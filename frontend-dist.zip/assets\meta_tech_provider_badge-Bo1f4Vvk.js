const e="/assets/meta_tech_provider_badge-BNI92b8_.png";export{e as m};
