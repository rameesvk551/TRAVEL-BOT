import{c}from"./createLucideIcon-Yi38CAVC.js";import{u as l}from"./useQuery-CW3Fgc9e.js";import{h as s,i as u,k as i}from"./index-CfajBCbm.js";/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const r=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 6v6l4 2",key:"mmk7yg"}]],k=c("clock",r);/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const o=[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",ry:"2",key:"1m3agn"}],["circle",{cx:"9",cy:"9",r:"2",key:"af1f0g"}],["path",{d:"m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21",key:"1xmnt7"}]],f=c("image",o);/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const p=[["path",{d:"M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83z",key:"zw3jo"}],["path",{d:"M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12",key:"1wduqc"}],["path",{d:"M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17",key:"kqbvx6"}]],g=c("layers",p);/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const m=[["path",{d:"M12 4v16",key:"1654pz"}],["path",{d:"M4 7V5a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1v2",key:"e0r10z"}],["path",{d:"M9 20h6",key:"s66wpe"}]],b=c("type",m);/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const y=[["path",{d:"m16 13 5.223 3.482a.5.5 0 0 0 .777-.416V7.87a.5.5 0 0 0-.752-.432L16 10.5",key:"ftymec"}],["rect",{x:"2",y:"6",width:"14",height:"12",rx:"2",key:"158x01"}]],v=c("video",y),n={listPrebuilt:e=>s.get("/templates/prebuilt",{params:e}).then(t=>t.data),usePrebuilt:(e,t)=>s.post(`/templates/prebuilt/${e}/use`,t).then(a=>a.data),listAgency:e=>s.get("/templates",{params:e}).then(t=>t.data),getById:e=>s.get(`/templates/${e}`).then(t=>t.data),create:e=>s.post("/templates",e).then(t=>t.data),update:(e,t)=>s.patch(`/templates/${e}`,t).then(a=>a.data),uploadMedia:e=>{const t=new FormData;return t.append("media",e),s.post("/templates/upload-media",t,{headers:{"Content-Type":"multipart/form-data"}}).then(a=>a.data)},delete:e=>s.delete(`/templates/${e}`).then(t=>t.data),duplicate:e=>s.post(`/templates/${e}/duplicate`).then(t=>t.data),submit:e=>s.post(`/templates/${e}/submit`).then(t=>t.data),sync:()=>s.post("/templates/sync").then(e=>e.data)};function _(e={}){return l({queryKey:["templates","prebuilt",e],queryFn:()=>n.listPrebuilt(e)})}function T(e={}){return l({queryKey:["templates","agency",e],queryFn:()=>n.listAgency(e)})}function x(){const e=u();return i({mutationFn:t=>n.create(t),onSuccess:()=>e.invalidateQueries({queryKey:["templates"]})})}function K(){const e=u();return i({mutationFn:({id:t,data:a})=>n.update(t,a),onSuccess:(t,{id:a})=>{e.invalidateQueries({queryKey:["templates"]}),e.invalidateQueries({queryKey:["template",a]})}})}function Q(){const e=u();return i({mutationFn:t=>n.delete(t),onSuccess:()=>e.invalidateQueries({queryKey:["templates"]})})}function $(){const e=u();return i({mutationFn:({id:t,data:a})=>n.usePrebuilt(t,a),onSuccess:()=>e.invalidateQueries({queryKey:["templates"]})})}function F(){const e=u();return i({mutationFn:t=>n.submit(t),onSuccess:(t,a)=>{e.invalidateQueries({queryKey:["templates"]}),e.invalidateQueries({queryKey:["template",a]})}})}function M(){const e=u();return i({mutationFn:()=>n.sync(),onSuccess:()=>e.invalidateQueries({queryKey:["templates"]})})}export{k as C,f as I,g as L,b as T,v as V,K as a,$ as b,Q as c,F as d,_ as e,T as f,M as g,n as t,x as u};
