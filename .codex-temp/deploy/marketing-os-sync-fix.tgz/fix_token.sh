#!/bin/bash
TOKEN=$(grep WHATSAPP_ACCESS_TOKEN ~/marketting-os/marketing-os-server/.env | cut -d= -f2 | tr -d '\r\n')
echo "Token length: ${#TOKEN}"
echo "Token prefix: ${TOKEN:0:30}"
docker exec marketing_os_postgres psql -U edger_user -d travel_ops -c "UPDATE whatsapp_business_configs SET access_token = '${TOKEN}', updated_at = NOW() RETURNING tenant_id, length(access_token) as token_len;"
