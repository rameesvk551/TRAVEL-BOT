require('dotenv').config();
const mongoose = require('mongoose');

(async () => {
    try {
        const uri = 'mongodb://localhost:27018/marketing-os?directConnection=true';
        await mongoose.connect(uri);

        console.log("Connected to MongoDB");

        // Dynamically import the required modules since they are ES modules
        const { getPartnerOrThrow, updatePartnerSettings, rotatePartnerWebhookSecret } = await import('./dist/modules/partner/partner.service.js');
        const { TenantModel } = await import('./dist/modules/tenant/tenant.model.js');
        const { PartnerModel } = await import('./dist/modules/partner/partner.model.js');

        const tenantSlug = 'wayo-82ac6fd3';
        const tenant = await TenantModel.findOne({ slug: tenantSlug });

        if (!tenant || !tenant.partnerId) {
            console.error('Tenant or partnerId not found!');
            process.exit(1);
        }

        const partnerId = tenant.partnerId.toString();
        console.log('Found Partner ID:', partnerId);

        const webhookUrl = 'http://localhost:6767/api/whatsapp/webhook';

        console.log('Updating partner webhookUrl to', webhookUrl);
        await updatePartnerSettings(partnerId, { webhookUrl });

        console.log('Generating new webhook secret...');
        const result = await rotatePartnerWebhookSecret(partnerId);

        console.log('================ OUTPUT ================');
        console.log('WEBHOOK_SECRET=' + result.webhookSecret);
        console.log('========================================');

        process.exit(0);

    } catch (e) {
        console.error("Error:", e);
        process.exit(1);
    }
})();
