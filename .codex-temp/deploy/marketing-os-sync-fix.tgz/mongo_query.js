import mongoose from 'mongoose';

async function run() {
  await mongoose.connect('mongodb://127.0.0.1:27017/marketing_os');
  const Tenant = mongoose.connection.collection('tenants');
  
  const tenants = await Tenant.find({}).toArray();
  console.log('All Tenants in Mongo:');
  tenants.forEach(t => console.log(t.name, t.slug, t.email, 'partnerId:', t.partnerId));
  process.exit(0);
}
run();
