import 'dotenv/config.js';
import mongoose from 'mongoose';
import crypto from 'crypto';

(async () => {
  try {
    const mongoUri = process.env.MONGODB_URI || 'mongodb://localhost:27017/marketing-os';
    await mongoose.connect(mongoUri);
    console.log('✅ Connected to MongoDB\n');

    const partnerSchema = new mongoose.Schema({
      name: String,
      email: { type: String, unique: true, sparse: true },
      commissionRate: Number,
      status: String,
      plan: String,
      walletBalance: Number,
      totalCustomers: Number,
      totalRevenue: Number,
      referralCode: String,
      webhookUrl: String,
      webhookSecretEncrypted: String,
      apiKeyEncrypted: String
    });

    const Partner = mongoose.model('Partner', partnerSchema);
    const referralCode = 'REA-BOT-' + crypto.randomBytes(4).toString('hex').toUpperCase();
    const apiKey = 'reb_' + crypto.randomBytes(32).toString('hex');

    const partner = await Partner.findOneAndUpdate(
      { email: 'admin@real-estate-bot.wayon.in' },
      {
        name: 'Real Estate Bot',
        email: 'admin@real-estate-bot.wayon.in',
        commissionRate: 0.50,
        status: 'active',
        plan: 'enterprise',
        walletBalance: 0,
        totalCustomers: 0,
        totalRevenue: 0,
        referralCode,
        webhookUrl: 'https://api.real-estate.wayon.in/webhooks/marketing-os'
      },
      { new: true, upsert: true, runValidators: false }
    );

    console.log('✅ Partner Created/Updated\n');
    console.log('====================================');
    console.log('Name:              ' + partner.name);
    console.log('Email:             ' + partner.email);
    console.log('Referral Code:     ' + partner.referralCode);
    console.log('Status:            ' + partner.status);
    console.log('Commission Rate:   ' + (partner.commissionRate * 100) + '%');
    console.log('\n📋 Credentials for Real Estate Bot .env:');
    console.log('====================================');
    console.log('MARKETING_OS_API_BASE_URL=https://api.marketing-os.wayon.in');
    console.log('MARKETING_OS_PARTNER_KEY=' + apiKey);
    console.log('MARKETING_OS_PROVISION_ENABLED=true');
    console.log('====================================\n');

    process.exit(0);
  } catch (error) {
    console.error('❌ Error:', error.message);
    process.exit(1);
  }
})();
