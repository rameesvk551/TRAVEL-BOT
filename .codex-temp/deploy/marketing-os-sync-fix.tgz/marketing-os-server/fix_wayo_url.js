import 'dotenv/config';
import { MongoClient } from 'mongodb';

const uri = process.env.MONGODB_URI || 'mongodb://localhost:27017/marketing_os';

async function run() {
  const client = new MongoClient(uri);
  try {
    await client.connect();
    const db = client.db();
    const partners = db.collection('partners');

    console.log('Searching for Wayo partner...');
    const partner = await partners.findOne({ name: /Wayo/i });

    if (!partner) {
      console.error('Wayo partner NOT found!');
      return;
    }

    console.log('Current Partner Record:', JSON.stringify(partner, null, 2));

    const result = await partners.updateOne(
      { _id: partner._id },
      { $set: { webhookUrl: 'http://localhost:6767/api/whatsapp/webhook' } }
    );

    console.log('Update result:', result);
    console.log('Wayo Webhook URL corrected to: http://localhost:6767/api/whatsapp/webhook');

  } finally {
    await client.close();
  }
}

run().catch(console.dir);
