const mongoose = require('mongoose');

async function debugWayo() {
  try {
    await mongoose.connect('mongodb://localhost:27018/marketing-os');
    const tenant = await mongoose.connection.db.collection('tenants').findOne({ slug: 'wayo-82ac6fd3' });
    console.log('Tenant:', JSON.stringify(tenant, null, 2));

    if (tenant && tenant.partnerId) {
      const partner = await mongoose.connection.db.collection('partners').findOne({ _id: tenant.partnerId });
      console.log('Partner:', JSON.stringify(partner, null, 2));
    } else {
      console.log('Tenant wayo-82ac6fd3 has no partnerId.');
    }
    process.exit(0);
  } catch (err) {
    console.error('Error:', err);
    process.exit(1);
  }
}

debugWayo();
