import 'dotenv/config';
import { MongoClient } from 'mongodb';

// Correct URI from EC2 .env
const uri = 'mongodb://localhost:27018/marketing-os?directConnection=true';
const WAYO_TENANT_ID = 'b78ba0d3-3563-441d-b657-619f79e2e58e';

async function run() {
  const client = new MongoClient(uri);
  try {
    await client.connect();
    const db = client.db();
    
    console.log('1. Searching for the Customer/Tenant in marketing-os...');
    const customer = await db.collection('partnercustomers').findOne({ tenantId: WAYO_TENANT_ID });
    
    if (!customer) {
      console.error('Wayo tenant NOT found in partnercustomers!');
      // Try searching all
      const allCustomers = await db.collection('partnercustomers').find({}).toArray();
      console.log('All customer tenant IDs:', allCustomers.map(c => c.tenantId));
      return;
    }

    console.log('2. Found Customer. Partner ID:', customer.partnerId);

    console.log('3. Searching for the Partner...');
    const partner = await db.collection('partners').findOne({ _id: customer.partnerId });

    if (!partner) {
      console.error('Partner NOT found!');
      return;
    }

    console.log('4. Found Partner:', partner.name, 'Current URL:', partner.webhookUrl);

    if (partner.webhookUrl.includes('/flow')) {
      console.log('5. Correcting URL...');
      const result = await db.collection('partners').updateOne(
        { _id: partner._id },
        { $set: { webhookUrl: 'http://localhost:6767/api/whatsapp/webhook' } }
      );
      console.log('Update result:', result);
      console.log('SUCCESS: URL corrected to /webhook');
    } else {
      console.log('Partner URL is already NOT /flow. No change needed.');
    }

  } catch (err) {
    console.error('Database error:', err);
  } finally {
    await client.close();
  }
}

run().catch(console.dir);
