import db from './src/db/sqlmodels/index.js';

async function checkUser() {
  const email = 'rameesvk551@gmail.com';
  try {
    const user = await db.User.findOne({ where: { email } });
    if (user) {
      console.log('User found:');
      console.log('ID:', user.id);
      console.log('Email:', user.email);
      console.log('Name:', user.name);
      console.log('Created At:', user.createdAt);
      console.log('Password Hash (first 10 chars):', user.password_hash.substring(0, 10));
    } else {
      console.log('User not found:', email);
    }
    process.exit(0);
  } catch (error) {
    console.error('Error checking user:', error);
    process.exit(1);
  }
}

checkUser();
