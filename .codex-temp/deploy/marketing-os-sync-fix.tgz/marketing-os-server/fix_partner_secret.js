import mongoose from 'mongoose';
import { PartnerModel } from './src/modules/partner/partner.model.js';
import { TenantModel } from './src/modules/tenant/tenant.model.js';
import { encryptSecret } from './src/modules/whatsapp/security/tokenCipher.js';
import dotenv from 'dotenv';

dotenv.config();

async function fixPartner() {
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('Connected to MongoDB');

    const tenantSlug = 'b78ba0d3-9efc-464e-bced-30784ae2e58e';
    const tenant = await TenantModel.findOne({ slug: tenantSlug });
    
    if (!tenant) {
        console.error('Tenant not found');
        process.exit(1);
    }

    const partnerId = tenant.partnerId;
    if (!partnerId) {
        console.error('Partner ID missing on tenant');
        process.exit(1);
    }

    const secret = 'pkwhsec_wayo_restore_2026';
    const encryptedSecret = encryptSecret(secret);

    await PartnerModel.findByIdAndUpdate(partnerId, {
        webhookUrl: 'http://localhost:6767/api/whatsapp/flow',
        webhookSecretEncrypted: encryptedSecret,
        status: 'active'
    });

    console.log(`Updated Partner ${partnerId} with secret and URL`);
    process.exit(0);
}

fixPartner().catch(err => {
    console.error(err);
    process.exit(1);
});
