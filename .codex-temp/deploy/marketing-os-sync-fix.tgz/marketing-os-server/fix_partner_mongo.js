const mongoose = require('mongoose');
const crypto = require('crypto');

// Configuration
const MONGO_URI = 'mongodb://localhost:27018/marketing-os?directConnection=true';
const ENCRYPTION_KEY = 'wato_secret_encryption_key_2026_03_29';
const TENANT_SLUG = 'wayo-82ac6fd3';
const NEW_SECRET = 'pkwhsec_wayo_restore_2026';

// Encryption logic (matching Marketing OS)
function encryptSecret(text) {
    const iv = crypto.randomBytes(16);
    const cipher = crypto.createCipheriv('aes-256-cbc', crypto.createHash('sha256').update(ENCRYPTION_KEY).digest(), iv);
    let encrypted = cipher.update(text);
    encrypted = Buffer.concat([encrypted, cipher.final()]);
    return iv.toString('hex') + ':' + encrypted.toString('hex');
}

async function run() {
    try {
        await mongoose.connect(MONGO_URI);
        console.log('Connected to MongoDB');

        const db = mongoose.connection.db;
        
        // 1. Find tenant
        const tenant = await db.collection('tenants').findOne({ slug: TENANT_SLUG });
        if (!tenant) {
            console.error('Tenant not found');
            process.exit(1);
        }
        console.log('Found tenant:', tenant.slug, 'Partner ID:', tenant.partnerId);

        const partnerId = tenant.partnerId;
        if (!partnerId) {
            console.error('No partnerId on tenant');
            process.exit(1);
        }

        // 2. Update partner
        const encryptedSecret = encryptSecret(NEW_SECRET);
        const result = await db.collection('partners').updateOne(
            { _id: partnerId },
            { 
                $set: { 
                    webhookUrl: 'http://localhost:6767/api/whatsapp/flow',
                    webhookSecretEncrypted: encryptedSecret,
                    status: 'active'
                } 
            }
        );

        console.log('Update result:', result);
        process.exit(0);
    } catch (err) {
        console.error(err);
        process.exit(1);
    }
}

run();
