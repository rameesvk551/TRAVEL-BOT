import { UploadApiResponse, UploadApiErrorResponse } from 'cloudinary';
import cloudinary from '../config/cloudinary.js';

export class CloudinaryService {
    /**
     * Upload an image buffer to Cloudinary
     * @param buffer - The image buffer to upload
     * @param folder - The folder name in Cloudinary
     * @returns A promise resolving to the uploaded image URL
     */
    static uploadImage(buffer: Buffer, folder: string = 'marketing_os_products'): Promise<string> {
        return new Promise((resolve, reject) => {
            const uploadStream = cloudinary.uploader.upload_stream(
                { folder },
                (error: UploadApiErrorResponse | undefined, result: UploadApiResponse | undefined) => {
                    if (error) {
                        return reject(error);
                    }
                    if (result && result.secure_url) {
                        resolve(result.secure_url);
                    } else {
                        reject(new Error('Failed to retrieve secure URL after upload.'));
                    }
                }
            );

            // Write buffer to stream and end
            if (!buffer) {
                return reject(new Error('Buffer is empty or undefined.'));
            }
            uploadStream.end(buffer);
        });
    }

    /**
     * Extract public ID from Cloudinary URL and delete the image
     * @param url - The Cloudinary image URL
     */
    static async deleteImageByUrl(url: string): Promise<void> {
        try {
            // e.g., https://res.cloudinary.com/demo/image/upload/v123456789/folder/image_id.jpg
            const segments = url.split('/');
            const filename = segments.pop() || '';
            const publicIdWithExt = filename.split('?')[0]; // Remove query params if any
            const publicId = publicIdWithExt.split('.')[0]; // Remove extension
            
            // Reconstruct the full public ID including the folder
            // Typically it's folder/image_id. This is a simplified extraction
            // A more robust way might be needed if folder depth is > 1
            const folderSegment = segments[segments.length - 1];
            
            let fullPublicId = publicId;
            if (folderSegment && folderSegment !== 'upload') {
                 fullPublicId = `${folderSegment}/${publicId}`;
            }

            if (fullPublicId) {
                await cloudinary.uploader.destroy(fullPublicId);
            }
        } catch (error) {
            console.error('Error deleting image from Cloudinary:', error);
            // We just log it and do not block the main process
        }
    }
}
