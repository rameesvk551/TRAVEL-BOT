import { Router } from 'express';
import { apiKeyMiddleware } from '../middlewares/apikey.middleware.js';
import { createTenantRouter } from '../modules/tenant/tenant.routes.js';
import { createMessagingRouter } from '../modules/messaging/messaging.routes.js';
import { createEventsRouter } from '../modules/events/events.routes.js';
import { createTenantController } from '../modules/tenant/tenant.controller.js';

/**
 * V1 API Router — partner-facing APIs.
 * All routes are protected by API key authentication.
 *
 * Mounted at: /api/v1
 */
const v1Router = Router();

// ── API key auth for all v1 routes ──
v1Router.use(apiKeyMiddleware);

// ── Tenant management ──
v1Router.use('/tenants', createTenantRouter());

// ── Message sending ──
v1Router.use('/messages', createMessagingRouter());

// ── Event ingestion & mapping ──
v1Router.use('/events', createEventsRouter());

// ── Partner self-service ──
const tenantController = createTenantController();
v1Router.post('/partners/api-key', tenantController.generateApiKey);

export default v1Router;
