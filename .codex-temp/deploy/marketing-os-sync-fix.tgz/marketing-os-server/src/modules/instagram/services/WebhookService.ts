// services/WebhookService.ts
// Processes incoming Instagram webhook events (comments, messages, mentions).

import { logger } from '../../../config/logger.js';
import { IInstagramAccountRepo } from '../repositories/InstagramAccountRepo.js';
import { IInstagramMediaRepo } from '../repositories/InstagramMediaRepo.js';
import { IInstagramCommentRepo } from '../repositories/InstagramCommentRepo.js';
import { IInstagramMessageRepo } from '../repositories/InstagramMessageRepo.js';
import type { IInstagramAutomationEngine } from './InstagramAutomationEngine.js';
import * as partnerService from '../../partner/partner.service.js';

export interface InstagramWebhookEntry {
    id: string;
    time: number;
    messaging?: Array<{
        sender: { id: string };
        recipient: { id: string };
        timestamp: number;
        message?: {
            mid: string;
            text?: string;
            attachments?: Array<{ type: string; payload: { url: string } }>;
        };
        postback?: {
            mid: string;
            title: string;
            payload: string;
        };
        read?: { watermark: number };
        reaction?: { mid: string; action: string; reaction: string; emoji: string };
    }>;
    changes?: Array<{
        field: string;
        value: {
            from: { id: string; username: string };
            media: { id: string; media_product_type: string };
            id: string;
            text: string;
            verb: string;
            created_time: number;
            parent_id?: string;
        };
    }>;
}

export interface IWebhookService {
    processWebhook(body: any): Promise<void>;
    verifySignature(payload: Buffer, signature: string, appSecret: string): boolean;
    setAutomationEngine(engine: IInstagramAutomationEngine): void;
}

export function createWebhookService(
    accountRepo: IInstagramAccountRepo,
    mediaRepo: IInstagramMediaRepo,
    commentRepo: IInstagramCommentRepo,
    messageRepo: IInstagramMessageRepo
): IWebhookService {
    // Late-bound automation engine (set after container is fully built to avoid circular deps)
    let automationEngine: IInstagramAutomationEngine | null = null;

    return {
        setAutomationEngine(engine: IInstagramAutomationEngine): void {
            automationEngine = engine;
        },
        async processWebhook(body: any): Promise<void> {
            const object = body.object;

            if (object !== 'instagram') {
                logger.warn(`[IG Webhook] Unexpected object type: ${object}`);
                return;
            }

            const entries: InstagramWebhookEntry[] = body.entry || [];

            for (const entry of entries) {
                const igAccountId = entry.id;

                // Lookup ALL accounts connected to this Instagram User ID (across all tenants)
                const connectedAccounts = await accountRepo.findByIgUserIdGlobal(igAccountId);
                if (connectedAccounts.length === 0) {
                    logger.debug(`[IG Webhook] Received event for unconnected account ${igAccountId}`);
                    continue;
                }

                // ── Handle comment/mention webhooks ──
                if (entry.changes) {
                    for (const change of entry.changes) {
                        switch (change.field) {
                            case 'comments':
                                logger.info(`[IG Webhook] Comment on media ${change.value.media?.id} from @${change.value.from?.username}: "${change.value.text}"`);

                                // Process for each tenant that has this account connected
                                for (const account of connectedAccounts) {
                                    // Try to link to a specific media item in our DB
                                    const media = await mediaRepo.findByIgMediaId(change.value.media?.id);

                                    try {
                                        await commentRepo.save({
                                            tenantId: account.tenantId,
                                            accountId: account.id,
                                            mediaId: media ? media.id : null,
                                            igCommentId: change.value.id,
                                            igMediaId: change.value.media?.id,
                                            fromUsername: change.value.from?.username || 'unknown',
                                            fromId: change.value.from?.id,
                                            text: change.value.text,
                                            parentId: change.value.parent_id,
                                            timestamp: (() => {
                                                const raw = change.value.created_time;
                                                // If it looks like a unix timestamp (seconds), convert to ms
                                                if (typeof raw === 'number' && !isNaN(raw) && raw > 1000000000) {
                                                    return new Date(raw * 1000);
                                                }
                                                // If it's a numeric string that looks like a unix timestamp
                                                if (typeof raw === 'string' && !isNaN(Number(raw)) && Number(raw) > 1000000000) {
                                                    return new Date(Number(raw) * 1000);
                                                }
                                                // Try parsing as ISO string
                                                const d = new Date(raw);
                                                return isNaN(d.getTime()) ? new Date() : d;
                                            })(),
                                        });

                                        if (media) {
                                            // Increment comment count on our media
                                            await mediaRepo.updateEngagement(media.id, {
                                                commentsCount: (media.commentsCount || 0) + 1
                                            });
                                        } else {
                                            logger.info(`[IG Webhook] Saved comment ${change.value.id} for unknown media ${change.value.media?.id} (untracked post).`);
                                        }

                                        // Trigger automation engine for this comment
                                        if (automationEngine) {
                                            try {
                                                await automationEngine.processCommentEvent(account.tenantId, {
                                                    accountId: account.id,
                                                    commentId: change.value.id,
                                                    igCommentId: change.value.id,
                                                    mediaId: change.value.media?.id || '',
                                                    igMediaId: change.value.media?.id || '',
                                                    fromId: change.value.from?.id || '',
                                                    fromUsername: change.value.from?.username || 'unknown',
                                                    text: change.value.text,
                                                });
                                            } catch (autoErr: any) {
                                                logger.error(`[IG Webhook] Automation processing failed for comment: ${autoErr.message}`);
                                            }
                                        }

                                        // Dispatch to partner webhook if configured
                                        try {
                                            await partnerService.dispatchPartnerWebhookByTenant({
                                                tenantId: account.tenantId,
                                                eventType: 'instagram_comment',
                                                data: change.value,
                                                isRawProxy: true,
                                            });
                                        } catch (proxyErr: any) {
                                            logger.warn(`[IG Webhook] Failed to dispatch proxy for comment: ${proxyErr.message}`);
                                        }
                                    } catch (err: any) {
                                        logger.error(`[IG Webhook] Failed to save comment for tenant ${account.tenantId}: ${err.message}`);
                                    }
                                }
                                break;

                            case 'mentions':
                                logger.info(`[IG Webhook] Mentioned by @${change.value.from?.username} in media ${change.value.media?.id}`);
                                // TODO: Phase 4 — UGC detection
                                break;

                            case 'live_comments':
                                logger.info(`[IG Webhook] Live comment from @${change.value.from?.username}`);
                                break;

                            case 'story_insights':
                                logger.info(`[IG Webhook] Story insights received for account ${igAccountId}`);
                                break;

                            default:
                                logger.debug(`[IG Webhook] Unhandled change field: ${change.field}`);
                        }
                    }
                }

                // ── Handle messaging webhooks ──
                if (entry.messaging) {
                    for (const event of entry.messaging) {
                        if (event.message) {
                            logger.info(`[IG Webhook] DM from ${event.sender.id}: "${event.message.text || '[media]'}"`);

                            for (const account of connectedAccounts) {
                                try {
                                    // Generate a pseudo-conversation ID based on the sender/recipient pair to group messages
                                    const p1 = event.sender.id < event.recipient.id ? event.sender.id : event.recipient.id;
                                    const p2 = event.sender.id > event.recipient.id ? event.sender.id : event.recipient.id;
                                    const conversationId = `${p1}_${p2}`;

                                    await messageRepo.save({
                                        tenantId: account.tenantId,
                                        accountId: account.id,
                                        igMessageId: event.message.mid,
                                        conversationId: conversationId,
                                        senderId: event.sender.id,
                                        recipientId: event.recipient.id,
                                        text: event.message.text,
                                        attachments: event.message.attachments,
                                        isEcho: event.sender.id === igAccountId, // If sender is the IG page itself
                                        timestamp: new Date(event.timestamp), // Meta sends MS here usually
                                    });

                                    // Check if this is the first message from this user (conversation opener)
                                    if (automationEngine && event.sender.id !== igAccountId) {
                                        const existingMessages = await messageRepo.findByConversation(account.tenantId, conversationId, 2);
                                        const isFirstMessage = existingMessages.length <= 1; // Just the message we saved

                                        if (isFirstMessage) {
                                            // Trigger conversation opener automation
                                            try {
                                                await automationEngine.processConversationOpener(
                                                    account.tenantId,
                                                    account.id,
                                                    event.sender.id
                                                );
                                                logger.info(`[IG Webhook] Triggered conversation opener for new user ${event.sender.id}`);
                                            } catch (autoErr: any) {
                                                logger.error(`[IG Webhook] Conversation opener automation failed: ${autoErr.message}`);
                                            }
                                        }

                                        // Also process regular DM automations (keyword triggers)
                                        try {
                                            await automationEngine.processMessageEvent(account.tenantId, {
                                                accountId: account.id,
                                                messageId: event.message.mid,
                                                senderId: event.sender.id,
                                                text: event.message.text || '',
                                            });
                                        } catch (autoErr: any) {
                                            logger.error(`[IG Webhook] Automation processing failed for message: ${autoErr.message}`);
                                        }
                                    }

                                    // Dispatch to partner webhook if configured
                                    try {
                                        await partnerService.dispatchPartnerWebhookByTenant({
                                            tenantId: account.tenantId,
                                            eventType: 'instagram_message',
                                            data: {
                                                accountId: account.id,
                                                igAccountId,
                                                senderId: event.sender.id,
                                                recipientId: event.recipient.id,
                                                messageId: event.message.mid,
                                                text: event.message.text,
                                                attachments: event.message.attachments,
                                                timestamp: event.timestamp,
                                            },
                                            isRawProxy: true,
                                        });
                                    } catch (proxyErr: any) {
                                        logger.warn(`[IG Webhook] Failed to dispatch proxy for message: ${proxyErr.message}`);
                                    }
                                } catch (err: any) {
                                    logger.error(`[IG Webhook] Failed to save message for tenant ${account.tenantId}: ${err.message}`);
                                }
                            }
                        } else if (event.postback) {
                            logger.info(`[IG Webhook] Postback from ${event.sender.id}: ${event.postback.payload}`);
                        } else if (event.read) {
                            logger.debug(`[IG Webhook] Message read by ${event.sender.id}`);
                        } else if (event.reaction) {
                            logger.debug(`[IG Webhook] Reaction ${event.reaction.emoji} on message ${event.reaction.mid}`);
                        }
                    }
                }
            }
        },

        verifySignature(payload: Buffer, signature: string, appSecret: string): boolean {
            try {
                const crypto = require('crypto');
                const expectedSig = crypto
                    .createHmac('sha256', appSecret)
                    .update(payload)
                    .digest('hex');
                return `sha256=${expectedSig}` === signature;
            } catch {
                return false;
            }
        },
    };
}
