import { Request, Response, NextFunction } from 'express';
import * as orderService from './order.service.js';

// ── Order Controller — HTTP Request Handlers ──

export const list = async (req: Request, res: Response, next: NextFunction) => {
    try {
        const tenantId = req.context.tenantId;
        const result = await orderService.getAllOrders(tenantId, req.query as any);

        res.json({ status: 'success', ...result });
    } catch (error) {
        next(error);
    }
};

export const getById = async (req: Request, res: Response, next: NextFunction) => {
    try {
        const tenantId = req.context.tenantId;
        const order = await orderService.getOrderById(req.params.id, tenantId);

        res.json({ status: 'success', data: order });
    } catch (error) {
        next(error);
    }
};

export const create = async (req: Request, res: Response, next: NextFunction) => {
    try {
        const tenantId = req.context.tenantId;
        const userId = req.context.userId || '';
        const order = await orderService.createOrder(tenantId, userId, req.body);

        res.status(201).json({ status: 'success', data: order });
    } catch (error) {
        next(error);
    }
};

export const updateStatus = async (req: Request, res: Response, next: NextFunction) => {
    try {
        const tenantId = req.context.tenantId;
        const order = await orderService.updateOrderStatus(req.params.id, tenantId, req.body);

        // Send WhatsApp notification if the order came from WhatsApp
        if (order.source === 'whatsapp' && order.phoneNumber) {
            try {
                const statusLabel = req.body.orderStatus || order.orderStatus;

                // Try to use native order_status message
                const { createWhatsAppPaymentService } = await import('../../modules/whatsapp/services/WhatsAppPaymentService.js');
                const { getPool } = await import('../../config/database.js');
                const pool = getPool();
                const paymentService = createWhatsAppPaymentService(pool);

                // Map our statuses to WhatsApp order_status values
                const waStatusMap: Record<string, 'processing' | 'shipped' | 'completed' | 'canceled'> = {
                    pending: 'processing',
                    confirmed: 'processing',
                    shipped: 'shipped',
                    delivered: 'completed',
                    cancelled: 'canceled',
                };

                const waStatus = waStatusMap[statusLabel];
                if (waStatus) {
                    const descriptions: Record<string, string> = {
                        processing: 'Your order is being prepared.',
                        shipped: 'Your order has been shipped and is on its way!',
                        completed: 'Your order has been delivered. Thank you!',
                        canceled: 'Your order has been cancelled.',
                    };

                    await paymentService.sendOrderStatusMessage(
                        tenantId,
                        order.phoneNumber,
                        order.orderId,
                        waStatus,
                        descriptions[waStatus],
                    );
                    console.log(`[OrderController] Sent native order_status (${waStatus}) for ${order.orderId}`);
                }
            } catch (notifyErr) {
                // Fallback to text message
                try {
                    const statusLabel = req.body.orderStatus || order.orderStatus;
                    const statusEmoji: Record<string, string> = {
                        pending: '⏳', confirmed: '✅', shipped: '🚚', delivered: '📦', cancelled: '❌',
                    };
                    const emoji = statusEmoji[statusLabel] || '📋';
                    const text = `${emoji} *Order Update*\nYour order *#${order.orderId}* is now *${statusLabel.toUpperCase()}*.${
                        req.body.paymentStatus ? `\nPayment: ${req.body.paymentStatus.toUpperCase()}` : ''
                    }\n\nThank you for shopping with us!`;

                    const { getPool } = await import('../../config/database.js');
                    const pool = getPool();
                    const configResult = await pool.query(
                        `SELECT phone_number_id, access_token FROM whatsapp_business_configs WHERE tenant_id = $1 AND status = 'connected' LIMIT 1`,
                        [tenantId]
                    );
                    if (configResult.rows.length > 0) {
                        const { phone_number_id, access_token } = configResult.rows[0];
                        const apiVersion = process.env.META_API_VERSION || 'v19.0';
                        await fetch(`https://graph.facebook.com/${apiVersion}/${phone_number_id}/messages`, {
                            method: 'POST',
                            headers: {
                                'Authorization': `Bearer ${access_token}`,
                                'Content-Type': 'application/json',
                            },
                            body: JSON.stringify({
                                messaging_product: 'whatsapp',
                                to: order.phoneNumber,
                                type: 'text',
                                text: { body: text },
                            }),
                        });
                        console.log(`[OrderController] Sent text fallback for order ${order.orderId} to ${order.phoneNumber}`);
                    }
                } catch (fallbackErr) {
                    console.warn('[OrderController] Failed to send any notification:', fallbackErr);
                }
            }
        }

        res.json({ status: 'success', data: order });
    } catch (error) {
        next(error);
    }
};

export const stats = async (req: Request, res: Response, next: NextFunction) => {
    try {
        const tenantId = req.context.tenantId;
        const data = await orderService.getStats(tenantId);

        res.json({ status: 'success', data });
    } catch (error) {
        next(error);
    }
};

export const sendInvoice = async (req: Request, res: Response, next: NextFunction) => {
    try {
        const tenantId = req.context.tenantId;
        const order = await orderService.getOrderById(req.params.id, tenantId);

        if (!order.phoneNumber) {
            res.status(400).json({ status: 'error', message: 'Order has no phone number' });
            return;
        }

        const { createWhatsAppPaymentService } = await import('../../modules/whatsapp/services/WhatsAppPaymentService.js');
        const { getPool } = await import('../../config/database.js');
        const pool = getPool();
        const paymentService = createWhatsAppPaymentService(pool);

        await paymentService.sendOrderDetailsMessage(tenantId, {
            recipientPhone: order.phoneNumber,
            referenceId: order.orderId,
            items: order.products.map(p => ({
                productName: p.productName,
                quantity: p.quantity,
                price: p.price,
                sku: typeof p.product === 'object' ? String((p.product as any)._id) : String(p.product),
            })),
            subtotal: order.totalAmount,
            tax: 0,
            totalAmount: order.totalAmount,
            expirationSeconds: 3600,
        });

        res.json({ status: 'success', message: 'Invoice sent via WhatsApp' });
    } catch (error) {
        next(error);
    }
};
