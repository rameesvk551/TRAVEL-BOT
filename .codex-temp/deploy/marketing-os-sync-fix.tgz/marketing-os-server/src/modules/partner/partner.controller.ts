import { Request, Response } from 'express';
import { z } from 'zod';
import { asyncHandler } from '../../utils/asyncHandler.js';
import { ApiResponse } from '../../utils/apiResponse.js';
import * as partnerService from './partner.service.js';

const joinPartnerSchema = z.object({
    name: z.string().trim().min(2).max(120),
});

const withdrawSchema = z.object({
    amount: z.coerce.number().finite().positive(),
});

const settingsSchema = z.object({
    webhookUrl: z.string().trim().url().max(2048),
});

const resolveRequestPartner = async (req: Request) => {
    return partnerService.resolvePartnerContext({
        userId: req.user?.id,
    });
};

export const getDashboard = asyncHandler(async (req: Request, res: Response) => {
    const partner = await resolveRequestPartner(req);
    const dashboard = await partnerService.getPartnerDashboard(partner.id);

    ApiResponse.success(res, dashboard, 'Partner dashboard fetched successfully');
});

export const getCustomers = asyncHandler(async (req: Request, res: Response) => {
    const partner = await resolveRequestPartner(req);
    const customers = await partnerService.getPartnerCustomers(partner.id);

    ApiResponse.success(res, customers, 'Partner customers fetched successfully');
});

export const getCommissions = asyncHandler(async (req: Request, res: Response) => {
    const partner = await resolveRequestPartner(req);
    const commissions = await partnerService.getPartnerCommissions(partner.id);

    ApiResponse.success(res, commissions, 'Partner commissions fetched successfully');
});

export const withdraw = asyncHandler(async (req: Request, res: Response) => {
    const partner = await resolveRequestPartner(req);
    const { amount } = withdrawSchema.parse(req.body || {});
    const withdrawRequest = await partnerService.createWithdrawRequest(partner.id, amount);

    ApiResponse.created(res, withdrawRequest, 'Withdraw request created successfully');
});

export const joinPartner = asyncHandler(async (req: Request, res: Response) => {
    const userId = req.user?.id;
    if (!userId) {
        throw new Error('User not authenticated');
    }
    const { name } = joinPartnerSchema.parse(req.body || {});
    
    const partner = await partnerService.joinAsPartner({ userId, name });
    
    ApiResponse.created(res, partner, 'Successfully joined the partner program');
});

export const updateSettings = asyncHandler(async (req: Request, res: Response) => {
    const partnerCtx = await resolveRequestPartner(req);
    const { webhookUrl } = settingsSchema.parse(req.body || {});
    
    const updated = await partnerService.updatePartnerSettings(partnerCtx.id, { webhookUrl });
    
    ApiResponse.success(res, updated, 'Partner settings updated successfully');
});

export const rotateWebhookSecret = asyncHandler(async (req: Request, res: Response) => {
    const partnerCtx = await resolveRequestPartner(req);
    const secret = await partnerService.rotatePartnerWebhookSecret(partnerCtx.id);

    ApiResponse.success(res, secret, 'Partner webhook secret rotated successfully');
});

export const migrateApiKey = asyncHandler(async (req: Request, res: Response) => {
    const partnerCtx = await resolveRequestPartner(req);
    const result = await partnerService.rotatePartnerApiKey(partnerCtx.id);

    ApiResponse.success(res, result, 'Partner API key migrated successfully');
});
