import mongoose from 'mongoose';
import crypto from 'crypto';
import bcrypt from 'bcryptjs';
import { v4 as uuidv4 } from 'uuid';
import { getPartnerCommissionHistory } from '../commission/commission.service.js';
import { ValidationError, NotFoundError } from '../../utils/apiError.js';
import * as authRepository from '../auth/auth.repository.js';
import { TenantModel } from '../tenant/tenant.model.js';
import { encryptSecret, decryptSecret } from '../whatsapp/security/tokenCipher.js';
import {
    PartnerCustomerModel,
    PartnerModel,
    WithdrawRequestModel,
    type IPartner,
} from './partner.model.js';

interface ResolvePartnerContextInput {
    explicitPartnerId?: string;
    userId?: string;
}

interface JoinPartnerInput {
    userId: string;
    name: string;
}

interface RegisterReferredCustomerInput {
    businessName: string;
    email: string;
    partnerId: string;
    tenantId?: string;
    plan?: string;
}

interface SyncPartnerCustomerFromTenantInput {
    partnerId: string;
    tenantId: string;
    businessName: string;
    email: string;
    plan?: string;
}

interface DispatchPartnerWebhookByTenantInput {
    tenantId: string;
    eventType: string;
    data: Record<string, unknown>;
    timestamp?: string;
    isRawProxy?: boolean;
}

const PARTNER_WEBHOOK_TIMEOUT_MS = 5000;
const PARTNER_WEBHOOK_EVENTS = new Set(['message', 'status', 'account_update', 'raw_proxy', 'instagram_message', 'instagram_comment']);
const PARTNER_PROXY_SHARED_SECRET = process.env.PARTNER_PROXY_SHARED_SECRET || process.env.MARKETING_OS_WEBHOOK_SECRET || '';

const isBlockedHostname = (hostname: string) => {
    const lower = hostname.toLowerCase();
    if (lower === 'localhost' || lower === '127.0.0.1' || lower === '::1') {
        return true;
    }

    if (/^10\./.test(lower) || /^192\.168\./.test(lower) || /^169\.254\./.test(lower)) {
        return true;
    }

    if (/^172\.(1[6-9]|2\d|3[0-1])\./.test(lower)) {
        return true;
    }

    return false;
};

const validatePartnerWebhookUrl = (rawUrl?: string) => {
    if (!rawUrl) {
        return { ok: true as const, parsed: null };
    }

    try {
        const parsed = new URL(rawUrl);
        const isHttps = parsed.protocol === 'https:';
        const isHttpLocal = parsed.protocol === 'http:' && (
            parsed.hostname === 'localhost' ||
            parsed.hostname === '127.0.0.1'
        );

        if (!isHttps && !isHttpLocal) {
            return { ok: false as const, reason: 'Webhook URL must use https (or http localhost for local testing).' };
        }

        if (isBlockedHostname(parsed.hostname) && parsed.hostname !== 'localhost' && parsed.hostname !== '127.0.0.1') {
            return { ok: false as const, reason: 'Webhook URL host is not allowed.' };
        }

        return { ok: true as const, parsed };
    } catch {
        return { ok: false as const, reason: 'Webhook URL is invalid.' };
    }
};

const signPartnerWebhookPayload = (input: {
    webhookSecret: string;
    eventType: string;
    tenantId: string;
    timestamp: string;
    data: Record<string, unknown>;
}) => {
    const payload = JSON.stringify({
        tenantId: input.tenantId,
        eventType: input.eventType,
        timestamp: input.timestamp,
        data: input.data,
    });

    const signature = crypto
        .createHmac('sha256', input.webhookSecret)
        .update(payload)
        .digest('hex');

    return {
        payload,
        signature,
    };
};

const FRONTEND_URL = process.env.FRONTEND_URL || 'http://localhost:5173';

const mapPartnerSummary = (partner: IPartner & { id: string }) => ({
    id: partner.id,
    name: partner.name,
    email: partner.email,
    commissionRate: partner.commissionRate,
    referralCode: partner.referralCode,
    referralLink: `${FRONTEND_URL}/signup?ref=${partner.referralCode}`,
    webhookUrl: partner.webhookUrl,
    webhookSecretConfigured: Boolean((partner as any).webhookSecretEncrypted),
    createdAt: partner.createdAt,
});

const mapCustomer = (customer: {
    id: string;
    businessName: string;
    email: string;
    plan: string;
    createdAt: Date;
}) => ({
    id: customer.id,
    businessName: customer.businessName,
    email: customer.email,
    plan: customer.plan,
    createdAt: customer.createdAt,
});

const mapWithdrawRequest = (request: {
    id: string;
    amount: number;
    status: 'pending' | 'approved' | 'rejected';
    createdAt: Date;
}) => ({
    id: request.id,
    amount: request.amount,
    status: request.status,
    createdAt: request.createdAt,
});

const getPendingWithdrawals = async (partnerId: string): Promise<number> => {
    const [pendingRecord] = await WithdrawRequestModel.aggregate<{ totalPending: number }>([
        {
            $match: {
                partnerId: new mongoose.Types.ObjectId(partnerId),
                status: 'pending',
            },
        },
        {
            $group: {
                _id: null,
                totalPending: { $sum: '$amount' },
            },
        },
    ]);

    return pendingRecord?.totalPending ?? 0;
};

const getPartnerOrThrow = async (partnerId: string) => {
    if (!mongoose.isValidObjectId(partnerId)) {
        throw new ValidationError('Invalid partner id', {
            partnerId: ['Partner id must be a valid Mongo ObjectId'],
        });
    }

    const partner = await PartnerModel.findById(partnerId);
    if (!partner) {
        throw new NotFoundError('Partner', partnerId);
    }

    return partner;
};

const resolvePartnerByUserId = async (userId?: string) => {
    if (!userId) {
        return null;
    }

    const user = await authRepository.findUserById(userId);
    if (!user?.email) {
        return null;
    }

    return PartnerModel.findOne({ email: user.email.toLowerCase().trim() });
};

export const resolvePartnerByReferralCode = async (referralCode: string) => {
    return PartnerModel.findOne({ referralCode: referralCode.toUpperCase().trim() });
};

export const resolvePartnerContext = async ({ explicitPartnerId, userId }: ResolvePartnerContextInput) => {
    if (explicitPartnerId) {
        return getPartnerOrThrow(explicitPartnerId);
    }

    const partner = await resolvePartnerByUserId(userId);
    if (partner) {
        return partner;
    }

    throw new ValidationError('Partner context is required', {
        partnerId: ['Provide x-partner-id, partnerId query param, or authenticate as a partner email.'],
    });
};

export const joinAsPartner = async ({ userId, name }: JoinPartnerInput) => {
    const user = await authRepository.findUserById(userId);
    if (!user || !user.email) {
        throw new ValidationError('User email is required to become a partner', {
            email: ['Cannot resolve email for this user'],
        });
    }

    const normalizedEmail = user.email.toLowerCase().trim();

    // Check if partner already exists
    let partner = await PartnerModel.findOne({ email: normalizedEmail });
    
    if (partner) {
        throw new ValidationError('You are already registered as a partner', {
            partnerId: ['Partner record already exists for this email.'],
        });
    }

    // Create the new partner
    partner = await PartnerModel.create({
        name: name.trim() || user.name || 'Partner',
        email: normalizedEmail,
        commissionRate: 0.50, // Default 50% commission 
        status: 'active',
        plan: 'starter',
        walletBalance: 0,
        totalCustomers: 0,
        totalRevenue: 0,
    });

    return mapPartnerSummary(partner as IPartner & { id: string });
};

export const registerReferredCustomer = async ({
    businessName,
    email,
    partnerId,
    tenantId,
    plan = 'trial',
}: RegisterReferredCustomerInput) => {
    const normalizedEmail = email.toLowerCase().trim();

    const existingCustomer = tenantId
        ? await PartnerCustomerModel.findOne({ tenantId })
        : await PartnerCustomerModel.findOne({ email: normalizedEmail });

    if (existingCustomer) {
        if (!existingCustomer.tenantId && tenantId) {
            existingCustomer.tenantId = tenantId;
        }

        if (existingCustomer.plan !== plan) {
            existingCustomer.plan = plan;
        }

        await existingCustomer.save();
        return existingCustomer;
    }

    const customer = await PartnerCustomerModel.create({
        businessName,
        email: normalizedEmail,
        partnerId,
        tenantId,
        plan,
    });

    await PartnerModel.findByIdAndUpdate(partnerId, {
        $inc: { totalCustomers: 1 },
    });

    return customer;
};

export const syncPartnerCustomerFromTenant = async ({
    partnerId,
    tenantId,
    businessName,
    email,
    plan = 'starter',
}: SyncPartnerCustomerFromTenantInput) => {
    const normalizedEmail = email.toLowerCase().trim();
    const normalizedBusinessName = businessName.trim();

    const existingCustomer = await PartnerCustomerModel.findOne({
        partnerId,
        $or: [{ tenantId }, { email: normalizedEmail }],
    });

    if (existingCustomer) {
        existingCustomer.tenantId = tenantId;
        existingCustomer.businessName = normalizedBusinessName;
        existingCustomer.email = normalizedEmail;
        existingCustomer.plan = plan;
        await existingCustomer.save();
        return existingCustomer;
    }

    return PartnerCustomerModel.create({
        partnerId,
        tenantId,
        businessName: normalizedBusinessName,
        email: normalizedEmail,
        plan,
    });
};

export const dispatchPartnerWebhookByTenant = async ({
    tenantId,
    eventType,
    data,
    timestamp = new Date().toISOString(),
    isRawProxy,
}: DispatchPartnerWebhookByTenantInput) => {
    try {
        if (!PARTNER_WEBHOOK_EVENTS.has(eventType)) {
            return { isPartnerTenant: false, dispatchedToWebhook: false };
        }

        let tenant = await TenantModel.findOne({
            $or: [
                { slug: tenantId },
                { 'metadata.sqlTenantId': tenantId }
            ]
        }).select('partnerId slug email').lean();

        // If not found, bridge Postgres UUID to Mongo Tenant via User's email
        if (!tenant) {
            try {
                console.log(`[PartnerWebhook] Tenant slug ${tenantId} not found in Mongo. Attempting SQL bridge...`);
                const db = (await import('../../db/sqlmodels/index.js')).default;
                const sqlUser = await db.User.findOne({ where: { tenant_id: tenantId } });
                console.log(`[PartnerWebhook] SQL bridge: found user with email ${sqlUser?.email} for tenantId ${tenantId}`);
                if (sqlUser && sqlUser.email) {
                    tenant = await TenantModel.findOne({ email: sqlUser.email })
                        .select('partnerId slug email')
                        .lean();
                    console.log(`[PartnerWebhook] SQL bridge: Mongo lookup by email returned ${tenant ? 'tenant ' + tenant.slug : 'null'}`);
                }
            } catch (err) {
                console.warn('[PartnerWebhook] Failed to bridge SQL tenantId to Mongo tenant via email:', err);
            }
        }

        if (!tenant?.partnerId) {
            console.log(`[PartnerWebhook] Final check failed: tenant ${tenantId} does not have a partnerId (is null? ${!tenant})`);
            return { isPartnerTenant: false, dispatchedToWebhook: false };
        }

        const partner = await PartnerModel.findById(tenant.partnerId)
            .select('webhookUrl webhookSecretEncrypted status')
            .lean();

        if (!partner || partner.status !== 'active' || !partner.webhookUrl) {
            return { isPartnerTenant: true, dispatchedToWebhook: false };
        }

        const validation = validatePartnerWebhookUrl(partner.webhookUrl);
        if (!validation.ok || !validation.parsed) {
            console.warn(`[PartnerWebhook] Skipping invalid webhook URL for tenant ${tenantId}`);
            return { isPartnerTenant: true, dispatchedToWebhook: false };
        }

        const webhookSecret = partner.webhookSecretEncrypted
            ? decryptSecret(partner.webhookSecretEncrypted)
            : null;

        const effectiveWebhookSecret = webhookSecret || process.env.META_APP_SECRET || '';
        if (!effectiveWebhookSecret) {
            console.warn(`[PartnerWebhook] Missing webhook secret for tenant ${tenantId}`);
            return { isPartnerTenant: true, dispatchedToWebhook: false };
        }

        let signed: { payload: string, signature: string };
        if (eventType === 'raw_proxy' || isRawProxy) {
            const rawPayload = JSON.stringify(data);
            const signature = crypto.createHmac('sha256', effectiveWebhookSecret).update(rawPayload).digest('hex');
            signed = { payload: rawPayload, signature };
        } else {
            signed = signPartnerWebhookPayload({
                webhookSecret: effectiveWebhookSecret,
                tenantId: tenant.slug,
                eventType,
                timestamp,
                data,
            });
        }

        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), PARTNER_WEBHOOK_TIMEOUT_MS);

        const response = await (async () => {
            try {
                const targetUrl = validation.parsed.toString();
                console.log(`[PartnerWebhook] Dispatching to: ${targetUrl}`, {
                    event: eventType,
                    tenant: tenantId,
                    isRaw: isRawProxy
                });
                
                return await fetch(targetUrl, {
                method: 'POST',
                headers: {
                    'content-type': 'application/json',
                    'x-marketing-os-signature': `sha256=${signed.signature}`,
                    ...(PARTNER_PROXY_SHARED_SECRET ? { 'x-marketing-os-secret': PARTNER_PROXY_SHARED_SECRET } : {}),
                    'x-marketing-os-event': eventType,
                    'x-marketing-os-timestamp': timestamp,
                    'x-partner-tenant-id': tenantId,
                },
                body: signed.payload,
                redirect: 'error',
                signal: controller.signal,
            });
            } finally {
                clearTimeout(timeout);
            }
        })();

        const responseBody = await response.text();

        if (!response.ok) {
            console.warn(
                `[PartnerWebhook] Failed delivery for tenant ${tenantId}. Status: ${response.status}`,
            );
            return { isPartnerTenant: true, dispatchedToWebhook: false, responseBody };
        }
        
        return { isPartnerTenant: true, dispatchedToWebhook: true, responseBody };
    } catch (error) {
        console.warn(
            `[PartnerWebhook] Delivery error for tenant ${tenantId}:`,
            error,
        );
        return { isPartnerTenant: true, dispatchedToWebhook: false };
    }
};

export const getPartnerDashboard = async (partnerId: string) => {
    const partner = await getPartnerOrThrow(partnerId);
    const [recentCustomers, recentWithdrawRequests, pendingWithdrawals] = await Promise.all([
        PartnerCustomerModel.find({ partnerId })
            .sort({ createdAt: -1 })
            .limit(5),
        WithdrawRequestModel.find({ partnerId })
            .sort({ createdAt: -1 })
            .limit(5),
        getPendingWithdrawals(partnerId),
    ]);

    return {
        partner: mapPartnerSummary(partner as IPartner & { id: string }),
        totalCustomers: partner.totalCustomers,
        totalRevenue: partner.totalRevenue,
        walletBalance: partner.walletBalance,
        withdrawableAmount: Math.max(Number((partner.walletBalance - pendingWithdrawals).toFixed(2)), 0),
        pendingWithdrawals,
        recentCustomers: recentCustomers.map(mapCustomer),
        recentWithdrawRequests: recentWithdrawRequests.map(mapWithdrawRequest),
    };
};

export const getPartnerCustomers = async (partnerId: string) => {
    await getPartnerOrThrow(partnerId);

    const customers = await PartnerCustomerModel.find({ partnerId }).sort({ createdAt: -1 });
    return customers.map(mapCustomer);
};

export const getPartnerCommissions = async (partnerId: string) => {
    await getPartnerOrThrow(partnerId);
    return getPartnerCommissionHistory(partnerId);
};

export const createWithdrawRequest = async (partnerId: string, amount: number) => {
    if (!Number.isFinite(amount) || amount <= 0) {
        throw new ValidationError('Withdrawal amount must be greater than zero', {
            amount: ['Provide a valid positive amount'],
        });
    }

    const partner = await getPartnerOrThrow(partnerId);
    const pendingWithdrawals = await getPendingWithdrawals(partnerId);
    const withdrawableAmount = Math.max(Number((partner.walletBalance - pendingWithdrawals).toFixed(2)), 0);

    if (amount > withdrawableAmount) {
        throw new ValidationError('Withdrawal amount exceeds available balance', {
            amount: [`Maximum withdrawable amount is ${withdrawableAmount.toFixed(2)}`],
        });
    }

    const withdrawRequest = await WithdrawRequestModel.create({
        partnerId,
        amount: Number(amount.toFixed(2)),
        status: 'pending',
    });

    return mapWithdrawRequest(withdrawRequest);
};

export const updatePartnerSettings = async (partnerId: string, data: { webhookUrl?: string }) => {
    const partner = await getPartnerOrThrow(partnerId);
    
    // Only update allowed fields
    if (data.webhookUrl !== undefined) {
        const validation = validatePartnerWebhookUrl(data.webhookUrl);
        if (!validation.ok) {
            throw new ValidationError(validation.reason || 'Invalid webhook URL', {
                webhookUrl: [validation.reason || 'Invalid webhook URL'],
            });
        }
        partner.webhookUrl = data.webhookUrl;
    }
    
    await partner.save();
    return mapPartnerSummary(partner as IPartner & { id: string });
};

export const rotatePartnerWebhookSecret = async (partnerId: string) => {
    const partner = await getPartnerOrThrow(partnerId);
    const webhookSecret = `pkwhsec_${uuidv4().replace(/-/g, '')}`;

    (partner as any).webhookSecretEncrypted = encryptSecret(webhookSecret);
    await partner.save();

    return {
        webhookSecret,
        message: 'Store this webhook secret securely. It cannot be retrieved again.',
    };
};

export const rotatePartnerApiKey = async (partnerId: string) => {
    const partner = await getPartnerOrThrow(partnerId);
    const randomPart = uuidv4().replace(/-/g, '');
    const apiKey = `mk_live_${partner.id}_${randomPart}`;
    const apiKeyHash = await bcrypt.hash(apiKey, 12);
    const apiKeyPrefix = randomPart.slice(0, 12);

    partner.apiKeyHash = apiKeyHash;
    (partner as any).apiKeyPrefix = apiKeyPrefix;
    await partner.save();

    return {
        apiKey,
        message: 'Store this API key securely. It cannot be retrieved again.',
    };
};
