import { Router } from 'express';
import { authMiddleware } from '../../middlewares/auth.middleware.js';
import * as partnerController from './partner.controller.js';
import { createTenantRouter } from '../tenant/tenant.routes.js';

export const createPartnerRouter = () => {
    const router = Router();

    router.use(authMiddleware());
    router.get('/dashboard', partnerController.getDashboard);
    router.get('/customers', partnerController.getCustomers);
    router.get('/commissions', partnerController.getCommissions);
    router.post('/withdraw', partnerController.withdraw);
    router.post('/join', partnerController.joinPartner);
    router.put('/settings', partnerController.updateSettings);
    router.post('/settings/webhook-secret/rotate', partnerController.rotateWebhookSecret);
    router.post('/api-key/migrate', partnerController.migrateApiKey);

    // Tenant management for UI (via JWT)
    router.use('/tenants', createTenantRouter());

    return router;
};
