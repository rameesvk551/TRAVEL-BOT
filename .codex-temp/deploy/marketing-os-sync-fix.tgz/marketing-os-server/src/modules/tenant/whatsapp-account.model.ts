import mongoose, { Schema, Document, Types } from 'mongoose';

// ── Phone Number Sub-Document ──

export interface IPhoneNumber {
    phoneNumberId: string;
    displayNumber: string;
    qualityRating?: 'GREEN' | 'YELLOW' | 'RED' | 'UNKNOWN';
    status: 'active' | 'inactive' | 'pending';
    isDefault: boolean;
}

const PhoneNumberSchema = new Schema<IPhoneNumber>(
    {
        phoneNumberId: { type: String, required: true },
        displayNumber: { type: String, required: true },
        qualityRating: {
            type: String,
            enum: ['GREEN', 'YELLOW', 'RED', 'UNKNOWN'],
            default: 'UNKNOWN',
        },
        status: {
            type: String,
            enum: ['active', 'inactive', 'pending'],
            default: 'pending',
        },
        isDefault: { type: Boolean, default: false },
    },
    { _id: true },
);

// ── WhatsApp Account Interface ──

export interface IWhatsAppAccount extends Document {
    tenantId: string;
    partnerId: Types.ObjectId;
    wabaId: string;
    businessName: string;
    accessToken: string;
    credentialSource: 'own' | 'managed';
    status: 'connected' | 'disconnected' | 'pending';
    webhookVerifyToken?: string;
    phoneNumbers: IPhoneNumber[];
    metadata: Record<string, unknown>;
    createdAt: Date;
    updatedAt: Date;
}

// ── Schema Definition ──

const WhatsAppAccountSchema = new Schema<IWhatsAppAccount>(
    {
        tenantId: {
            type: String,
            required: [true, 'Tenant ID is required'],
        },
        partnerId: {
            type: Schema.Types.ObjectId,
            ref: 'Partner',
            required: [true, 'Partner ID is required'],
        },
        wabaId: {
            type: String,
            required: [true, 'WABA ID is required'],
            trim: true,
        },
        businessName: {
            type: String,
            required: [true, 'Business name is required'],
            trim: true,
        },
        accessToken: {
            type: String,
            required: [true, 'Access token is required'],
        },
        credentialSource: {
            type: String,
            enum: ['own', 'managed'],
            default: 'own',
        },
        status: {
            type: String,
            enum: ['connected', 'disconnected', 'pending'],
            default: 'pending',
        },
        webhookVerifyToken: {
            type: String,
        },
        phoneNumbers: {
            type: [PhoneNumberSchema],
            default: [],
        },
        metadata: {
            type: Schema.Types.Mixed,
            default: {},
        },
    },
    {
        timestamps: true,
    },
);

// ── Indexes ──
WhatsAppAccountSchema.index({ tenantId: 1 }, { unique: true });
WhatsAppAccountSchema.index({ partnerId: 1 });
WhatsAppAccountSchema.index({ wabaId: 1 });
WhatsAppAccountSchema.index({ 'phoneNumbers.phoneNumberId': 1 });

export const WhatsAppAccountModel =
    (mongoose.models.WhatsAppAccount as mongoose.Model<IWhatsAppAccount> | undefined) ||
    mongoose.model<IWhatsAppAccount>('WhatsAppAccount', WhatsAppAccountSchema);
