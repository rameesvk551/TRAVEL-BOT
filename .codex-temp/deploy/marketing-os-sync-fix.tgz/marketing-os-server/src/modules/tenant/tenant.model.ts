import mongoose, { Schema, Document, Types } from 'mongoose';

// ── Tenant Interface ──

export interface ITenant extends Document {
    partnerId: Types.ObjectId;
    name: string;
    slug: string;
    email: string;
    phone?: string;
    status: 'active' | 'suspended' | 'pending';
    settings: {
        timezone: string;
        language: string;
        businessType?: string;
    };
    rateLimits: {
        messagesPerMinute: number;
        messagesPerDay: number;
    };
    metadata: Record<string, unknown>;
    createdAt: Date;
    updatedAt: Date;
}

// ── Schema Definition ──

const TenantSchema = new Schema<ITenant>(
    {
        partnerId: {
            type: Schema.Types.ObjectId,
            ref: 'Partner',
            required: [true, 'Partner ID is required'],
            index: true,
        },
        name: {
            type: String,
            required: [true, 'Tenant name is required'],
            trim: true,
        },
        slug: {
            type: String,
            required: [true, 'Tenant slug is required'],
            trim: true,
            lowercase: true,
        },
        email: {
            type: String,
            required: [true, 'Tenant email is required'],
            trim: true,
            lowercase: true,
        },
        phone: {
            type: String,
            trim: true,
        },
        status: {
            type: String,
            enum: ['active', 'suspended', 'pending'],
            default: 'pending',
        },
        settings: {
            timezone: { type: String, default: 'Asia/Kolkata' },
            language: { type: String, default: 'en' },
            businessType: { type: String },
        },
        rateLimits: {
            messagesPerMinute: { type: Number, default: 60 },
            messagesPerDay: { type: Number, default: 10000 },
        },
        metadata: {
            type: Schema.Types.Mixed,
            default: {},
        },
    },
    {
        timestamps: true,
    },
);

// ── Indexes ──
TenantSchema.index({ partnerId: 1, status: 1 });
TenantSchema.index({ slug: 1 }, { unique: true });
TenantSchema.index({ partnerId: 1, createdAt: -1 });
TenantSchema.index({ email: 1 });

export const TenantModel =
    (mongoose.models.Tenant as mongoose.Model<ITenant> | undefined) ||
    mongoose.model<ITenant>('Tenant', TenantSchema);
