import { Router } from 'express';
import { createTenantController } from './tenant.controller.js';

export function createTenantRouter() {
    const router = Router();
    const controller = createTenantController();

    // Tenant CRUD
    router.post('/', controller.create);
    router.get('/', controller.list);
    router.get('/:tenantId', controller.get);
    router.put('/:tenantId', controller.update);
    router.delete('/:tenantId', controller.deactivate);

    // WhatsApp account management
    router.post('/:tenantId/whatsapp', controller.linkWhatsApp);
    router.get('/:tenantId/whatsapp', controller.getWhatsApp);
    router.post('/:tenantId/token', controller.getToken);

    return router;
}
