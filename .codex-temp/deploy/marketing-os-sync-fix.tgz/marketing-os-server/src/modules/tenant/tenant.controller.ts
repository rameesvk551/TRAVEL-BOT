import { Request, Response } from 'express';
import { createTenantService } from './tenant.service.js';
import * as partnerService from '../partner/partner.service.js';
import { generateToken } from '../auth/auth.service.js';
import * as authRepository from '../auth/auth.repository.js';
import { logger } from '../../config/logger.js';
import { TenantModel } from './tenant.model.js';
import { v4 as uuidv4 } from 'uuid';



const tenantService = createTenantService();

/**
 * Tenant management controller — used by partners via API key auth.
 */
export function createTenantController() {
    const resolvePartner = async (req: Request) => {
        // 1. Check if apiKeyMiddleware already attached partner
        if ((req as any).partner) {
            return (req as any).partner;
        }

        // 2. Resolve strictly from authenticated JWT user context
        return partnerService.resolvePartnerContext({
            userId: req.user?.id,
        });
    };

    /**
     * POST /api/v1/tenants
     * Create a new tenant under the authenticated partner.
     */
    async function create(req: Request, res: Response) {
        try {
            const partner = await resolvePartner(req);
            const { name, email, phone, settings, rateLimits, metadata } = req.body;

            if (!name || !email) {
                res.status(400).json({
                    status: 'error',
                    code: 'VALIDATION_ERROR',
                    message: 'name and email are required',
                });
                return;
            }

            // 1. Check if user already exists in Auth system (SQL)
            const existingUser = await authRepository.findUserByEmail(email);
            if (existingUser) {
                res.status(409).json({
                    status: 'error',
                    code: 'USER_ALREADY_EXISTS',
                    message: `A user with email ${email} already exists in the system.`,
                });
                return;
            }

            // 2. Provision in Auth system (SQL)
            // Generate a random password for the new customer
            const crypto = await import('crypto');
            const randomPassword = crypto.randomBytes(8).toString('hex') + '!'; // ~17 chars
            const salt = await (await import('bcryptjs')).default.genSalt(10);
            const passwordHash = await (await import('bcryptjs')).default.hash(randomPassword, salt);

            // Create SQL Tenant first
            const sqlSlug = name.toLowerCase().replace(/[^a-z0-9]/g, '-') + '-' + uuidv4().slice(0, 4);
            const sqlTenant = await authRepository.createTenant({
                name,
                slug: sqlSlug,
                is_active: true
            });

            // Create SQL User
            const sqlUser = await authRepository.createUser({
                tenant_id: sqlTenant.id,
                email,
                password_hash: passwordHash,
                name: name,
                role: 'admin',
                is_active: true
            });

            // 3. Provision in Operational system (MongoDB)
            const tenant = await tenantService.createTenant(partner._id.toString(), {
                name, email, phone, settings, rateLimits, metadata,
            });

            // Sync Partner Customer record
            await partnerService.syncPartnerCustomerFromTenant({
                partnerId: partner._id.toString(),
                tenantId: tenant.slug,
                businessName: tenant.name,
                email: tenant.email,
                plan: 'starter',
            });

            // 4. Send Welcome Email (Stubbed for now, but logs the password)
            console.log(`[PARTNER_PROVISION] Created user for ${email}. Generated password: ${randomPassword}`);
            // TODO: Call mailer here to notify customer of their new account

            res.status(201).json({
                status: 'success',
                data: {
                    id: tenant._id,
                    tenantId: tenant.slug,
                    name: tenant.name,
                    email: tenant.email,
                    status: tenant.status,
                    settings: tenant.settings,
                    createdAt: tenant.createdAt,
                    // We don't return the password in the API for security, 
                    // it is sent via email.
                },
            });
        } catch (error: any) {
            console.error('[TenantController] create error:', error.message);
            res.status(error.message.includes('maximum') ? 429 : 500).json({
                status: 'error',
                message: error.message,
            });
        }
    }


    /**
     * GET /api/v1/tenants
     * List all tenants for the authenticated partner.
     */
    async function list(req: Request, res: Response) {
        try {
            const partner = await resolvePartner(req);
            const { status, search, page, limit } = req.query;

            const result = await tenantService.listTenants(partner._id.toString(), {
                status: status as string,
                search: search as string,
                page: page ? parseInt(page as string) : undefined,
                limit: limit ? parseInt(limit as string) : undefined,
            });

            res.json({ status: 'success', data: result });
        } catch (error: any) {
            console.error('[TenantController] list error:', error.message);
            res.status(500).json({ status: 'error', message: error.message });
        }
    }

    /**
     * GET /api/v1/tenants/:tenantId
     */
    async function get(req: Request, res: Response) {
        try {
            const partner = await resolvePartner(req);
            const tenant = await tenantService.getTenant(partner._id.toString(), req.params.tenantId);

            if (!tenant) {
                res.status(404).json({
                    status: 'error',
                    code: 'TENANT_NOT_FOUND',
                    message: 'Tenant not found',
                });
                return;
            }

            res.json({ status: 'success', data: tenant });
        } catch (error: any) {
            res.status(500).json({ status: 'error', message: error.message });
        }
    }

    /**
     * PUT /api/v1/tenants/:tenantId
     */
    async function update(req: Request, res: Response) {
        try {
            const partner = await resolvePartner(req);
            const updated = await tenantService.updateTenant(
                partner._id.toString(),
                req.params.tenantId,
                req.body,
            );

            if (!updated) {
                res.status(404).json({ status: 'error', message: 'Tenant not found' });
                return;
            }

            await partnerService.syncPartnerCustomerFromTenant({
                partnerId: partner._id.toString(),
                tenantId: updated.slug,
                businessName: updated.name,
                email: updated.email,
                plan: 'starter',
            });

            res.json({ status: 'success', data: updated });
        } catch (error: any) {
            res.status(500).json({ status: 'error', message: error.message });
        }
    }

    /**
     * DELETE /api/v1/tenants/:tenantId  (soft delete = suspend)
     */
    async function deactivate(req: Request, res: Response) {
        try {
            const partner = await resolvePartner(req);
            const updated = await tenantService.updateTenant(
                partner._id.toString(),
                req.params.tenantId,
                { status: 'suspended' },
            );

            if (!updated) {
                res.status(404).json({ status: 'error', message: 'Tenant not found' });
                return;
            }

            res.json({ status: 'success', message: 'Tenant deactivated' });
        } catch (error: any) {
            res.status(500).json({ status: 'error', message: error.message });
        }
    }

    /**
     * POST /api/v1/tenants/:tenantId/whatsapp
     */
    async function linkWhatsApp(req: Request, res: Response) {
        try {
            const partner = await resolvePartner(req);
            const { wabaId, businessName, accessToken, credentialSource, webhookVerifyToken, phoneNumbers } = req.body;

            if (!wabaId || !businessName || !accessToken) {
                res.status(400).json({
                    status: 'error',
                    message: 'wabaId, businessName, and accessToken are required',
                });
                return;
            }

            const account = await tenantService.linkWhatsAppAccount(
                partner._id.toString(),
                req.params.tenantId,
                { wabaId, businessName, accessToken, credentialSource, webhookVerifyToken, phoneNumbers },
            );

            res.status(201).json({ status: 'success', data: account });
        } catch (error: any) {
            res.status(500).json({ status: 'error', message: error.message });
        }
    }

    /**
     * GET /api/v1/tenants/:tenantId/whatsapp
     */
    async function getWhatsApp(req: Request, res: Response) {
        try {
            const account = await tenantService.getWhatsAppAccount(req.params.tenantId);

            if (!account) {
                res.status(404).json({
                    status: 'error',
                    message: 'No WhatsApp account linked to this tenant',
                });
                return;
            }

            // Mask access token
            const masked = {
                ...account,
                accessToken: account.accessToken
                    ? `${account.accessToken.slice(0, 8)}...${account.accessToken.slice(-4)}`
                    : undefined,
            };

            res.json({ status: 'success', data: masked });
        } catch (error: any) {
            res.status(500).json({ status: 'error', message: error.message });
        }
    }

    /**
     * POST /api/v1/tenants/:tenantId/token
     * Generate a JWT token for a tenant (impersonation/partner access).
     */
    async function getToken(req: Request, res: Response) {
        try {
            const partner = await resolvePartner(req);
            const tenantIdOrEmail = req.params.tenantId;

            let tenant;
            if (tenantIdOrEmail.includes('@')) {
                // Lookup by email (ensuring it belongs to the partner)
                tenant = await TenantModel.findOne({
                    partnerId: partner._id,
                    email: tenantIdOrEmail.toLowerCase().trim()
                }).lean();
            } else {
                tenant = await tenantService.getTenant(partner._id.toString(), tenantIdOrEmail);
            }

            if (!tenant) {
                res.status(404).json({
                    status: 'error',
                    code: 'TENANT_NOT_FOUND',
                    message: 'Tenant not found',
                });
                return;
            }

            // Find the user associated with this tenant
            const user = await authRepository.findUserByEmail(tenant.email);
            if (!user) {
                res.status(404).json({
                    status: 'error',
                    code: 'USER_NOT_FOUND',
                    message: 'No user found for this tenant',
                });
                return;
            }

            const token = generateToken(user.id, tenant.slug, user.role);

            // ── Audit Log ──
            logger.info(`[PartnerAuth] Partner ${partner.name} (${partner._id}) generated token for tenant ${tenant.slug} (${tenant.email})`);

            res.json({

                status: 'success',
                data: { token },
            });
        } catch (error: any) {
            console.error('[TenantController] getToken error:', error.message);
            res.status(500).json({ status: 'error', message: error.message });
        }
    }

    /**
     * POST /api/v1/partners/api-key
     */
    async function generateApiKey(req: Request, res: Response) {
        try {
            const partner = await resolvePartner(req);
            const result = await tenantService.generatePartnerApiKey(partner._id.toString());
            res.json({ status: 'success', data: result });
        } catch (error: any) {
            res.status(500).json({ status: 'error', message: error.message });
        }
    }

    return { create, list, get, update, deactivate, linkWhatsApp, getWhatsApp, generateApiKey, getToken };
}


