import { Types } from 'mongoose';
import bcrypt from 'bcryptjs';
import { v4 as uuidv4 } from 'uuid';
import { TenantModel, ITenant } from './tenant.model.js';
import { WhatsAppAccountModel } from './whatsapp-account.model.js';
import { PartnerModel } from '../partner/partner.model.js';

// ── Tenant Service ──

export function createTenantService() {
    /**
     * Create a new tenant under a partner.
     */
    async function createTenant(partnerId: string, data: {
        name: string;
        email: string;
        phone?: string;
        settings?: Partial<ITenant['settings']>;
        rateLimits?: Partial<ITenant['rateLimits']>;
        metadata?: Record<string, unknown>;
    }) {
        // Generate unique slug from name
        const baseSlug = data.name
            .toLowerCase()
            .replace(/[^a-z0-9]+/g, '-')
            .replace(/^-|-$/g, '');
        const slug = `${baseSlug}-${uuidv4().slice(0, 8)}`;

        // Check partner tenant limit
        const partner = await PartnerModel.findById(partnerId).lean();
        if (!partner) throw new Error('Partner not found');

        const tenantCount = await TenantModel.countDocuments({ partnerId: new Types.ObjectId(partnerId) });
        const maxTenants = partner.settings?.maxTenants || 100;
        if (tenantCount >= maxTenants) {
            throw new Error(`Partner has reached the maximum number of tenants (${maxTenants})`);
        }

        const tenant = await TenantModel.create({
            partnerId: new Types.ObjectId(partnerId),
            name: data.name,
            slug,
            email: data.email,
            phone: data.phone,
            status: 'active',
            settings: {
                timezone: data.settings?.timezone || partner.settings?.defaultTimezone || 'Asia/Kolkata',
                language: data.settings?.language || partner.settings?.defaultLanguage || 'en',
                businessType: data.settings?.businessType,
            },
            rateLimits: {
                messagesPerMinute: data.rateLimits?.messagesPerMinute || 60,
                messagesPerDay: data.rateLimits?.messagesPerDay || 10000,
            },
            metadata: data.metadata || {},
        });

        // Increment partner customer count
        await PartnerModel.findByIdAndUpdate(partnerId, {
            $inc: { totalCustomers: 1 },
        });

        return tenant;
    }

    /**
     * List all tenants for a partner.
     */
    async function listTenants(partnerId: string, filters: {
        status?: string;
        search?: string;
        page?: number;
        limit?: number;
    } = {}) {
        const query: any = { partnerId: new Types.ObjectId(partnerId) };

        if (filters.status) query.status = filters.status;
        if (filters.search) {
            query.$or = [
                { name: { $regex: filters.search, $options: 'i' } },
                { email: { $regex: filters.search, $options: 'i' } },
                { slug: { $regex: filters.search, $options: 'i' } },
            ];
        }

        const page = filters.page || 1;
        const limit = filters.limit || 20;
        const skip = (page - 1) * limit;

        const [tenants, total] = await Promise.all([
            TenantModel.find(query).sort({ createdAt: -1 }).skip(skip).limit(limit).lean(),
            TenantModel.countDocuments(query),
        ]);

        return { tenants, total, page, limit, pages: Math.ceil(total / limit) };
    }

    /**
     * Get a single tenant by ID or slug.
     */
    async function getTenant(partnerId: string, tenantIdOrSlug: string) {
        const query: any = { partnerId: new Types.ObjectId(partnerId) };

        if (Types.ObjectId.isValid(tenantIdOrSlug)) {
            query._id = new Types.ObjectId(tenantIdOrSlug);
        } else {
            query.slug = tenantIdOrSlug;
        }

        return TenantModel.findOne(query).lean();
    }

    /**
     * Update a tenant.
     */
    async function updateTenant(partnerId: string, tenantIdOrSlug: string, updates: {
        name?: string;
        email?: string;
        phone?: string;
        status?: 'active' | 'suspended' | 'pending';
        settings?: Partial<ITenant['settings']>;
        rateLimits?: Partial<ITenant['rateLimits']>;
        metadata?: Record<string, unknown>;
    }) {
        const query: any = { partnerId: new Types.ObjectId(partnerId) };
        if (Types.ObjectId.isValid(tenantIdOrSlug)) {
            query._id = new Types.ObjectId(tenantIdOrSlug);
        } else {
            query.slug = tenantIdOrSlug;
        }

        const updateDoc: any = {};
        if (updates.name) updateDoc.name = updates.name;
        if (updates.email) updateDoc.email = updates.email;
        if (updates.phone !== undefined) updateDoc.phone = updates.phone;
        if (updates.status) updateDoc.status = updates.status;
        if (updates.metadata) updateDoc.metadata = updates.metadata;

        if (updates.settings) {
            for (const [key, val] of Object.entries(updates.settings)) {
                updateDoc[`settings.${key}`] = val;
            }
        }
        if (updates.rateLimits) {
            for (const [key, val] of Object.entries(updates.rateLimits)) {
                updateDoc[`rateLimits.${key}`] = val;
            }
        }

        return TenantModel.findOneAndUpdate(query, { $set: updateDoc }, { returnDocument: 'after' }).lean();
    }

    /**
     * Link a WhatsApp Business Account to a tenant.
     */
    async function linkWhatsAppAccount(partnerId: string, tenantSlug: string, data: {
        wabaId: string;
        businessName: string;
        accessToken: string;
        credentialSource: 'own' | 'managed';
        webhookVerifyToken?: string;
        phoneNumbers?: Array<{ phoneNumberId: string; displayNumber: string }>;
    }) {
        const existing = await WhatsAppAccountModel.findOne({ tenantId: tenantSlug }).lean();
        if (existing) {
            // Update existing
            return WhatsAppAccountModel.findOneAndUpdate(
                { tenantId: tenantSlug },
                {
                    $set: {
                        wabaId: data.wabaId,
                        businessName: data.businessName,
                        accessToken: data.accessToken,
                        credentialSource: data.credentialSource,
                        webhookVerifyToken: data.webhookVerifyToken,
                        status: 'connected',
                        phoneNumbers: (data.phoneNumbers || []).map((p, i) => ({
                            phoneNumberId: p.phoneNumberId,
                            displayNumber: p.displayNumber,
                            qualityRating: 'UNKNOWN' as const,
                            status: 'active' as const,
                            isDefault: i === 0,
                        })),
                    },
                },
                { returnDocument: 'after' },
            ).lean();
        }

        return WhatsAppAccountModel.create({
            tenantId: tenantSlug,
            partnerId: new Types.ObjectId(partnerId),
            wabaId: data.wabaId,
            businessName: data.businessName,
            accessToken: data.accessToken,
            credentialSource: data.credentialSource,
            webhookVerifyToken: data.webhookVerifyToken,
            status: 'connected',
            phoneNumbers: (data.phoneNumbers || []).map((p, i) => ({
                phoneNumberId: p.phoneNumberId,
                displayNumber: p.displayNumber,
                qualityRating: 'UNKNOWN' as const,
                status: 'active' as const,
                isDefault: i === 0,
            })),
        });
    }

    /**
     * Get WhatsApp config for a tenant.
     */
    async function getWhatsAppAccount(tenantSlug: string) {
        return WhatsAppAccountModel.findOne({ tenantId: tenantSlug }).lean();
    }

    /**
     * Generate an API key for a partner.
     */
    async function generatePartnerApiKey(partnerId: string) {
        const randomPart = uuidv4().replace(/-/g, '');
        const apiKey = `mk_live_${partnerId}_${randomPart}`;
        const apiKeyHash = await bcrypt.hash(apiKey, 12);
        const apiKeyPrefix = randomPart.slice(0, 12);

        await PartnerModel.findByIdAndUpdate(partnerId, {
            $set: { apiKeyHash, apiKeyPrefix },
        });

        // Return the raw key — it cannot be retrieved again
        return { apiKey, message: 'Store this key securely. It cannot be retrieved again.' };
    }

    return {
        createTenant,
        listTenants,
        getTenant,
        updateTenant,
        linkWhatsAppAccount,
        getWhatsAppAccount,
        generatePartnerApiKey,
    };
}
