import { Worker, Job } from 'bullmq';
import Bottleneck from 'bottleneck';
import { config } from '../../config/env.js';
import { MessageLogModel } from './message-log.model.js';
import { BillingUsageModel } from '../billing/billing-usage.model.js';
import { WhatsAppAccountModel } from '../tenant/whatsapp-account.model.js';
import { QUEUE_NAME, MessageJobData, moveToDeadLetter } from './message.queue.js';
import { createMetaCloudProvider } from '../whatsapp/providers/MetaCloudProvider.js';

/**
 * Per-tenant rate limiters using Bottleneck.
 * Limits are loaded from tenant config, default 60/min.
 */
const tenantLimiters = new Map<string, Bottleneck>();

function getLimiter(tenantId: string, messagesPerMinute: number = 60): Bottleneck {
    if (!tenantLimiters.has(tenantId)) {
        tenantLimiters.set(tenantId, new Bottleneck({
            reservoir: messagesPerMinute,
            reservoirRefreshAmount: messagesPerMinute,
            reservoirRefreshInterval: 60_000,
            maxConcurrent: 5,
            minTime: Math.ceil(60_000 / messagesPerMinute),
        }));
    }
    return tenantLimiters.get(tenantId)!;
}

/**
 * Resolve WhatsApp credentials for a tenant from MongoDB WhatsAppAccount.
 */
async function resolveCredentials(tenantId: string) {
    const account = await WhatsAppAccountModel.findOne({
        tenantId,
        status: 'connected',
    }).lean();

    if (!account) {
        throw new Error(`No connected WhatsApp account for tenant: ${tenantId}`);
    }

    const defaultPhone = account.phoneNumbers.find(p => p.isDefault) || account.phoneNumbers[0];
    if (!defaultPhone) {
        throw new Error(`No phone numbers configured for tenant: ${tenantId}`);
    }

    return {
        accessToken: account.accessToken,
        phoneNumberId: defaultPhone.phoneNumberId,
        businessAccountId: account.wabaId,
    };
}

/**
 * Send a template message via Meta Cloud API.
 */
async function sendTemplateMessage(
    credentials: { accessToken: string; phoneNumberId: string; businessAccountId: string },
    to: string,
    templateName: string,
    languageCode: string,
    variables: Record<string, string>,
): Promise<string> {
    const provider = createMetaCloudProvider({
        accessToken: credentials.accessToken,
        phoneNumberId: credentials.phoneNumberId,
        businessAccountId: credentials.businessAccountId,
        webhookVerifyToken: '',
        apiVersion: 'v19.0',
    });

    const components = Object.values(variables).length > 0
        ? [{
            type: 'body' as const,
            parameters: Object.values(variables).map(val => ({
                type: 'text' as const,
                value: val,
            })),
        }]
        : [];

    const result = await provider.sendTemplate(to, templateName, languageCode, components);
    if (!result.success) {
        throw new Error(result.errorMessage || 'WhatsApp API: template send failed');
    }
    return result.providerMessageId!;
}

/**
 * Send a text message via Meta Cloud API.
 */
async function sendTextMessage(
    credentials: { accessToken: string; phoneNumberId: string; businessAccountId: string },
    to: string,
    text: string,
): Promise<string> {
    const provider = createMetaCloudProvider({
        accessToken: credentials.accessToken,
        phoneNumberId: credentials.phoneNumberId,
        businessAccountId: credentials.businessAccountId,
        webhookVerifyToken: '',
        apiVersion: 'v19.0',
    });

    const result = await provider.sendMessage({
        recipientPhone: to,
        messageType: 'TEXT',
        textContent: { body: text },
    });
    if (!result.success) {
        throw new Error(result.errorMessage || 'WhatsApp API: text send failed');
    }
    return result.providerMessageId!;
}

/**
 * Process a message job from the queue.
 */
async function processMessageJob(job: Job<MessageJobData>): Promise<void> {
    const data = job.data;
    const { messageLogId, tenantId, to, type, templateName, languageCode, variables, text } = data;

    console.log(`[MessageWorker] Processing job ${job.id} for tenant ${tenantId}: ${type} → ${to}`);

    // Update message log to processing
    await MessageLogModel.findOneAndUpdate(
        { messageId: messageLogId },
        { $set: { status: 'processing', processedAt: new Date() } },
    );

    try {
        // 1. Resolve credentials
        const credentials = await resolveCredentials(tenantId);

        // 2. Rate limit through Bottleneck
        const limiter = getLimiter(tenantId);
        const externalMessageId = await limiter.schedule(async () => {
            // 3. Send message based on type
            switch (type) {
                case 'template':
                    return sendTemplateMessage(
                        credentials,
                        to,
                        templateName!,
                        languageCode || 'en',
                        variables || {},
                    );
                case 'text':
                    return sendTextMessage(credentials, to, text!);
                default:
                    throw new Error(`Unsupported message type: ${type}`);
            }
        });

        // 4. Update message log to sent
        await MessageLogModel.findOneAndUpdate(
            { messageId: messageLogId },
            {
                $set: {
                    status: 'sent',
                    externalMessageId,
                    sentAt: new Date(),
                },
            },
        );

        // 5. Track billing usage
        const period = new Date().toISOString().slice(0, 7); // "2026-03"
        const categoryField = type === 'template' ? 'templateMessages' : 'sessionMessages';

        await BillingUsageModel.findOneAndUpdate(
            { tenantId, period },
            {
                $inc: {
                    [categoryField]: 1,
                    totalMessages: 1,
                },
                $setOnInsert: {
                    partnerId: data.partnerId,
                },
            },
            { upsert: true },
        );

        console.log(`[MessageWorker] Job ${job.id} sent successfully: ${externalMessageId}`);
    } catch (error: any) {
        console.error(`[MessageWorker] Job ${job.id} failed (attempt ${job.attemptsMade + 1}/${job.opts.attempts}):`, error.message);

        // Update retry count
        await MessageLogModel.findOneAndUpdate(
            { messageId: messageLogId },
            {
                $set: {
                    error: error.message,
                    retryCount: job.attemptsMade + 1,
                },
            },
        );

        // If max retries exhausted, move to DLQ
        if (job.attemptsMade + 1 >= (job.opts.attempts || 3)) {
            await MessageLogModel.findOneAndUpdate(
                { messageId: messageLogId },
                { $set: { status: 'dlq', failedAt: new Date() } },
            );
            await moveToDeadLetter(data, error.message);
            console.error(`[MessageWorker] Job ${job.id} moved to DLQ after ${job.attemptsMade + 1} attempts`);
        } else {
            await MessageLogModel.findOneAndUpdate(
                { messageId: messageLogId },
                { $set: { status: 'queued' } },
            );
        }

        throw error; // Let BullMQ handle retry
    }
}

/**
 * Start the message worker.
 */
export function startMessageWorker(concurrency: number = 10): Worker<MessageJobData> {
    const connection = {
        host: config.redis.host,
        port: config.redis.port,
        maxRetriesPerRequest: null as unknown as number,
    };

    const worker = new Worker<MessageJobData>(
        QUEUE_NAME,
        processMessageJob,
        {
            connection,
            concurrency,
            limiter: {
                max: 100,
                duration: 1000,  // Global: 100 jobs/sec across all tenants
            },
        },
    );

    worker.on('completed', (job) => {
        console.log(`[MessageWorker] Job ${job.id} completed`);
    });

    worker.on('failed', (job, err) => {
        console.error(`[MessageWorker] Job ${job?.id} failed:`, err.message);
    });

    worker.on('error', (err) => {
        console.error('[MessageWorker] Worker error:', err);
    });

    console.log(`[MessageWorker] Started with concurrency=${concurrency}`);
    return worker;
}
