import { Request, Response } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { MessageLogModel } from './message-log.model.js';
import { enqueueMessage, MessageJobData } from './message.queue.js';

/**
 * Messaging controller — partner-facing API for sending WhatsApp messages.
 */
export function createMessagingController() {

    /**
     * POST /api/v1/messages/send
     *
     * Accepts a message payload, validates it, creates a MessageLog entry,
     * enqueues the job, and returns an async response with the messageId.
     */
    async function send(req: Request, res: Response) {
        try {
            const partner = (req as any).partner;
            const tenant = (req as any).tenant;

            const { to, type, templateName, languageCode, variables, text, interactiveContent, metadata } = req.body;

            // ── Validation ──
            if (!to) {
                res.status(400).json({ status: 'error', code: 'VALIDATION_ERROR', message: '`to` (phone number) is required' });
                return;
            }
            if (!type || !['template', 'text', 'interactive'].includes(type)) {
                res.status(400).json({ status: 'error', code: 'VALIDATION_ERROR', message: '`type` must be one of: template, text, interactive' });
                return;
            }
            if (type === 'template' && !templateName) {
                res.status(400).json({ status: 'error', code: 'VALIDATION_ERROR', message: '`templateName` is required for template messages' });
                return;
            }
            if (type === 'text' && !text) {
                res.status(400).json({ status: 'error', code: 'VALIDATION_ERROR', message: '`text` is required for text messages' });
                return;
            }

            // ── Create idempotency key ──
            const idempotencyKey = req.headers['x-idempotency-key'] as string || `${tenant.slug}-${to}-${Date.now()}`;

            // Check for duplicate
            const existing = await MessageLogModel.findOne({ idempotencyKey }).lean();
            if (existing) {
                res.status(200).json({
                    status: 'success',
                    data: {
                        messageId: existing.messageId,
                        status: existing.status,
                        message: 'Duplicate request — returning existing message',
                    },
                });
                return;
            }

            // ── Create MessageLog ──
            const messageId = uuidv4();
            await MessageLogModel.create({
                tenantId: tenant.slug,
                partnerId: partner._id,
                messageId,
                to,
                type,
                templateName,
                status: 'queued',
                variables,
                metadata: metadata || {},
                retryCount: 0,
                maxRetries: 3,
                idempotencyKey,
                queuedAt: new Date(),
            });

            // ── Enqueue job ──
            const jobData: MessageJobData = {
                messageLogId: messageId,
                tenantId: tenant.slug,
                partnerId: partner._id.toString(),
                to,
                type,
                templateName,
                languageCode: languageCode || 'en',
                variables,
                text,
                interactiveContent,
                metadata,
            };

            await enqueueMessage(jobData);

            // ── Return async response ──
            res.status(202).json({
                status: 'success',
                data: {
                    messageId,
                    status: 'queued',
                    message: 'Message queued for delivery',
                },
            });
        } catch (error: any) {
            console.error('[MessagingController] send error:', error.message);
            res.status(500).json({ status: 'error', message: error.message });
        }
    }

    /**
     * POST /api/v1/messages/instagram/send
     *
     * Partner-facing Instagram DM sender. Uses tenant ownership validation from
     * the router, then delegates to the Instagram inbox service.
     */
    async function sendInstagram(req: Request, res: Response) {
        try {
            const tenant = (req as any).tenant;
            const tenantId = tenant?.slug || (req as any).context?.tenantId;
            const { accountId: requestedAccountId, recipientId, text } = req.body;

            if (!tenantId) {
                res.status(401).json({ status: 'error', code: 'TENANT_REQUIRED', message: 'Tenant required' });
                return;
            }

            if (!recipientId || !text) {
                res.status(400).json({
                    status: 'error',
                    code: 'VALIDATION_ERROR',
                    message: 'recipientId and text are required',
                });
                return;
            }

            const { getPool } = await import('../../config/database.js');
            const { getConfig } = await import('../../config/index.js');
            const { createInstagramAccountRepo } = await import('../instagram/repositories/InstagramAccountRepo.js');
            const { createInstagramCommentRepo } = await import('../instagram/repositories/InstagramCommentRepo.js');
            const { createInstagramMessageRepo } = await import('../instagram/repositories/InstagramMessageRepo.js');
            const { createInboxService } = await import('../instagram/services/InboxService.js');
            const { createInstagramGraphApiProvider } = await import('../instagram/providers/InstagramGraphApiProvider.js');

            const pool = getPool();
            const accountRepo = createInstagramAccountRepo(pool);
            const commentRepo = createInstagramCommentRepo(pool);
            const messageRepo = createInstagramMessageRepo(pool);

            let accountId = requestedAccountId;
            if (!accountId) {
                const accounts = await accountRepo.findByTenant(tenantId);
                accountId = accounts[0]?.id;
            }

            if (!accountId) {
                res.status(400).json({
                    status: 'error',
                    code: 'INSTAGRAM_ACCOUNT_REQUIRED',
                    message: 'accountId is required or no Instagram account is connected for this tenant',
                });
                return;
            }

            const config = getConfig();
            const igConfig = config.instagram;
            const apiVersion = (igConfig as any).apiVersion || 'v19.0';
            const createProvider = (accessToken: string, igUserId: string) => createInstagramGraphApiProvider({
                accessToken,
                igUserId,
                apiVersion,
            });

            const inboxService = createInboxService(commentRepo, messageRepo, accountRepo, createProvider);
            await inboxService.sendMessage(tenantId, accountId, recipientId, text);

            res.status(202).json({
                status: 'success',
                data: {
                    status: 'sent',
                    accountId,
                    recipientId,
                },
            });
        } catch (error: any) {
            console.error('[MessagingController] sendInstagram error:', error.message);
            res.status(500).json({ status: 'error', message: error.message });
        }
    }

    /**
     * GET /api/v1/messages/:messageId/status
     */
    async function getStatus(req: Request, res: Response) {
        try {
            const tenant = (req as any).tenant;
            const { messageId } = req.params;

            const log = await MessageLogModel.findOne({
                messageId,
                tenantId: tenant.slug,
            }).lean();

            if (!log) {
                res.status(404).json({ status: 'error', message: 'Message not found' });
                return;
            }

            res.json({
                status: 'success',
                data: {
                    messageId: log.messageId,
                    to: log.to,
                    type: log.type,
                    status: log.status,
                    externalMessageId: log.externalMessageId,
                    error: log.error,
                    retryCount: log.retryCount,
                    queuedAt: log.queuedAt,
                    sentAt: log.sentAt,
                    deliveredAt: log.deliveredAt,
                    failedAt: log.failedAt,
                },
            });
        } catch (error: any) {
            res.status(500).json({ status: 'error', message: error.message });
        }
    }

    /**
     * GET /api/v1/messages
     * List messages for a tenant with pagination.
     */
    async function list(req: Request, res: Response) {
        try {
            const tenant = (req as any).tenant;
            const { status: filterStatus, page = '1', limit = '20' } = req.query;

            const query: any = { tenantId: tenant.slug };
            if (filterStatus) query.status = filterStatus;

            const pageNum = parseInt(page as string);
            const limitNum = parseInt(limit as string);
            const skip = (pageNum - 1) * limitNum;

            const [messages, total] = await Promise.all([
                MessageLogModel.find(query).sort({ createdAt: -1 }).skip(skip).limit(limitNum).lean(),
                MessageLogModel.countDocuments(query),
            ]);

            res.json({
                status: 'success',
                data: { messages, total, page: pageNum, limit: limitNum, pages: Math.ceil(total / limitNum) },
            });
        } catch (error: any) {
            res.status(500).json({ status: 'error', message: error.message });
        }
    }

    return { send, sendInstagram, getStatus, list };
}
