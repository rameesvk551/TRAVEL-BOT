import mongoose, { Schema, Document, Types } from 'mongoose';

// ── Message Log Interface ──

export interface IMessageLog extends Document {
    tenantId: string;
    partnerId: Types.ObjectId;
    messageId: string;
    externalMessageId?: string;
    to: string;
    type: 'template' | 'text' | 'interactive';
    templateName?: string;
    status: 'queued' | 'processing' | 'sent' | 'delivered' | 'read' | 'failed' | 'dlq';
    metadata: Record<string, unknown>;
    variables?: Record<string, string>;
    retryCount: number;
    maxRetries: number;
    error?: string;
    errorCode?: string;
    idempotencyKey: string;
    queuedAt: Date;
    processedAt?: Date;
    sentAt?: Date;
    deliveredAt?: Date;
    failedAt?: Date;
    createdAt: Date;
    updatedAt: Date;
}

// ── Schema Definition ──

const MessageLogSchema = new Schema<IMessageLog>(
    {
        tenantId: {
            type: String,
            required: [true, 'Tenant ID is required'],
            index: true,
        },
        partnerId: {
            type: Schema.Types.ObjectId,
            ref: 'Partner',
            required: [true, 'Partner ID is required'],
            index: true,
        },
        messageId: {
            type: String,
            required: true,
            unique: true,
        },
        externalMessageId: {
            type: String,
        },
        to: {
            type: String,
            required: [true, 'Recipient phone number is required'],
        },
        type: {
            type: String,
            enum: ['template', 'text', 'interactive'],
            required: true,
        },
        templateName: {
            type: String,
            trim: true,
        },
        status: {
            type: String,
            enum: ['queued', 'processing', 'sent', 'delivered', 'read', 'failed', 'dlq'],
            default: 'queued',
        },
        metadata: {
            type: Schema.Types.Mixed,
            default: {},
        },
        variables: {
            type: Schema.Types.Mixed,
        },
        retryCount: {
            type: Number,
            default: 0,
        },
        maxRetries: {
            type: Number,
            default: 3,
        },
        error: String,
        errorCode: String,
        idempotencyKey: {
            type: String,
            required: true,
        },
        queuedAt: {
            type: Date,
            default: Date.now,
        },
        processedAt: Date,
        sentAt: Date,
        deliveredAt: Date,
        failedAt: Date,
    },
    {
        timestamps: true,
    },
);

// ── Indexes ──
MessageLogSchema.index({ tenantId: 1, status: 1 });
MessageLogSchema.index({ tenantId: 1, createdAt: -1 });
MessageLogSchema.index({ partnerId: 1, createdAt: -1 });
MessageLogSchema.index({ idempotencyKey: 1 }, { unique: true });
MessageLogSchema.index({ externalMessageId: 1 }, { sparse: true });
MessageLogSchema.index({ status: 1, retryCount: 1 });

export const MessageLogModel =
    (mongoose.models.MessageLog as mongoose.Model<IMessageLog> | undefined) ||
    mongoose.model<IMessageLog>('MessageLog', MessageLogSchema);
