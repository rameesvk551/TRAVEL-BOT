import { Queue, QueueEvents } from 'bullmq';
import { config } from '../../config/env.js';

// Build connection options for BullMQ (avoids type incompatibility with ioredis client)
const getConnectionOpts = () => ({
    host: config.redis.host,
    port: config.redis.port,
    maxRetriesPerRequest: null as unknown as number,
});

/**
 * BullMQ queue for async WhatsApp message processing.
 *
 * Job data shape:
 * {
 *   messageLogId: string;
 *   tenantId: string;
 *   partnerId: string;
 *   to: string;
 *   type: 'template' | 'text' | 'interactive';
 *   templateName?: string;
 *   languageCode?: string;
 *   variables?: Record<string, string>;
 *   text?: string;
 *   metadata?: Record<string, any>;
 * }
 */

const QUEUE_NAME = 'whatsapp-messages';
const DLQ_NAME = 'whatsapp-messages-dlq';

let messageQueue: Queue | null = null;
let deadLetterQueue: Queue | null = null;
let queueEvents: QueueEvents | null = null;

export interface MessageJobData {
    messageLogId: string;
    tenantId: string;
    partnerId: string;
    to: string;
    type: 'template' | 'text' | 'interactive';
    templateName?: string;
    languageCode?: string;
    variables?: Record<string, string>;
    text?: string;
    interactiveContent?: any;
    metadata?: Record<string, any>;
}

/**
 * Get or create the message queue singleton.
 */
export function getMessageQueue(): Queue<MessageJobData> {
    if (!messageQueue) {
        const connection = getConnectionOpts();
        messageQueue = new Queue<MessageJobData>(QUEUE_NAME, {
            connection,
            defaultJobOptions: {
                attempts: 3,
                backoff: {
                    type: 'exponential',
                    delay: 2000,  // 2s, 4s, 8s
                },
                removeOnComplete: {
                    age: 86400,    // keep completed for 24h
                    count: 10000,
                },
                removeOnFail: false,  // keep failures for inspection
            },
        });
    }
    return messageQueue as Queue<MessageJobData>;
}

/**
 * Get or create the dead letter queue.
 */
export function getDeadLetterQueue(): Queue<MessageJobData> {
    if (!deadLetterQueue) {
        const connection = getConnectionOpts();
        deadLetterQueue = new Queue<MessageJobData>(DLQ_NAME, {
            connection,
            defaultJobOptions: {
                removeOnComplete: false,
                removeOnFail: false,
            },
        });
    }
    return deadLetterQueue as Queue<MessageJobData>;
}

/**
 * Get QueueEvents for monitoring.
 */
export function getQueueEvents(): QueueEvents {
    if (!queueEvents) {
        const connection = getConnectionOpts();
        queueEvents = new QueueEvents(QUEUE_NAME, { connection });
    }
    return queueEvents;
}

/**
 * Add a message job to the queue.
 */
export async function enqueueMessage(data: MessageJobData, priority: number = 0): Promise<string> {
    const queue = getMessageQueue();
    const job = await queue.add('send-message', data, {
        priority,
        // Group by tenantId for per-tenant rate limiting
        // BullMQ Pro has rate limiting built in; for OSS we use Bottleneck in worker
    });
    return job.id!;
}

/**
 * Move a failed job to the dead letter queue.
 */
export async function moveToDeadLetter(data: MessageJobData, error: string): Promise<void> {
    const dlq = getDeadLetterQueue();
    await dlq.add('dead-letter', {
        ...data,
        metadata: {
            ...data.metadata,
            dlqReason: error,
            movedAt: new Date().toISOString(),
        },
    });
}

export { QUEUE_NAME, DLQ_NAME };
