import { Router } from 'express';
import { createMessagingController } from './messaging.controller.js';
import { validateTenantOwnership } from '../../middlewares/rbac.middleware.js';

export function createMessagingRouter() {
    const router = Router();
    const controller = createMessagingController();

    // All messaging routes require tenant ownership validation
    router.use(validateTenantOwnership());

    router.post('/send', controller.send);
    router.post('/instagram/send', controller.sendInstagram);
    router.get('/', controller.list);
    router.get('/:messageId/status', controller.getStatus);

    return router;
}
