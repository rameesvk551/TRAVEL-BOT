// WhatsAppPaymentService.ts
// Handles WhatsApp native Payments API — order_details and order_status messages
// Supports Razorpay Payment Gateway Deep Integration per-tenant

import type { Pool } from 'pg';

export interface PaymentConfig {
    enabled: boolean;
    cod_enabled: boolean;
    online_enabled: boolean;
    provider: 'razorpay' | 'payu' | 'zaakpay' | 'billdesk';
    razorpay_payment_config_name?: string;
    payu_payment_config_name?: string;
    zaakpay_payment_config_name?: string;
    billdesk_payment_config_name?: string;
    business_name?: string;
    country_of_origin?: string;
    importer_name?: string;
    importer_address?: {
        address_line1: string;
        address_line2?: string;
        city: string;
        zone_code: string;
        postal_code: string;
        country_code: string;
    };
}

export interface OrderItem {
    product?: string;
    productName: string;
    quantity: number;
    price: number;
    sku?: string;
    imageUrl?: string;
}

export interface OrderDetailsOptions {
    recipientPhone: string;
    referenceId: string;           // orderId — unique per order
    items: OrderItem[];
    subtotal: number;
    tax?: number;
    shipping?: number;
    discount?: number;
    totalAmount: number;
    bodyText?: string;
    footerText?: string;
    expirationSeconds?: number;    // optional expiry for payment
    catalogId?: string;            // if using Meta catalog
    preferredPaymentMethods?: string[]; // e.g. ["gpay", "phonepe"]
    enabledPaymentOptions?: ('upi' | 'web')[];
}

export function createWhatsAppPaymentService(pool: Pool) {

    /**
     * Get payment config for a tenant
     */
    async function getPaymentConfig(tenantId: string): Promise<PaymentConfig | null> {
        try {
            const result = await pool.query(
                `SELECT payment_config FROM whatsapp_business_configs WHERE tenant_id = $1 AND status = 'connected' LIMIT 1`,
                [tenantId]
            );
            if (result.rows.length === 0) return null;
            const config = result.rows[0].payment_config;
            if (!config || !config.enabled) return null;
            return config as PaymentConfig;
        } catch (err) {
            console.error('[PaymentService] Failed to get payment config:', err);
            return null;
        }
    }

    /**
     * Get WhatsApp API credentials for a tenant
     */
    async function getWaCredentials(tenantId: string) {
        const result = await pool.query(
            `SELECT phone_number_id, access_token, waba_id, catalog_id FROM whatsapp_business_configs WHERE tenant_id = $1 AND status = 'connected' LIMIT 1`,
            [tenantId]
        );
        if (result.rows.length === 0) throw new Error('No WhatsApp config found for tenant');
        return result.rows[0];
    }

    /**
     * Send order_details interactive message (native WhatsApp invoice with payment)
     */
    async function sendOrderDetailsMessage(tenantId: string, options: OrderDetailsOptions): Promise<any> {
        const paymentConfig = await getPaymentConfig(tenantId);
        if (!paymentConfig || !paymentConfig.online_enabled) {
            throw new Error('Online payments not configured for this tenant');
        }

        const creds = await getWaCredentials(tenantId);
        const apiVersion = process.env.WHATSAPP_API_VERSION || 'v24.0';

        // Build items array
        const items = options.items.map(item => {
            const itemObj: any = {
                name: item.productName.substring(0, 60),  // max 60 chars
                amount: {
                    value: Math.round(item.price * 100),   // offset 100
                    offset: 100,
                },
                quantity: item.quantity,
            };

            // If using catalog, include retailer_id
            if (options.catalogId && item.sku) {
                itemObj.retailer_id = item.sku;
            } else {
                // Non-catalog: compliance fields required
                itemObj.country_of_origin = paymentConfig.country_of_origin || 'India';
                itemObj.importer_name = paymentConfig.importer_name || paymentConfig.business_name || 'Business';
                itemObj.importer_address = paymentConfig.importer_address || {
                    address_line1: 'Not specified',
                    city: 'Not specified',
                    zone_code: 'KL',
                    postal_code: '000000',
                    country_code: 'IN',
                };
            }

            return itemObj;
        });

        // Build order object
        const order: any = {
            status: 'pending',
            items,
            subtotal: {
                value: Math.round(options.subtotal * 100),
                offset: 100,
            },
            tax: {
                value: Math.round((options.tax || 0) * 100),
                offset: 100,
            },
        };

        if (options.shipping !== undefined) {
            order.shipping = {
                value: Math.round(options.shipping * 100),
                offset: 100,
                description: 'Shipping',
            };
        }

        if (options.discount !== undefined && options.discount > 0) {
            order.discount = {
                value: Math.round(options.discount * 100),
                offset: 100,
                description: 'Discount',
            };
        }

        if (options.catalogId) {
            order.catalog_id = options.catalogId;
        }

        if (options.expirationSeconds) {
            order.expiration = {
                timestamp: String(Math.floor(Date.now() / 1000) + options.expirationSeconds),
                description: `Payment expires in ${Math.round(options.expirationSeconds / 60)} minutes`,
            };
        }

        // Build payment_settings based on provider
        const paymentSettings: any[] = [];
        const pgType = paymentConfig.provider;
        const configName = (paymentConfig as any)[`${pgType}_payment_config_name`];

        if (configName) {
            const pgData: any = {
                type: 'payment_gateway',
                payment_gateway: {
                    type: pgType,
                    configuration_name: configName,
                }
            };

            // Add PG specific fields
            if (pgType === 'razorpay') {
                pgData.payment_gateway.razorpay = {
                    receipt: options.referenceId,
                    notes: {
                        order_id: options.referenceId,
                        tenant_id: tenantId,
                    },
                };
            } else if (pgType === 'payu') {
                pgData.payment_gateway.payu = {
                    udf1: options.referenceId,
                    udf2: tenantId,
                };
            } else if (pgType === 'zaakpay') {
                pgData.payment_gateway.zaakpay = {
                    extra1: options.referenceId,
                    extra2: tenantId,
                };
            } else if (pgType === 'billdesk') {
                pgData.payment_gateway.billdesk = {
                    additional_info1: options.referenceId,
                    additional_info2: tenantId,
                };
            }

            // Add preferred payment methods (UPI apps)
            if (options.preferredPaymentMethods && options.preferredPaymentMethods.length > 0) {
                pgData.payment_gateway.preferred_payment_methods = options.preferredPaymentMethods.map(m => ({ method: m }));
            }

            // Add enabled payment options (upi/web)
            if (options.enabledPaymentOptions && options.enabledPaymentOptions.length > 0) {
                pgData.payment_gateway.enabled_payment_options = options.enabledPaymentOptions;
            }

            paymentSettings.push(pgData);
        }

        // Build the interactive message
        const messagePayload: any = {
            messaging_product: 'whatsapp',
            recipient_type: 'individual',
            to: options.recipientPhone,
            type: 'interactive',
            interactive: {
                type: 'order_details',
                body: {
                    text: options.bodyText || `Order #${options.referenceId} — Please review and pay.`,
                },
                footer: {
                    text: (options.footerText || paymentConfig.business_name || 'Thank you!').substring(0, 60),
                },
                action: {
                    name: 'review_and_pay',
                    parameters: {
                        reference_id: options.referenceId.substring(0, 35),
                        type: 'physical-goods',
                        payment_settings: paymentSettings,
                        currency: 'INR',
                        total_amount: {
                            value: Math.round(options.totalAmount * 100),
                            offset: 100,
                        },
                        order,
                    },
                },
            },
        };

        console.log(`[PaymentService] Sending order_details for order ${options.referenceId} to ${options.recipientPhone}`);

        const response = await fetch(
            `https://graph.facebook.com/${apiVersion}/${creds.phone_number_id}/messages`,
            {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${creds.access_token}`,
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(messagePayload),
            }
        );

        const data = await response.json() as any;

        if (!response.ok) {
            console.error(`[PaymentService] Failed to send order_details:`, data);
            throw new Error(data.error?.message || 'Failed to send order_details message');
        }

        console.log(`[PaymentService] order_details sent successfully:`, data.messages?.[0]?.id);
        return data;
    }

    /**
     * Send order_status update message (native WhatsApp order status update)
     */
    async function sendOrderStatusMessage(
        tenantId: string,
        recipientPhone: string,
        referenceId: string,
        status: 'processing' | 'partially_shipped' | 'shipped' | 'completed' | 'canceled',
        description?: string,
        bodyText?: string,
    ): Promise<any> {
        const creds = await getWaCredentials(tenantId);
        const apiVersion = process.env.WHATSAPP_API_VERSION || 'v24.0';

        const statusLabels: Record<string, string> = {
            processing: '🔄 Processing',
            partially_shipped: '📦 Partially Shipped',
            shipped: '🚚 Shipped',
            completed: '✅ Completed',
            canceled: '❌ Canceled',
        };

        const messagePayload = {
            messaging_product: 'whatsapp',
            recipient_type: 'individual',
            to: recipientPhone,
            type: 'interactive',
            interactive: {
                type: 'order_status',
                body: {
                    text: bodyText || `${statusLabels[status] || status} — Your order #${referenceId} has been updated.`,
                },
                action: {
                    name: 'review_order',
                    parameters: {
                        reference_id: referenceId.substring(0, 35),
                        order: {
                            status,
                            description: description?.substring(0, 120) || undefined,
                        },
                    },
                },
            },
        };

        console.log(`[PaymentService] Sending order_status (${status}) for ${referenceId} to ${recipientPhone}`);

        const response = await fetch(
            `https://graph.facebook.com/${apiVersion}/${creds.phone_number_id}/messages`,
            {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${creds.access_token}`,
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(messagePayload),
            }
        );

        const data = await response.json() as any;

        if (!response.ok) {
            console.error(`[PaymentService] Failed to send order_status:`, data);
            throw new Error(data.error?.message || 'Failed to send order_status message');
        }

        console.log(`[PaymentService] order_status sent successfully:`, data.messages?.[0]?.id);
        return data;
    }

    /**
     * Handle payment status webhook from WhatsApp
     * Called when WhatsApp sends a status webhook of type "payment"
     */
    async function handlePaymentWebhook(tenantId: string, paymentStatus: any): Promise<void> {
        try {
            const referenceId = paymentStatus.payment?.reference_id;
            const transaction = paymentStatus.payment?.transaction;
            const status = paymentStatus.status; // captured | pending

            if (!referenceId) {
                console.warn('[PaymentService] Payment webhook missing reference_id');
                return;
            }

            console.log(`[PaymentService] Payment webhook: order=${referenceId}, status=${status}, txn_status=${transaction?.status}`);

            // Import Order model
            const Order = (await import('../../../db/nosqlmodels/Order.js')).default;

            if (status === 'captured' || transaction?.status === 'success') {
                // Payment successful
                await Order.findOneAndUpdate(
                    { orderId: referenceId, tenantId },
                    {
                        paymentStatus: 'paid',
                        orderStatus: 'confirmed',
                        paymentMethod: transaction?.method?.type || 'online',
                        paymentTransactionId: transaction?.pg_transaction_id || transaction?.id,
                        paymentMetadata: {
                            ...paymentStatus.payment,
                            webhook_status: paymentStatus.status,
                            received_at: new Date().toISOString()
                        },
                        updatedAt: new Date(),
                    }
                );

                // Send order_status update to customer
                const order = await Order.findOne({ orderId: referenceId, tenantId });
                if (order?.phoneNumber) {
                    await sendOrderStatusMessage(
                        tenantId,
                        order.phoneNumber,
                        referenceId,
                        'processing',
                        'Payment received! We are processing your order.',
                        '✅ Payment confirmed! Your order is being processed.',
                    );
                }

                console.log(`[PaymentService] Order ${referenceId} marked as PAID`);
            } else if (transaction?.status === 'failed') {
                // Payment failed
                await Order.findOneAndUpdate(
                    { orderId: referenceId, tenantId },
                    {
                        paymentStatus: 'failed',
                        paymentMetadata: {
                            ...paymentStatus.payment,
                            webhook_status: paymentStatus.status,
                            received_at: new Date().toISOString()
                        },
                        updatedAt: new Date(),
                    }
                );

                const order = await Order.findOne({ orderId: referenceId, tenantId });
                if (order?.phoneNumber) {
                    // Send notification about failed payment  
                    const creds = await getWaCredentials(tenantId);
                    const apiVersion = process.env.WHATSAPP_API_VERSION || 'v24.0';
                    await fetch(`https://graph.facebook.com/${apiVersion}/${creds.phone_number_id}/messages`, {
                        method: 'POST',
                        headers: {
                            'Authorization': `Bearer ${creds.access_token}`,
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                            messaging_product: 'whatsapp',
                            to: order.phoneNumber,
                            type: 'text',
                            text: { body: `❌ Payment failed for order #${referenceId}. Please try again or choose a different payment method.` },
                        }),
                    });
                }

                console.log(`[PaymentService] Payment FAILED for order ${referenceId}`);
            }
        } catch (err) {
            console.error('[PaymentService] Error handling payment webhook:', err);
        }
    }

    /**
     * Check payment status via WhatsApp API (verification)
     */
    async function lookupPaymentStatus(tenantId: string, referenceId: string): Promise<any> {
        const paymentConfig = await getPaymentConfig(tenantId);
        if (!paymentConfig) return null;

        const pgType = paymentConfig.provider;
        const configName = (paymentConfig as any)[`${pgType}_payment_config_name`];
        if (!configName) return null;

        const creds = await getWaCredentials(tenantId);
        const apiVersion = process.env.WHATSAPP_API_VERSION || 'v24.0';

        const response = await fetch(
            `https://graph.facebook.com/${apiVersion}/${creds.phone_number_id}/payments/${configName}/${referenceId}`,
            {
                headers: {
                    'Authorization': `Bearer ${creds.access_token}`,
                },
            }
        );

        return await response.json();
    }

    /**
     * Initiate a refund for an order via WhatsApp API
     */
    async function refundOrder(
        tenantId: string,
        referenceId: string,
        amount: number,
        speed: 'normal' | 'instant' = 'normal'
    ): Promise<any> {
        const paymentConfig = await getPaymentConfig(tenantId);
        const pgType = paymentConfig?.provider;
        const configName = (paymentConfig as any)?.[`${pgType}_payment_config_name`];

        if (!configName) throw new Error('Payment configuration not found or config name missing');

        const creds = await getWaCredentials(tenantId);
        const apiVersion = process.env.WHATSAPP_API_VERSION || 'v24.0';

        const payload = {
            reference_id: referenceId,
            speed,
            payment_config_id: configName,
            amount: {
                currency: 'INR',
                value: String(Math.round(amount * 100)),
                offset: '100'
            }
        };

        console.log(`[PaymentService] Initiating refund for ${referenceId}, amount=${amount}`);

        const response = await fetch(
            `https://graph.facebook.com/${apiVersion}/${creds.phone_number_id}/payments_refund`,
            {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${creds.access_token}`,
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(payload),
            }
        );

        const data = await response.json() as any;

        if (!response.ok) {
            console.error(`[PaymentService] Refund failed:`, data);
            throw new Error(data.error?.message || 'Failed to initiate refund');
        }

        console.log(`[PaymentService] Refund initiated successfully:`, data.id);
        return data;
    }

    return {
        getPaymentConfig,
        sendOrderDetailsMessage,
        sendOrderStatusMessage,
        handlePaymentWebhook,
        lookupPaymentStatus,
        refundOrder,
    };
}

export type WhatsAppPaymentService = ReturnType<typeof createWhatsAppPaymentService>;
