// application/services/whatsapp/AIEcommerceAssistant.ts
import { cartService } from './CartService.js';
import Order from '../../../db/nosqlmodels/Order.js';
import CustomerAddress from '../../../db/nosqlmodels/CustomerAddress.js';
import type { WhatsAppPaymentService } from './WhatsAppPaymentService.js';

interface AddressData {
    name?: string;
    addressLine1?: string;
    addressLine2?: string;
    city?: string;
    state?: string;
    pincode?: string;
}

interface UserState {
    userId: string;
    currentView: 'MENU' | 'BROWSING' | 'SEARCHING' | 'CART' | 'CHECKOUT' | 'BOOKING';
    lastViewedProductId?: string;
    checkoutStep?: 'ADDRESS_CHECK' | 'ADDRESS_NAME' | 'ADDRESS_LINE' | 'ADDRESS_CITY' | 'ADDRESS_STATE' | 'ADDRESS_PINCODE' | 'ADDRESS_CONFIRM' | 'PAYMENT' | 'CONFIRMATION';
    addressData?: AddressData;
    bookingData?: { serviceType?: string; appointmentDate?: string };
    bookingStep?: 'SERVICE' | 'DATE' | 'CONFIRMATION';
}

// Indian states for interactive list
const INDIAN_STATES = [
    'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chhattisgarh',
    'Goa', 'Gujarat', 'Haryana', 'Himachal Pradesh', 'Jharkhand',
    'Karnataka', 'Kerala', 'Madhya Pradesh', 'Maharashtra', 'Manipur',
    'Meghalaya', 'Mizoram', 'Nagaland', 'Odisha', 'Punjab',
    'Rajasthan', 'Sikkim', 'Tamil Nadu', 'Telangana', 'Tripura',
    'Uttar Pradesh', 'Uttarakhand', 'West Bengal',
    'Delhi', 'Jammu & Kashmir', 'Ladakh', 'Puducherry', 'Chandigarh',
];

export function createAIEcommerceAssistant(
    messageService: any,
    productService: any,
    categoryService: any,
    appointmentService?: any,
    waConfigRepo?: any,
    pool?: any,
    paymentService?: WhatsAppPaymentService,
) {
    // In-memory state store for MVP. In production, this should be in Redis or Postgres.
    const userStates: Map<string, UserState> = new Map();

    const getOrCreateState = (userId: string): UserState => {
        if (!userStates.has(userId)) {
            userStates.set(userId, {
                userId,
                currentView: 'MENU',
            });
        }
        return userStates.get(userId)!;
    };

    const updateState = (userId: string, updates: Partial<UserState>) => {
        const currentState = getOrCreateState(userId);
        userStates.set(userId, { ...currentState, ...updates });
    };

    const sendWelcomeMenu = async (tenantId: string, recipientPhone: string, ms: any) => {
        updateState(recipientPhone, { currentView: 'MENU' });

        const bodyText = "Welcome to our store! 👋\nHow can I help you today?";
        const buttons = [
            { id: 'view_products', title: '🛍️ View Products' },
            { id: 'book_appointment', title: '📅 Book Consultation' },
            { id: 'search_product', title: '🔍 Search' }
        ];

        await ms.sendInteractive({
            tenantId,
            recipientPhone,
            bodyText,
            buttons,
            senderUserId: 'AI_ASSISTANT'
        });
    };

    const sendProductList = async (tenantId: string, recipientPhone: string, ms: any) => {
        try {
            const result = await productService.getAllProducts(tenantId, { limit: 5 });
            const products = result.data;

            if (!products || products.length === 0) {
                await ms.sendText({
                    tenantId,
                    recipientPhone,
                    text: "Sorry, we don't have any products available right now. 😔",
                    senderUserId: 'AI_ASSISTANT'
                });
                return;
            }

            updateState(recipientPhone, { currentView: 'BROWSING' });

            // Try to send as Meta Catalog interactive product list
            let catalogId: string | null = null;
            if (waConfigRepo) {
                try {
                    const config = await waConfigRepo.findByTenantId(tenantId);
                    catalogId = config?.catalog_id || null;
                } catch (e) {
                    console.warn('[AIEcommerce] Failed to fetch catalog config:', e);
                }
            }

            // Fallback: check catalog_configs table
            if (!catalogId && pool) {
                try {
                    const catalogResult = await pool.query(
                        `SELECT catalog_id FROM catalog_configs WHERE tenant_id = $1 AND status = 'active' ORDER BY created_at DESC LIMIT 1`,
                        [tenantId]
                    );
                    if (catalogResult.rows.length > 0) {
                        catalogId = catalogResult.rows[0].catalog_id;
                        console.log(`[AIEcommerce] Resolved catalog_id from catalog_configs: ${catalogId}`);
                    }
                } catch (e) {
                    console.warn('[AIEcommerce] Failed to fetch from catalog_configs:', e);
                }
            }

            if (catalogId) {
                const categoryMap = new Map<string, { name: string; items: any[] }>();
                for (const p of products) {
                    const catName = p.categoryName || p.category?.name || 'Products';
                    if (!categoryMap.has(catName)) {
                        categoryMap.set(catName, { name: catName, items: [] });
                    }
                    categoryMap.get(catName)!.items.push(p);
                }

                const sections = Array.from(categoryMap.values()).map(cat => ({
                    title: cat.name,
                    product_items: cat.items.map((p: any) => ({
                        product_retailer_id: p.sku || p._id.toString()
                    }))
                }));

                try {
                    await ms.sendInteractive({
                        tenantId,
                        recipientPhone,
                        interactiveContent: {
                            type: 'PRODUCT_LIST',
                            header: 'Our Products',
                            body: 'Browse our latest collection',
                            action: {
                                catalog_id: catalogId,
                                sections
                            }
                        },
                        senderUserId: 'AI_ASSISTANT'
                    });
                } catch (interactiveErr: any) {
                    console.warn('[AIEcommerce] failed to send catalog interactive, falling back to text:', interactiveErr?.message);
                    await sendProductTextFallback(tenantId, recipientPhone, products, ms);
                }
            } else {
                await sendProductTextFallback(tenantId, recipientPhone, products, ms);
            }
        } catch (error) {
            console.error("Error fetching products:", error);
            await ms.sendText({ tenantId, recipientPhone, text: "Failed to load products.", senderUserId: "AI_ASSISTANT" });
        }
    };

    const sendProductTextFallback = async (tenantId: string, recipientPhone: string, products: any[], ms: any) => {
        let text = "Here are our latest products:\n\n";
        products.forEach((p: any, index: number) => {
            text += `${index + 1}. *${p.productName}*\n`;
            text += `   Price: ₹${p.price}\n`;
            text += `   Reply with "add ${p._id}" to buy.\n\n`;
        });
        text += "Reply 'menu' to go back.";
        await ms.sendText({ tenantId, recipientPhone, text, senderUserId: 'AI_ASSISTANT' });
    };

    const sendCart = async (tenantId: string, recipientPhone: string, ms: any) => {
        updateState(recipientPhone, { currentView: 'CART' });

        const cart = await cartService.getCart(recipientPhone, tenantId);

        if (!cart || cart.items.length === 0) {
            const bodyText = "Your cart is empty. 🛒 Let's add some items!";
            const buttons = [
                { id: 'view_products', title: '🛍️ View Products' },
                { id: 'menu', title: '🏠 Main Menu' },
            ];
            await ms.sendInteractive({ tenantId, recipientPhone, bodyText, buttons, senderUserId: 'AI_ASSISTANT' });
            return;
        }

        let text = "*Your Cart:*\n\n";
        let total = 0;
        cart.items.forEach((item, index) => {
            const itemTotal = item.price * item.quantity;
            total += itemTotal;
            text += `${index + 1}. ${item.productName} x${item.quantity} - ₹${itemTotal}\n`;
        });
        text += `\n*Total: ₹${total}*`;

        const buttons = [
            { id: 'checkout', title: '💳 Checkout' },
            { id: 'clear_cart', title: '🗑️ Clear Cart' },
            { id: 'view_products', title: '🛍️ Continue Shopping' },
        ];

        await ms.sendInteractive({ tenantId, recipientPhone, bodyText: text, buttons, senderUserId: 'AI_ASSISTANT' });
    };

    const addToCart = async (tenantId: string, recipientPhone: string, productId: string, ms: any) => {
        try {
            const product = await productService.getProductById(productId, tenantId);
            if (!product) {
                await ms.sendText({ tenantId, recipientPhone, text: "Product not found.", senderUserId: "AI_ASSISTANT" });
                return;
            }

            await cartService.addToCart(recipientPhone, tenantId, {
                id: product._id.toString(),
                name: product.productName,
                price: product.price
            }, 1);

            const bodyText = `Added *${product.productName}* to your cart! ✅`;
            const buttons = [
                { id: 'view_cart', title: '🛒 View Cart' },
                { id: 'view_products', title: '🛍️ Continue Shopping' },
            ];
            await ms.sendInteractive({ tenantId, recipientPhone, bodyText, buttons, senderUserId: 'AI_ASSISTANT' });

        } catch (error) {
            console.error("Error adding to cart:", error);
            await ms.sendText({ tenantId, recipientPhone, text: "Failed to add to cart.", senderUserId: "AI_ASSISTANT" });
        }
    };

    const handleSearchInput = async (tenantId: string, recipientPhone: string, query: string, ms: any) => {
        try {
            const result = await productService.getAllProducts(tenantId, { search: query, limit: 5 });
            const products = result.data;

            if (!products || products.length === 0) {
                const bodyText = `No products found for "${query}". 😔`;
                const buttons = [
                    { id: 'search_product', title: '🔍 Search Again' },
                    { id: 'menu', title: '🏠 Main Menu' },
                ];
                await ms.sendInteractive({ tenantId, recipientPhone, bodyText, buttons, senderUserId: 'AI_ASSISTANT' });
                updateState(recipientPhone, { currentView: 'MENU' });
                return;
            }

            let text = `Search results for "${query}":\n\n`;
            products.forEach((p: any, index: number) => {
                text += `${index + 1}. *${p.productName}*\n`;
                text += `   Price: ₹${p.price}\n`;
                text += `   Reply with "add ${p._id}" to buy.\n\n`;
            });
            text += "Reply 'menu' to go back.";

            await ms.sendText({ tenantId, recipientPhone, text, senderUserId: 'AI_ASSISTANT' });
            updateState(recipientPhone, { currentView: 'BROWSING' });

        } catch (error) {
            console.error("Error searching products:", error);
            await ms.sendText({ tenantId, recipientPhone, text: "Search failed.", senderUserId: "AI_ASSISTANT" });
            updateState(recipientPhone, { currentView: 'MENU' });
        }
    };

    // ── Address Collection Flow ──

    const formatAddress = (addr: AddressData): string => {
        const parts = [addr.name, addr.addressLine1];
        if (addr.addressLine2) parts.push(addr.addressLine2);
        parts.push(`${addr.city}, ${addr.state} - ${addr.pincode}`);
        return parts.join('\n');
    };

    const startAddressCollection = async (tenantId: string, recipientPhone: string, ms: any) => {
        // First check if customer already has a saved address
        const savedAddress = await CustomerAddress.findOne({ tenantId, phoneNumber: recipientPhone, isDefault: true });

        if (savedAddress) {
            updateState(recipientPhone, { currentView: 'CHECKOUT', checkoutStep: 'ADDRESS_CHECK' });
            const addrText = `${savedAddress.name}\n${savedAddress.addressLine1}${savedAddress.addressLine2 ? ', ' + savedAddress.addressLine2 : ''}\n${savedAddress.city}, ${savedAddress.state} - ${savedAddress.pincode}`;
            const bodyText = `🚚 *We found a saved address for you:*\n\n${addrText}\n\nWould you like to use this for your order?`;
            const buttons = [
                { id: 'use_saved_address', title: '✅ Use This' },
                { id: 'enter_new_address', title: '🏠 New Address' },
            ];
            await ms.sendInteractive({ tenantId, recipientPhone, bodyText, buttons, senderUserId: 'AI_ASSISTANT' });
        } else {
            // Trigger Native Address Form directly
            await ms.sendInteractive({
                tenantId,
                recipientPhone,
                interactiveContent: {
                    type: 'ADDRESS_MESSAGE',
                    body: "🚚 Please provide your delivery address for the order:",
                    footer: "Select or add a new address",
                },
                senderUserId: 'AI_ASSISTANT'
            });
            updateState(recipientPhone, { currentView: 'CHECKOUT', checkoutStep: 'ADDRESS_CONFIRM' }); // Wait for reply
        }
    };

    const handleAddressStep = async (tenantId: string, recipientPhone: string, ms: any, text?: string, selectedButtonId?: string) => {
        const state = getOrCreateState(recipientPhone);

        switch (state.checkoutStep) {
            case 'ADDRESS_CHECK': {
                if (selectedButtonId === 'use_saved_address') {
                    // Use the saved address, proceed to payment
                    updateState(recipientPhone, { checkoutStep: 'PAYMENT' });
                    return sendPaymentOptions(tenantId, recipientPhone, ms);
                }
                if (selectedButtonId === 'enter_new_address') {
                    // Trigger Native Address Form
                    await ms.sendInteractive({
                        tenantId,
                        recipientPhone,
                        interactiveContent: {
                            type: 'ADDRESS_MESSAGE',
                            body: "🚚 Please provide your delivery address for the order:",
                            footer: "Select or add a new address",
                        },
                        senderUserId: 'AI_ASSISTANT'
                    });
                    updateState(recipientPhone, { checkoutStep: 'ADDRESS_CONFIRM' });
                    return;
                }
                break;
            }

            case 'ADDRESS_PINCODE': {
                const pincode = (text || '').trim().replace(/\s/g, '');
                if (!/^\d{6}$/.test(pincode)) {
                    await ms.sendText({ tenantId, recipientPhone, text: "❌ Invalid pincode. Please enter a valid 6-digit pincode.", senderUserId: 'AI_ASSISTANT' });
                    return;
                }
                const fullAddress = { ...state.addressData, pincode };
                updateState(recipientPhone, {
                    checkoutStep: 'ADDRESS_CONFIRM',
                    addressData: fullAddress,
                });

                const addrText = formatAddress(fullAddress);
                const bodyText = `📋 *Please confirm your delivery address:*\n\n${addrText}`;
                const buttons = [
                    { id: 'confirm_address', title: '✅ Confirm' },
                    { id: 'edit_address', title: '✏️ Re-enter' },
                ];
                await ms.sendInteractive({ tenantId, recipientPhone, bodyText, buttons, senderUserId: 'AI_ASSISTANT' });
                return;
            }

            case 'ADDRESS_CONFIRM': {
                if (selectedButtonId === 'confirm_address') {
                    // Save address to DB
                    try {
                        const addr = state.addressData!;
                        await CustomerAddress.findOneAndUpdate(
                            { tenantId, phoneNumber: recipientPhone, isDefault: true },
                            {
                                tenantId,
                                phoneNumber: recipientPhone,
                                name: addr.name || '',
                                addressLine1: addr.addressLine1 || '',
                                addressLine2: addr.addressLine2 || '',
                                city: addr.city || '',
                                state: addr.state || '',
                                pincode: addr.pincode || '',
                                isDefault: true,
                            },
                            { upsert: true, returnDocument: 'after' }
                        );
                        console.log(`[AIEcommerce] Saved address for ${recipientPhone}`);
                    } catch (err) {
                        console.warn('[AIEcommerce] Failed to save address:', err);
                    }

                    updateState(recipientPhone, { checkoutStep: 'PAYMENT' });
                    return sendPaymentOptions(tenantId, recipientPhone, ms);
                }

                if (selectedButtonId === 'edit_address') {
                    // Trigger Native Address Form again
                    await ms.sendInteractive({
                        tenantId,
                        recipientPhone,
                        interactiveContent: {
                            type: 'ADDRESS_MESSAGE',
                            body: "🚚 Please provide your delivery address for the order:",
                            footer: "Select or add a new address",
                        },
                        senderUserId: 'AI_ASSISTANT'
                    });
                    updateState(recipientPhone, { checkoutStep: 'ADDRESS_CONFIRM', addressData: {} });
                    return;
                }
                break;
            }
        }
    };

    const sendPaymentOptions = async (tenantId: string, recipientPhone: string, ms: any) => {
        const bodyText = "💰 *How would you like to pay?*";
        const buttons = [
            { id: 'pay_cod', title: '💵 Cash on Delivery' },
            { id: 'pay_online', title: '💳 Pay Online' },
        ];
        await ms.sendInteractive({ tenantId, recipientPhone, bodyText, buttons, senderUserId: 'AI_ASSISTANT' });
    };

    // ── Main Message Handler ──

    const handleMessageWithService = async (tenantId: string, senderPhone: string, ms: any, text?: string, selectedButtonId?: string, incomingMsg?: any) => {
        try {
            console.log(`[AIEcommerce] Handling message from ${senderPhone}. State:`, userStates.get(senderPhone));
            const state = getOrCreateState(senderPhone);
            const normalizedText = text?.trim().toLowerCase() || '';

            // Handle Native Address Form reply
            if (incomingMsg?.addressFormContent) {
                try {
                    const addr = incomingMsg.addressFormContent;
                    const fullAddress = {
                        name: addr.name,
                        addressLine1: addr.house_number ? `${addr.house_number}, ${addr.address}` : addr.address,
                        addressLine2: addr.building_name || addr.landmark_area || '',
                        city: addr.city,
                        state: addr.state || '',
                        pincode: addr.pincode,
                    };

                    updateState(senderPhone, {
                        currentView: 'CHECKOUT',
                        checkoutStep: 'ADDRESS_CONFIRM',
                        addressData: fullAddress,
                    });

                    const addrText = formatAddress(fullAddress);
                    const bodyText = `🚚 *Confirm your delivery address:*\n\n${addrText}\n\nWould you like to use this for your order?`;
                    const buttons = [
                        { id: 'confirm_address', title: '✅ Use This' },
                        { id: 'edit_address', title: '🏠 New Address' },
                    ];
                    await ms.sendInteractive({ tenantId, recipientPhone: senderPhone, bodyText, buttons, senderUserId: 'AI_ASSISTANT' });
                    return;
                } catch (err: any) {
                    console.error('[AIEcommerce] Error handling address form:', err);
                    return ms.sendText({ tenantId, recipientPhone: senderPhone, text: "❌ *Sorry, I couldn't process your address.*\n\nPlease try again or type 'menu' to start over.", senderUserId: 'AI_ASSISTANT' });
                }
            }

            // Global intents (can be triggered anytime)
            if (normalizedText === 'menu' || normalizedText === 'hi' || normalizedText === 'hello' || normalizedText === 'start') {
                return sendWelcomeMenu(tenantId, senderPhone, ms);
            }
            if (normalizedText === 'cart' || selectedButtonId === 'view_cart') {
                return sendCart(tenantId, senderPhone, ms);
            }
            if (selectedButtonId === 'view_products' || normalizedText === 'products') {
                return sendProductList(tenantId, senderPhone, ms);
            }
            if (selectedButtonId === 'search_product' || normalizedText === 'search') {
                updateState(senderPhone, { currentView: 'SEARCHING' });
                return ms.sendText({ tenantId, recipientPhone: senderPhone, text: "What are you looking for? Type the product name:", senderUserId: 'AI_ASSISTANT' });
            }
            if (selectedButtonId === 'clear_cart') {
                await cartService.clearCart(senderPhone, tenantId);
                return ms.sendText({ tenantId, recipientPhone: senderPhone, text: "Cart cleared! 🗑️\nReply 'menu' to start over.", senderUserId: 'AI_ASSISTANT' });
            }
            if (selectedButtonId === 'checkout' || normalizedText === 'checkout') {
                const cart = await cartService.getCart(senderPhone, tenantId);
                if (!cart || cart.items.length === 0) {
                    return ms.sendText({ tenantId, recipientPhone: senderPhone, text: "Your cart is empty! Cannot checkout.", senderUserId: 'AI_ASSISTANT' });
                }
                return startAddressCollection(tenantId, senderPhone, ms);
            }

            // ── State-specific intents ──

            // Booking flow
            if (state.currentView === 'BOOKING') {
                if (state.bookingStep === 'SERVICE') {
                    updateState(senderPhone, { bookingStep: 'DATE', bookingData: { serviceType: text } });
                    return ms.sendText({ tenantId, recipientPhone: senderPhone, text: `Great, a ${text} consultation. When would you like to book?`, senderUserId: 'AI_ASSISTANT' });
                }
                if (state.bookingStep === 'DATE') {
                    updateState(senderPhone, { bookingStep: 'CONFIRMATION', bookingData: { ...state.bookingData, appointmentDate: text } });
                    const bodyText = `Please confirm your appointment:\nService: ${state.bookingData?.serviceType}\nDate/Time: ${text}\n\nIs this correct?`;
                    const buttons = [
                        { id: 'confirm_booking', title: '✅ Yes, book it' },
                        { id: 'cancel_booking', title: '❌ No, cancel' }
                    ];
                    return ms.sendInteractive({ tenantId, recipientPhone: senderPhone, bodyText, buttons, senderUserId: 'AI_ASSISTANT' });
                }
                if (state.bookingStep === 'CONFIRMATION') {
                    if (selectedButtonId === 'confirm_booking' && appointmentService) {
                        try {
                            await appointmentService.createAppointment(tenantId, {
                                contactName: "WhatsApp User",
                                contactPhone: senderPhone,
                                serviceType: state.bookingData?.serviceType || 'Consultation',
                                appointmentDate: new Date()
                            });
                            updateState(senderPhone, { currentView: 'MENU', bookingData: {}, bookingStep: undefined });
                            return ms.sendText({ tenantId, recipientPhone: senderPhone, text: "🎉 Your appointment is confirmed!", senderUserId: 'AI_ASSISTANT' });
                        } catch (e) {
                            return ms.sendText({ tenantId, recipientPhone: senderPhone, text: "Sorry, we couldn't book your appointment.", senderUserId: 'AI_ASSISTANT' });
                        }
                    } else {
                        updateState(senderPhone, { currentView: 'MENU', bookingData: {}, bookingStep: undefined });
                        return ms.sendText({ tenantId, recipientPhone: senderPhone, text: "Booking cancelled. Reply 'menu' to go back.", senderUserId: 'AI_ASSISTANT' });
                    }
                }
            }

            if (state.currentView === 'SEARCHING') {
                return handleSearchInput(tenantId, senderPhone, normalizedText, ms);
            }

            if (state.currentView === 'BROWSING' && normalizedText.startsWith('add ')) {
                const productId = normalizedText.replace('add ', '').trim();
                if (productId.length > 5) {
                    return addToCart(tenantId, senderPhone, productId, ms);
                }
            }

            // ── Checkout: Address Collection Steps ──
            if (state.currentView === 'CHECKOUT' && state.checkoutStep &&
                ['ADDRESS_CHECK', 'ADDRESS_NAME', 'ADDRESS_LINE', 'ADDRESS_CITY', 'ADDRESS_STATE', 'ADDRESS_PINCODE', 'ADDRESS_CONFIRM'].includes(state.checkoutStep)) {
                return handleAddressStep(tenantId, senderPhone, ms, text, selectedButtonId);
            }

            // ── Checkout: Payment Selection ──
            if (state.currentView === 'CHECKOUT' && state.checkoutStep === 'PAYMENT' && (selectedButtonId === 'pay_cod' || selectedButtonId === 'pay_online')) {
                const cart = await cartService.getCart(senderPhone, tenantId);
                if (!cart || cart.items.length === 0) {
                    return ms.sendText({ tenantId, recipientPhone: senderPhone, text: "Your cart seems to be empty! Let's start over.", senderUserId: 'AI_ASSISTANT' });
                }

                const totalAmount = cart.items.reduce((acc, item) => acc + (item.price * item.quantity), 0);
                const isCOD = selectedButtonId === 'pay_cod';
                const addr = state.addressData;

                const orderOptions: any = {
                    customerName: addr?.name || 'WhatsApp Customer',
                    phoneNumber: senderPhone,
                    products: cart.items.map(item => ({
                        product: item.product,
                        productName: item.productName,
                        quantity: item.quantity,
                        price: item.price
                    })),
                    totalAmount,
                    paymentStatus: 'pending',
                    orderStatus: isCOD ? 'confirmed' : 'pending',
                    paymentMethod: isCOD ? 'cod' : 'online',
                    source: 'whatsapp',
                    tenantId,
                    createdBy: 'AI_ASSISTANT',
                };

                if (addr && addr.addressLine1) {
                    orderOptions.shippingAddress = {
                        name: addr.name || '',
                        addressLine1: addr.addressLine1,
                        addressLine2: addr.addressLine2 || '',
                        city: addr.city || '',
                        state: addr.state || '',
                        pincode: addr.pincode || '',
                    };
                }

                try {
                    const order = new Order(orderOptions);
                    await order.save();
                    await cartService.completeCart(senderPhone, tenantId);

                    if (isCOD) {
                        updateState(senderPhone, { checkoutStep: 'CONFIRMATION', currentView: 'MENU', addressData: undefined });
                        return ms.sendText({
                            tenantId,
                            recipientPhone: senderPhone,
                            text: `🎉 *Order Confirmed!*\n\nOrder ID: *${order.orderId}*\nPayment: Cash on Delivery\nTotal: ₹${totalAmount}\n\n📍 Delivering to:\n${formatAddress(addr!)}\n\nWe'll notify you when it ships.`,
                            senderUserId: 'AI_ASSISTANT',
                        });
                    }

                    if (paymentService) {
                        try {
                            await paymentService.sendOrderDetailsMessage(tenantId, {
                                recipientPhone: senderPhone,
                                referenceId: order.orderId,
                                items: cart.items.map(item => ({
                                    productName: item.productName,
                                    quantity: item.quantity,
                                    price: item.price,
                                    sku: String(item.product),
                                })),
                                subtotal: totalAmount,
                                tax: 0,
                                totalAmount,
                                expirationSeconds: 3600,
                                preferredPaymentMethods: ['gpay'], // Added preferred payment method
                                enabledPaymentOptions: ['upi', 'web'], // Allow both UPI and Web
                            });
                            updateState(senderPhone, { checkoutStep: 'CONFIRMATION', currentView: 'MENU', addressData: undefined });
                            return ms.sendText({
                                tenantId,
                                recipientPhone: senderPhone,
                                text: `📱 *Payment Invoice Sent!*\n\nOrder ID: *${order.orderId}*\nTotal: ₹${totalAmount}\n\nPlease complete the payment using invoice above.`,
                                senderUserId: 'AI_ASSISTANT',
                            });
                        } catch (payErr) {
                            console.warn('[AIEcommerce] Payment service error:', payErr);
                        }
                    }

                    updateState(senderPhone, { checkoutStep: 'CONFIRMATION', currentView: 'MENU', addressData: undefined });
                    return ms.sendText({
                        tenantId,
                        recipientPhone: senderPhone,
                        text: `🎉 *Order Placed!*\n\nOrder ID: *${order.orderId}*\nPayment: Online (pending)\nTotal: ₹${totalAmount}`,
                        senderUserId: 'AI_ASSISTANT',
                    });
                } catch (orderErr: any) {
                    console.error('[AIEcommerce] Order creation failed:', orderErr);
                    return ms.sendText({
                        tenantId,
                        recipientPhone: senderPhone,
                        text: `❌ *Sorry, something went wrong while placing your order.*\n\nError: ${orderErr.message}`,
                        senderUserId: 'AI_ASSISTANT',
                    });
                }
            }

            // Fallback
            if (!selectedButtonId && !incomingMsg?.addressFormContent) {
                return sendWelcomeMenu(tenantId, senderPhone, ms);
            }
        } catch (globalErr: any) {
            console.error('[AIEcommerce] FATAL ERROR in handleMessageWithService:', globalErr);
            try {
                await ms.sendText({ 
                    tenantId, 
                    recipientPhone: senderPhone, 
                    text: "⚠️ *Something went wrong.* Please type 'menu' to start again.", 
                    senderUserId: 'SYSTEM' 
                });
            } catch (fallbackErr) {
                console.error('[AIEcommerce] Error sending fatal fallback:', fallbackErr);
            }
        }
    };

    /**
     * Simulates a message exchange for the Live Demo UI.
     */
    const simulateMessage = async (tenantId: string, senderPhone: string, text?: string, selectedButtonId?: string) => {
        const responses: any[] = [];

        const mockMessageService = {
            sendText: async (params: any) => {
                responses.push({ type: 'TEXT', text: params.text });
                return { success: true };
            },
            sendInteractive: async (params: any) => {
                responses.push({ type: 'INTERACTIVE', bodyText: params.bodyText, buttons: params.buttons });
                return { success: true };
            }
        };

        await handleMessageWithService(tenantId, senderPhone, mockMessageService, text, selectedButtonId);

        return responses;
    };

    return {
        handleMessage: (tenantId: string, senderPhone: string, text?: string, selectedButtonId?: string, incomingMsg?: any) =>
            handleMessageWithService(tenantId, senderPhone, messageService, text, selectedButtonId, incomingMsg),
        simulateMessage,
        getState: (userId: string) => userStates.get(userId)
    };
}
