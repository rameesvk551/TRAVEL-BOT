import axios from 'axios';
import { AppError } from '../../../utils/apiError.js';
import db from '../../../db/sqlmodels/index.js';

export function createMetaService() {
    return {
        async getBusinessDetails(userId: string) {
            const user = await db.User.findByPk(userId);
            if (!user || !user.metaAccessToken) {
                throw new AppError('Meta account not linked or access token missing', 400);
            }

            try {
                // Fetch businesses the user has access to
                const response = await axios.get(`https://graph.facebook.com/v25.0/me/businesses`, {
                    params: { access_token: user.metaAccessToken }
                });
                return response.data;
            } catch (error: any) {
                throw new AppError(error.response?.data?.error?.message || 'Failed to fetch business details', 400);
            }
        },

        async getConnectedAssets(userId: string, businessId: string) {
            const user = await db.User.findByPk(userId);
            if (!user || !user.metaAccessToken) {
                throw new AppError('Meta account not linked or access token missing', 400);
            }

            try {
                // Fetch ad accounts for this business
                const response = await axios.get(`https://graph.facebook.com/v25.0/${businessId}/client_ad_accounts`, {
                    params: { access_token: user.metaAccessToken }
                });

                // Fetch WABAs for this business
                const wabaResponse = await axios.get(`https://graph.facebook.com/v25.0/${businessId}/owned_whatsapp_business_accounts`, {
                    params: { access_token: user.metaAccessToken }
                });

                return {
                    adAccounts: response.data.data || [],
                    wabaAccounts: wabaResponse.data.data || []
                };
            } catch (error: any) {
                throw new AppError(error.response?.data?.error?.message || 'Failed to fetch connected assets', 400);
            }
        },

        async subscribeWabaToApp(wabaId: string, accessToken: string) {
            try {
                const response = await axios.post(
                    `https://graph.facebook.com/v25.0/${wabaId}/subscribed_apps`,
                    {},
                    {
                        headers: {
                            'Authorization': `Bearer ${accessToken}`
                        }
                    }
                );
                console.log(`[MetaService] Successfully subscribed WABA ${wabaId}:`, response.data);
                return response.data;
            } catch (error: any) {
                console.error(`[MetaService] Failed to subscribe WABA ${wabaId}:`, error.response?.data || error.message);
                throw new AppError(error.response?.data?.error?.message || 'Failed to subscribe WABA', error.response?.status || 500);
            }
        },

        async registerPhoneNumber(phoneNumberId: string, accessToken: string, pin: string) {
            try {
                const response = await axios.post(
                    `https://graph.facebook.com/v25.0/${phoneNumberId}/register`,
                    {
                        messaging_product: 'whatsapp',
                        pin
                    },
                    {
                        headers: {
                            'Authorization': `Bearer ${accessToken}`,
                            'Content-Type': 'application/json'
                        }
                    }
                );
                console.log(`[MetaService] Successfully registered phone number ${phoneNumberId}:`, response.data);
                return response.data;
            } catch (error: any) {
                console.error(`[MetaService] Failed to register phone number ${phoneNumberId}:`, error.response?.data || error.message);
                throw new AppError(error.response?.data?.error?.message || 'Failed to register phone number', error.response?.status || 500);
            }
        },

        async sendTestMessage(phoneNumberId: string, accessToken: string, to: string, body: string) {
            try {
                const response = await axios.post(
                    `https://graph.facebook.com/v25.0/${phoneNumberId}/messages`,
                    {
                        messaging_product: 'whatsapp',
                        recipient_type: 'individual',
                        to,
                        type: 'text',
                        text: { body }
                    },
                    {
                        headers: { Authorization: `Bearer ${accessToken}` }
                    }
                );
                return response.data;
            } catch (error: any) {
                console.error(`[MetaService] Failed to send test message from ${phoneNumberId}:`, error.response?.data || error.message);
                throw new AppError(error.response?.data?.error?.message || 'Failed to send test message', 400);
            }
        }
    };
}
