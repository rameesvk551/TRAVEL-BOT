// controllers/EmbeddedSignupController.ts
// Isolated controller for Facebook Embedded Signup flow.
// Handles: get signup config, complete signup callback.

import type { Pool } from 'pg';
import crypto from 'crypto';
import { TenantModel } from '../../tenant/tenant.model.js';
import * as partnerService from '../../partner/partner.service.js';
import { createMetaService } from '../services/MetaService.js';

interface EmbeddedStatePayload {
    tenantId: string;
    partnerId?: string;
    callbackUrl?: string;
    iat: number;
}

const STATE_MAX_AGE_MS = 10 * 60 * 1000;

const toBase64Url = (value: string) =>
    Buffer.from(value, 'utf8').toString('base64')
        .replace(/\+/g, '-')
        .replace(/\//g, '_')
        .replace(/=+$/g, '');

const fromBase64Url = (value: string) => {
    const normalized = value.replace(/-/g, '+').replace(/_/g, '/');
    const padLength = (4 - (normalized.length % 4)) % 4;
    const padded = `${normalized}${'='.repeat(padLength)}`;
    return Buffer.from(padded, 'base64').toString('utf8');
};

const getStateSecret = () =>
    process.env.EMBEDDED_SIGNUP_STATE_SECRET || process.env.JWT_SECRET || process.env.META_APP_SECRET || '';

const signState = (payload: EmbeddedStatePayload) => {
    const secret = getStateSecret();
    if (!secret) {
        throw new Error('Embedded signup state secret is not configured');
    }

    const body = toBase64Url(JSON.stringify(payload));
    const sig = crypto
        .createHmac('sha256', secret)
        .update(body)
        .digest('base64')
        .replace(/\+/g, '-')
        .replace(/\//g, '_')
        .replace(/=+$/g, '');

    return `${body}.${sig}`;
};

const verifyState = (state: string): EmbeddedStatePayload | null => {
    const secret = getStateSecret();
    if (!secret) {
        return null;
    }

    const [body, signature] = String(state || '').split('.');
    if (!body || !signature) {
        return null;
    }

    const expectedSignature = crypto
        .createHmac('sha256', secret)
        .update(body)
        .digest('base64')
        .replace(/\+/g, '-')
        .replace(/\//g, '_')
        .replace(/=+$/g, '');

    const expectedBuffer = Buffer.from(expectedSignature);
    const receivedBuffer = Buffer.from(signature);
    if (expectedBuffer.length !== receivedBuffer.length || !crypto.timingSafeEqual(expectedBuffer, receivedBuffer)) {
        return null;
    }

    try {
        const parsed = JSON.parse(fromBase64Url(body)) as EmbeddedStatePayload;
        if (!parsed?.tenantId || !parsed?.iat) {
            return null;
        }
        if (Date.now() - parsed.iat > STATE_MAX_AGE_MS) {
            return null;
        }
        return parsed;
    } catch {
        return null;
    }
};

const isCallbackUrlAllowed = (rawUrl?: string) => {
    if (!rawUrl) {
        return true;
    }

    try {
        const parsed = new URL(rawUrl);
        if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') {
            return false;
        }

        const allowedHosts = (process.env.EMBEDDED_SIGNUP_ALLOWED_CALLBACK_HOSTS || '')
            .split(',')
            .map((host) => host.trim().toLowerCase())
            .filter(Boolean);

        if (allowedHosts.length === 0) {
            return false;
        }

        return allowedHosts.includes(parsed.hostname.toLowerCase());
    } catch {
        return false;
    }
};

export function createEmbeddedSignupController(
    waConfigRepo: {
        findByTenantId: (tenantId: string) => Promise<any>;
        save: (config: any) => Promise<any>;
        updateStatus: (tenantId: string, status: string, error?: string) => Promise<void>;
    },
    metaService: ReturnType<typeof createMetaService>,
    pool: Pool
) {
    // ────────────────────────────────────────────
    // GET /settings/embedded/config — info to launch FB signup widget
    // ────────────────────────────────────────────
    const getConfig = async (req: any, res: any, next: any) => {
        try {
            const tenantId = req.context?.tenantId;
            if (!tenantId) { res.status(401).json({ error: 'Tenant required' }); return; }
            if (!getStateSecret()) {
                res.status(500).json({ error: 'Embedded signup state secret is not configured' });
                return;
            }
            const partnerId = req.context?.partnerId;
            const callbackUrl = typeof req.query?.callbackUrl === 'string' ? req.query.callbackUrl : undefined;

            if (callbackUrl && !isCallbackUrlAllowed(callbackUrl)) {
                res.status(400).json({ error: 'Invalid callbackUrl' });
                return;
            }

            const appId = process.env.META_APP_ID || '';
            const configId = process.env.META_CONFIG_ID || '';
            const redirectUri = callbackUrl || process.env.META_REDIRECT_URI ||
                `${process.env.API_BASE_URL || 'http://localhost:8000/api/v1'}/whatsapp/settings/embedded/callback`;

            if (!appId) {
                res.status(501).json({
                    error: 'Facebook Embedded Signup is not configured. Set META_APP_ID in environment.',
                });
                return;
            }

            const state = signState({
                tenantId,
                partnerId: typeof partnerId === 'string' ? partnerId : undefined,
                callbackUrl,
                iat: Date.now(),
            });

            res.json({
                data: { appId, configId, redirectUri, state },
            });
        } catch (error) { next(error); }
    };

    // ────────────────────────────────────────────
    // POST /settings/embedded/complete — exchange code for token & save config
    // ────────────────────────────────────────────
    const complete = async (req: any, res: any, next: any) => {
        try {
            const tenantId = req.context?.tenantId;
            if (!tenantId) { res.status(401).json({ error: 'Tenant required' }); return; }
            if (!getStateSecret()) {
                res.status(500).json({ error: 'Embedded signup state secret is not configured' });
                return;
            }

            const { code, state } = req.body;
            console.log(`[EmbeddedSignup] Received complete request. Code: ${code?.substring(0, 10)}..., State: ${state?.substring(0, 10)}...`);
            
            if (!state) {
                console.error('[EmbeddedSignup] Error: Signed state is missing from request body');
                res.status(400).json({ error: 'Signed state is required' });
                return;
            }
            
            const parsedState = state ? verifyState(state) : null;
            console.log('[EmbeddedSignup] Verified state payload:', parsedState);

            if (state && !parsedState) {
                console.error('[EmbeddedSignup] Error: Invalid or tampered state token');
                res.status(400).json({ error: 'Invalid or tampered state' });
                return;
            }

            if (parsedState?.tenantId && parsedState.tenantId !== tenantId) {
                res.status(403).json({ error: 'State tenant mismatch' });
                return;
            }

            if (!code) {
                res.status(400).json({ error: 'Authorization code is required' });
                return;
            }

            // Exchange the short-lived code for a System User Access Token
            const appId = process.env.META_APP_ID || '';
            const appSecret = process.env.META_APP_SECRET || '';
            const primaryRedirectUri = process.env.META_REDIRECT_URI || '';
            const callbackRedirectUri = (parsedState?.callbackUrl && isCallbackUrlAllowed(parsedState.callbackUrl)
                ? parsedState.callbackUrl
                : '') || '';

            if (!appId || !appSecret) {
                res.status(501).json({ error: 'Facebook app credentials are not configured' });
                return;
            }

            console.log('[EmbeddedSignup] Token exchange redirect candidates:', {
                callbackRedirectUri,
                primaryRedirectUri,
                noRedirectUri: true,
            });

            // Step 1: Exchange code → access token via Meta Graph API
            const exchangeForToken = async (redirectUri?: string) => {
                const tokenUrl = new URL('https://graph.facebook.com/v25.0/oauth/access_token');
                tokenUrl.searchParams.set('client_id', appId);
                tokenUrl.searchParams.set('client_secret', appSecret);
                tokenUrl.searchParams.set('code', code);
                if (redirectUri) {
                    tokenUrl.searchParams.set('redirect_uri', redirectUri);
                }
                const tokenResp = await fetch(tokenUrl.toString());
                return tokenResp.json() as Promise<any>;
            };

            const redirectCandidates: Array<{ label: string; redirectUri?: string }> = [];
            if (callbackRedirectUri) {
                redirectCandidates.push({ label: 'callbackRedirectUri', redirectUri: callbackRedirectUri });
            }
            if (primaryRedirectUri && primaryRedirectUri !== callbackRedirectUri) {
                redirectCandidates.push({ label: 'primaryRedirectUri', redirectUri: primaryRedirectUri });
            }
            redirectCandidates.push({ label: 'noRedirectUri' });

            let tokenData: any = null;
            for (const candidate of redirectCandidates) {
                tokenData = await exchangeForToken(candidate.redirectUri);
                console.log('[EmbeddedSignup] Token exchange attempt result:', {
                    candidate: candidate.label,
                    hasAccessToken: !!tokenData?.access_token,
                    error: tokenData?.error?.message || null,
                });
                if (!tokenData?.error && tokenData?.access_token) {
                    break;
                }
            }

            if (tokenData?.error) {
                res.status(400).json({
                    error: `Facebook token exchange failed: ${tokenData.error.message}`,
                });
                return;
            }

            const accessToken = tokenData?.access_token;

            // Step 2: Fetch shared WABA info
            const debugResp = await fetch(
                `https://graph.facebook.com/v25.0/debug_token?input_token=${accessToken}&access_token=${appId}|${appSecret}`
            );
            const debugData = await debugResp.json() as any;

            const wabaId = debugData?.data?.granular_scopes?.find(
                (s: any) => s.scope === 'whatsapp_business_management'
            )?.target_ids?.[0] || null;

            // Attempt to get phone number ID from granular scopes first
            let phoneIdFromScope = debugData?.data?.granular_scopes?.find(
                (s: any) => s.scope === 'whatsapp_business_messaging'
            )?.target_ids?.[0] || null;

            console.log(`[EmbeddedSignup] Derived WABA ID: ${wabaId}, Phone ID from scope: ${phoneIdFromScope}`);

            // Step 3: Fetch phone numbers from the WABA
            let phoneNumberId: string | null = null;
            let phoneDisplay: string | null = null;
            let verifiedName: string | null = null;

            if (wabaId) {
                // Step 2 (from Meta docs): Subscribe to webhooks on the customer's WABA
                try {
                    console.log(`[EmbeddedSignup] Subscribing app to WABA: ${wabaId}`);
                    await metaService.subscribeWabaToApp(wabaId, accessToken);
                } catch (err: any) {
                    console.warn(`[EmbeddedSignup] Initial webhook subscription failed for WABA ${wabaId}:`, err.message);
                }

                // Step 3 (from Meta docs): Fetch phone numbers from the WABA with retry
                const fetchPhoneWithRetry = async (attempts: number = 3, delayMs: number = 2000): Promise<any> => {
                    for (let i = 0; i < attempts; i++) {
                        console.log(`[EmbeddedSignup] Fetching phone numbers (attempt ${i + 1}/${attempts})...`);
                        const phonesResp = await fetch(
                            `https://graph.facebook.com/v25.0/${wabaId}/phone_numbers?access_token=${accessToken}`
                        );
                        const data = await phonesResp.json() as any;
                        
                        if (data?.data && data.data.length > 0) {
                            return data.data;
                        }

                        if (i < attempts - 1) {
                            console.log(`[EmbeddedSignup] No phones found yet, retrying in ${delayMs}ms...`);
                            await new Promise(resolve => setTimeout(resolve, delayMs));
                        }
                    }
                    return [];
                };

                const phonesList = await fetchPhoneWithRetry();
                // Prefer the phone ID from scope if it exists in the list, otherwise take the first one
                const phoneRecord = phoneIdFromScope 
                    ? (phonesList.find((p: any) => p.id === phoneIdFromScope) || phonesList[0])
                    : phonesList[0];

                if (phoneRecord) {
                    phoneNumberId = phoneRecord.id;
                    phoneDisplay = phoneRecord.display_phone_number;
                    verifiedName = phoneRecord.verified_name;

                    console.log(`[EmbeddedSignup] Selected phone number for registration: ${phoneNumberId} (${phoneDisplay})`);

                    // Step 3 (from Meta docs): Register the customer's phone number
                    if (phoneNumberId) {
                        try {
                            console.log(`[EmbeddedSignup] Registering phone number: ${phoneNumberId}`);
                            const registerPin = process.env.META_PHONE_REGISTER_PIN || '123456';
                            await metaService.registerPhoneNumber(phoneNumberId, accessToken, registerPin);
                            console.log(`[EmbeddedSignup] Phone registration successful for ${phoneNumberId}`);
                        } catch (err: any) {
                            console.error(`[EmbeddedSignup] Phone registration failed for ${phoneNumberId}:`, err.message);
                            // We don't throw here to allow the process to finish, but we logged the error
                        }
                    }
                } else {
                    console.warn(`[EmbeddedSignup] No phone numbers found in WABA ${wabaId} after retries.`);
                }
            }

            // Step 4: Persist to DB
            let sqlTenantId = tenantId;
            const isUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(sqlTenantId);
            if (!isUuid) {
                const tenantLookup = await pool.query(
                    'SELECT id FROM tenants WHERE slug = $1 LIMIT 1',
                    [tenantId]
                );
                let resolvedId = tenantLookup.rows?.[0]?.id as string | undefined;

                if (!resolvedId) {
                    const mongoTenant = await TenantModel.findOne({ slug: tenantId })
                        .select('email')
                        .lean();

                    if (mongoTenant?.email) {
                        const userLookup = await pool.query(
                            'SELECT tenant_id FROM users WHERE email = $1 ORDER BY created_at DESC LIMIT 1',
                            [mongoTenant.email]
                        );
                        resolvedId = userLookup.rows?.[0]?.tenant_id as string | undefined;
                    }
                }

                if (!resolvedId) {
                    res.status(400).json({ error: `Unable to resolve SQL tenant for slug: ${tenantId}` });
                    return;
                }
                sqlTenantId = resolvedId;
            }

            const { v4: uuidv4 } = await import('uuid');
            const saved = await waConfigRepo.save({
                tenantId: sqlTenantId,
                credentialSource: 'own',
                status: 'connected',
                onboardingMethod: 'embedded_signup',
                accessToken,
                phoneNumberId,
                wabaId,
                phoneDisplay,
                verifiedName,
                webhookVerifyToken: uuidv4(),
            });

            const tenant = await TenantModel.findOne({ slug: tenantId })
                .select('partnerId name email')
                .lean();

            const syncPartnerId = parsedState?.partnerId || tenant?.partnerId?.toString();

            if (syncPartnerId && tenant?.name && tenant?.email) {
                await partnerService.syncPartnerCustomerFromTenant({
                    partnerId: syncPartnerId,
                    tenantId,
                    businessName: tenant.name,
                    email: tenant.email,
                    plan: 'starter',
                });
            }

            let redirectTo: string | null = null;
            if (parsedState?.callbackUrl && isCallbackUrlAllowed(parsedState.callbackUrl)) {
                const callbackUrl = new URL(parsedState.callbackUrl);
                callbackUrl.searchParams.set('status', 'connected');
                callbackUrl.searchParams.set('tenantId', tenantId);
                if (wabaId) {
                    callbackUrl.searchParams.set('wabaId', wabaId);
                }
                if (phoneNumberId) {
                    callbackUrl.searchParams.set('phoneNumberId', phoneNumberId);
                }
                redirectTo = callbackUrl.toString();
            }

            res.json({
                data: {
                    success: true,
                    connection: mapToConnection(saved),
                    accessToken,
                    redirectTo,
                },
            });
        } catch (error) { next(error); }
    };

    return { getConfig, complete };
}

// ── Map DB row → UI-friendly shape (same as SettingsController) ──
function mapToConnection(row: any) {
    if (!row) return null;
    return {
        id: row.id,
        tenantId: row.tenant_id,
        connectionMethod: row.onboarding_method === 'embedded_signup' ? 'embedded' : 'manual',
        status: row.status === 'connected' ? 'connected' : row.status === 'error' ? 'error' : 'not_connected',
        whatsappBusinessAccountId: row.waba_id,
        phoneNumberId: row.phone_number_id,
        displayPhoneNumber: row.phone_display,
        businessName: row.business_name || row.verified_name,
        accessTokenLast4: row.access_token ? row.access_token.slice(-4) : null,
        webhookUrl: `${process.env.API_BASE_URL || 'http://localhost:5000/api/v1'}/whatsapp/webhook`,
        verifyToken: row.webhook_verify_token,
        connectedAt: row.connected_at,
        lastVerifiedAt: row.last_sync_at,
        errorMessage: row.error_message,
        createdAt: row.created_at,
        updatedAt: row.updated_at,
    };
}

export type EmbeddedSignupController = ReturnType<typeof createEmbeddedSignupController>;
