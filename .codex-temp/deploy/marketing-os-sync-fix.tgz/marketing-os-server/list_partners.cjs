const mongoose = require('mongoose');

async function listPartners() {
  try {
    await mongoose.connect('mongodb://localhost:27018/marketing-os');
    const partners = await mongoose.connection.db.collection('partners').find({}).toArray();
    console.log('Partners:', JSON.stringify(partners, null, 2));
    process.exit(0);
  } catch (err) {
    console.error('Error:', err);
    process.exit(1);
  }
}

listPartners();
