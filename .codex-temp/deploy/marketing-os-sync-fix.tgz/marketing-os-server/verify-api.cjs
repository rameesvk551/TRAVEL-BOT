const axios = require('axios');

const API_BASE_URL = 'http://localhost:8000/api/v1/api/v1'; // Based on my routing analysis
const PARTNER_KEY = 'mk_live_69c29fe5c6231cfeec0f14e0_fb54691a07f9407ea9443b95aa98c332';
const TEST_EMAIL = 'rameesvk551@gmail.com';

async function verify() {
  try {
    console.log(`Testing token generation for: ${TEST_EMAIL}`);
    const resp = await axios.post(
      `${API_BASE_URL}/tenants/${encodeURIComponent(TEST_EMAIL)}/token`,
      {},
      {
        headers: { 'x-api-key': PARTNER_KEY },
        timeout: 5000
      }
    );

    console.log('SUCCESS!');
    console.log('Response Status:', resp.status);
    console.log('Token received:', !!resp.data?.data?.token);
  } catch (error) {
    console.error('VERIFICATION FAILED');
    if (error.response) {
      console.error('Status:', error.response.status);
      console.error('Data:', error.response.data);
    } else {
      console.error('Error:', error.message);
    }
  }
}

verify();
