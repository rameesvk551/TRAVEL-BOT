import mongoose from 'mongoose';
import { config } from 'dotenv';
import { PartnerModel } from './src/modules/partner/partner.model.js';

config();

async function createPartner() {
  try {
    const mongoUri = process.env.MONGODB_URI || 'mongodb://localhost:27017/marketing-os';
    await mongoose.connect(mongoUri);
    console.log('Connected to MongoDB');

    const partnerData = {
      name: 'EdgesPlus',
      email: 'admin@edgesplus.com', // Change this to whatever email you log into the platform with
      commissionRate: 0.50, // 50% commission
      status: 'active',
      plan: 'enterprise',
      walletBalance: 0,
      totalCustomers: 0,
      totalRevenue: 0
    };

    // Use findOneAndUpdate with upsert to prevent unique constraint errors if it already exists
    const partner = await PartnerModel.findOneAndUpdate(
      { email: partnerData.email },
      partnerData,
      { new: true, upsert: true, runValidators: true }
    );
    
    console.log('\n✅ Partner successfully created/updated:');
    console.log('----------------------------------------');
    console.log(`Name:        ${partner.name}`);
    console.log(`Email:       ${partner.email} (Use this email to log in!)`);
    console.log(`Commission:  ${partner.commissionRate * 100}%`);
    console.log(`Ref Code:    ${partner.referralCode}`);
    console.log('----------------------------------------\n');
  } catch (error) {
    console.error('Failed to create partner:', error);
  } finally {
    await mongoose.disconnect();
    process.exit(0);
  }
}

createPartner();
