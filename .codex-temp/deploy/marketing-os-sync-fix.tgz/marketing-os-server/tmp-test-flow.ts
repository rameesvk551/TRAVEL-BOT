import mongoose from 'mongoose';
import dotenv from 'dotenv';
dotenv.config();

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27018/marketing-os?directConnection=true';

async function main() {
    await mongoose.connect(MONGO_URI);
    console.log('Connected to DB');

    const Flow = mongoose.connection.collection('flows');
    const flow = await Flow.findOne({});

    if (!flow) {
        console.log('Flow not found');
        process.exit(0);
    }

    console.log('--- EDGES ---');
    flow.edges.forEach((edge: any) => {
        console.log(`id: ${edge.id}, source: ${edge.source}, target: ${edge.target}, sourceHandle: ${edge.sourceHandle}`);
    });

    console.log('\n--- NODES WITH BUTTONS ---');
    flow.nodes.forEach((node: any) => {
        if (node.data?.buttons) {
            console.log(`nodeId: ${node.id}`);
            node.data.buttons.forEach((btn: any) => {
                console.log(`  - button id: ${btn.id}, title: ${btn.text || btn.title}`);
            });
        }
    });

    process.exit(0);
}

main().catch(console.error);
