# Partner Program Documentation (Complete)

This document explains everything related to the Partner Program in this codebase, including:

1. How a partner joins
2. What partners can see and manage
3. How partner webhooks work
4. How partners get API keys
5. How partners onboard their clients (tenants)
6. How client data syncs between your system and partner systems
7. How partner customers can log in

All examples below are derived from the current backend implementation.

## 1. Base URLs and Route Map

The app mounts routes like this:

- App prefix: `/api/v1`
- Module router mounted under that prefix
- Partner JWT routes: `/api/v1/partner/*`
- Auth routes: `/api/v1/auth/*`
- V1 API-key routes are currently mounted as: `/api/v1/api/v1/*`

So use:

- JWT/Auth base: `{{BASE_URL}}/api/v1`
- API key base: `{{BASE_URL}}/api/v1/api/v1`

Example:

```bash
BASE_URL="http://localhost:4000"
```

## 2. Partner Join Flow (Step-by-Step)

### Step 1: Register a user account

`POST /api/v1/auth/register`

```bash
curl -X POST "$BASE_URL/api/v1/auth/register" \
  -H "Content-Type: application/json" \
  -d '{
    "tenantName": "Acme Demo",
    "userName": "Acme Owner",
    "email": "owner@acme.com",
    "password": "StrongPass123!"
  }'
```

### Step 2: Login and get JWT

`POST /api/v1/auth/login`

```bash
curl -X POST "$BASE_URL/api/v1/auth/login" \
  -H "Content-Type: application/json" \
  -d '{
    "email": "owner@acme.com",
    "password": "StrongPass123!"
  }'
```

Save the returned `token` as `JWT_TOKEN`.

### Step 3: Join partner program

`POST /api/v1/partner/join` (JWT required)

```bash
curl -X POST "$BASE_URL/api/v1/partner/join" \
  -H "Authorization: Bearer $JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Acme Agency"
  }'
```

What is created:

- `Partner` record with email from logged-in user
- default `commissionRate = 0.50`
- `status = active`
- auto-generated `referralCode`
- referral link format: `FRONTEND_URL/signup?ref=<CODE>`

## 3. What a Partner Can See and Manage

All endpoints below require JWT and use the authenticated partner context.

### 3.1 Partner dashboard

`GET /api/v1/partner/dashboard`

```bash
curl "$BASE_URL/api/v1/partner/dashboard" \
  -H "Authorization: Bearer $JWT_TOKEN"
```

Includes:

- partner summary
- `totalCustomers`, `totalRevenue`, `walletBalance`
- `withdrawableAmount`, `pendingWithdrawals`
- recent customers
- recent withdraw requests

### 3.2 Partner customers

`GET /api/v1/partner/customers`

```bash
curl "$BASE_URL/api/v1/partner/customers" \
  -H "Authorization: Bearer $JWT_TOKEN"
```

### 3.3 Partner commissions

`GET /api/v1/partner/commissions`

```bash
curl "$BASE_URL/api/v1/partner/commissions" \
  -H "Authorization: Bearer $JWT_TOKEN"
```

### 3.4 Withdraw request

`POST /api/v1/partner/withdraw`

```bash
curl -X POST "$BASE_URL/api/v1/partner/withdraw" \
  -H "Authorization: Bearer $JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{ "amount": 250.00 }'
```

Validation:

- amount must be positive
- amount cannot exceed `walletBalance - pendingWithdrawals`

### 3.5 Partner webhook URL settings

`PUT /api/v1/partner/settings`

```bash
curl -X PUT "$BASE_URL/api/v1/partner/settings" \
  -H "Authorization: Bearer $JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "webhookUrl": "https://partner.example.com/marketing-os/webhooks"
  }'
```

Webhook URL rules:

- must be `https://...`
- only localhost testing allows `http://localhost/...`
- private/local blocked hosts are rejected

### 3.6 Rotate partner webhook secret

`POST /api/v1/partner/settings/webhook-secret/rotate`

```bash
curl -X POST "$BASE_URL/api/v1/partner/settings/webhook-secret/rotate" \
  -H "Authorization: Bearer $JWT_TOKEN"
```

Returns one-time plain secret, pattern like:

- `pkwhsec_<random>`

Store it securely. It is not retrievable later.

### 3.7 Tenant management from Partner Dashboard APIs (JWT)

The partner router also exposes tenant CRUD under JWT auth:

- `POST /api/v1/partner/tenants`
- `GET /api/v1/partner/tenants`
- `GET /api/v1/partner/tenants/{tenantId}`
- `PUT /api/v1/partner/tenants/{tenantId}`
- `DELETE /api/v1/partner/tenants/{tenantId}`

Create tenant example:

```bash
curl -X POST "$BASE_URL/api/v1/partner/tenants" \
  -H "Authorization: Bearer $JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Client via Dashboard",
    "email": "hello@clientdashboard.com"
  }'
```

## 4. How Partner Gets API Key

There are 2 implemented ways for key rotation/generation:

### Option A: Partner endpoint

`POST /api/v1/partner/api-key/migrate`

```bash
curl -X POST "$BASE_URL/api/v1/partner/api-key/migrate" \
  -H "Authorization: Bearer $JWT_TOKEN"
```

### Option B: V1 partner self-service endpoint

`POST /api/v1/api/v1/partners/api-key`

This endpoint is behind API key middleware, so it is best for rotating an already active key.

```bash
curl -X POST "$BASE_URL/api/v1/api/v1/partners/api-key" \
  -H "x-api-key: $PARTNER_API_KEY"
```

Generated format:

- `mk_live_<partnerObjectId>_<random>`

Storage behavior:

- raw key returned once
- only `apiKeyHash` and `apiKeyPrefix` stored

## 5. Partner API Key Authentication

For API-key protected partner APIs, add header:

- `x-api-key: <YOUR_PARTNER_API_KEY>`

The middleware:

1. parses key format to extract partner hint
2. does fast DB lookup using `_id + apiKeyPrefix`
3. verifies with bcrypt
4. caches for 60 seconds in-memory
5. attaches `req.partner` context

## 6. How Partner Onboards Their Client (Tenant)

All endpoints in this section use API key base:

- `{{BASE_URL}}/api/v1/api/v1`

and require:

- `x-api-key: <partner_api_key>`

### Step 1: Create tenant

`POST /api/v1/api/v1/tenants`

```bash
curl -X POST "$BASE_URL/api/v1/api/v1/tenants" \
  -H "x-api-key: $PARTNER_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Client One",
    "email": "ops@clientone.com",
    "phone": "+15550001111",
    "settings": {
      "timezone": "Asia/Kolkata",
      "language": "en",
      "businessType": "retail"
    },
    "rateLimits": {
      "messagesPerMinute": 80,
      "messagesPerDay": 20000
    },
    "metadata": {
      "source": "partner_portal"
    }
  }'
```

Behavior:

- tenant slug is auto-generated (`<name>-<random8>`)
- tenant linked to partner
- customer sync entry is created/updated for partner

### Step 2: List tenants

`GET /api/v1/api/v1/tenants?status=active&search=client&page=1&limit=20`

```bash
curl "$BASE_URL/api/v1/api/v1/tenants?status=active&page=1&limit=20" \
  -H "x-api-key: $PARTNER_API_KEY"
```

### Step 3: Get a tenant by slug/id

`GET /api/v1/api/v1/tenants/{tenantSlugOrId}`

```bash
curl "$BASE_URL/api/v1/api/v1/tenants/client-one-1234abcd" \
  -H "x-api-key: $PARTNER_API_KEY"
```

### Step 4: Update tenant

`PUT /api/v1/api/v1/tenants/{tenantSlugOrId}`

```bash
curl -X PUT "$BASE_URL/api/v1/api/v1/tenants/client-one-1234abcd" \
  -H "x-api-key: $PARTNER_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Client One Pvt Ltd",
    "email": "admin@clientone.com",
    "settings": {
      "language": "en"
    }
  }'
```

### Step 5: Deactivate tenant (soft)

`DELETE /api/v1/api/v1/tenants/{tenantSlugOrId}`

```bash
curl -X DELETE "$BASE_URL/api/v1/api/v1/tenants/client-one-1234abcd" \
  -H "x-api-key: $PARTNER_API_KEY"
```

## 7. Tenant WhatsApp Onboarding by Partner

### Link WhatsApp account

`POST /api/v1/api/v1/tenants/{tenantId}/whatsapp`

```bash
curl -X POST "$BASE_URL/api/v1/api/v1/tenants/client-one-1234abcd/whatsapp" \
  -H "x-api-key: $PARTNER_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "wabaId": "123456789012345",
    "businessName": "Client One WABA",
    "accessToken": "EAAB...",
    "credentialSource": "managed",
    "webhookVerifyToken": "my-verify-token",
    "phoneNumbers": [
      {
        "phoneNumberId": "987654321000111",
        "displayNumber": "+1 555 000 1111"
      }
    ]
  }'
```

### Get WhatsApp account (token masked)

`GET /api/v1/api/v1/tenants/{tenantId}/whatsapp`

```bash
curl "$BASE_URL/api/v1/api/v1/tenants/client-one-1234abcd/whatsapp" \
  -H "x-api-key: $PARTNER_API_KEY"
```

## 8. Partner Messaging and Event APIs

Both route groups require API key and tenant ownership checks.

Tenant ownership is resolved from one of:

- `body.tenantId`
- `params.tenantId`
- `query.tenantId`
- `x-tenant-id` header

### 8.1 Send message

`POST /api/v1/api/v1/messages/send`

```bash
curl -X POST "$BASE_URL/api/v1/api/v1/messages/send" \
  -H "x-api-key: $PARTNER_API_KEY" \
  -H "x-tenant-id: client-one-1234abcd" \
  -H "Content-Type: application/json" \
  -H "x-idempotency-key: msg-001" \
  -d '{
    "to": "+15550002222",
    "type": "template",
    "templateName": "order_update",
    "languageCode": "en",
    "variables": {
      "name": "John",
      "orderId": "ORD-1001"
    }
  }'
```

### 8.2 Get message status

`GET /api/v1/api/v1/messages/{messageId}/status`

```bash
curl "$BASE_URL/api/v1/api/v1/messages/0b73f298-857f-4a8d-8a1b-1177cbe6b637/status" \
  -H "x-api-key: $PARTNER_API_KEY" \
  -H "x-tenant-id: client-one-1234abcd"
```

### 8.3 List messages

`GET /api/v1/api/v1/messages?status=queued&page=1&limit=20`

```bash
curl "$BASE_URL/api/v1/api/v1/messages?status=queued&page=1&limit=20" \
  -H "x-api-key: $PARTNER_API_KEY" \
  -H "x-tenant-id: client-one-1234abcd"
```

### 8.4 Ingest external event

`POST /api/v1/api/v1/events`

```bash
curl -X POST "$BASE_URL/api/v1/api/v1/events" \
  -H "x-api-key: $PARTNER_API_KEY" \
  -H "x-tenant-id: client-one-1234abcd" \
  -H "Content-Type: application/json" \
  -d '{
    "event": "order_paid",
    "phone": "+15550002222",
    "data": {
      "orderId": "ORD-1001",
      "amount": 399.99,
      "customerName": "John"
    }
  }'
```

### 8.5 Event mapping CRUD

Create mapping:

```bash
curl -X POST "$BASE_URL/api/v1/api/v1/events/mappings" \
  -H "x-api-key: $PARTNER_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "tenantId": "client-one-1234abcd",
    "eventName": "order_paid",
    "action": "send_template",
    "templateName": "order_paid_template",
    "languageCode": "en",
    "variableMapping": {
      "name": "data.customerName",
      "order": "data.orderId",
      "amount": "data.amount"
    }
  }'
```

List mappings:

```bash
curl "$BASE_URL/api/v1/api/v1/events/mappings?tenantId=client-one-1234abcd" \
  -H "x-api-key: $PARTNER_API_KEY"
```

Update mapping:

```bash
curl -X PUT "$BASE_URL/api/v1/api/v1/events/mappings/<mappingId>" \
  -H "x-api-key: $PARTNER_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{ "isActive": false }'
```

Delete mapping:

```bash
curl -X DELETE "$BASE_URL/api/v1/api/v1/events/mappings/<mappingId>" \
  -H "x-api-key: $PARTNER_API_KEY"
```

## 9. How Partner Webhook Works

Your system sends webhook callbacks to partner webhook URL when WhatsApp webhook events are processed.

Currently supported outbound partner webhook events:

- `message`
- `status`

Delivery conditions:

1. tenant slug resolves to a partner
2. partner status is active
3. partner has `webhookUrl`
4. partner has `webhookSecretEncrypted` configured
5. webhook URL passes SSRF/security validation

Delivery behavior:

- HTTP `POST` to partner webhook URL
- timeout: 5 seconds
- headers:
  - `content-type: application/json`
  - `x-marketing-os-signature: sha256=<hmac_hex>`
  - `x-marketing-os-event: message|status`
  - `x-marketing-os-timestamp: <ISO timestamp>`

Payload body (signed JSON):

```json
{
  "tenantId": "client-one-1234abcd",
  "eventType": "message",
  "timestamp": "2026-03-25T12:00:00.000Z",
  "data": {
    "providerMessageId": "wamid....",
    "senderPhone": "+15550002222",
    "recipientPhone": "+15550001111",
    "messageType": "TEXT"
  }
}
```

### Partner-side webhook verification (Node.js example)

```js
import crypto from 'crypto';
import express from 'express';

const app = express();

// Keep raw JSON body exact for signature check
app.use(express.json({
  verify: (req, _res, buf) => {
    req.rawBody = Buffer.from(buf);
  },
}));

app.post('/marketing-os/webhooks', (req, res) => {
  const secret = process.env.MARKETING_OS_WEBHOOK_SECRET;
  const sigHeader = req.header('x-marketing-os-signature') || '';

  const expected = crypto
    .createHmac('sha256', secret)
    .update(req.rawBody)
    .digest('hex');

  const received = sigHeader.replace(/^sha256=/, '');
  const ok =
    received.length === expected.length &&
    crypto.timingSafeEqual(Buffer.from(received), Buffer.from(expected));

  if (!ok) {
    return res.status(401).json({ ok: false, error: 'invalid_signature' });
  }

  const event = req.header('x-marketing-os-event');
  const payload = req.body;

  // Process event safely
  console.log('event=', event, 'tenant=', payload.tenantId);

  return res.status(200).json({ ok: true });
});

app.listen(8080, () => {
  console.log('Webhook server running on :8080');
});
```

## 10. How Client Sync Works (Your System <-> Partner System)

There are two sync layers.

### A. Internal partner customer sync (inside your DB)

1. Referral signup path:
   - user registers with `referralCode`
   - system resolves partner by referral code
   - `registerReferredCustomer(...)` stores partner-customer link

2. Partner tenant onboarding path:
   - partner creates/updates tenant via API key
   - controller calls `syncPartnerCustomerFromTenant(...)`
   - this upserts by `tenantId` or email under the same partner

### B. External partner system sync (outbound webhooks)

When WhatsApp inbound message/status happens, your webhook controller calls:

- `dispatchPartnerWebhookByTenant({ tenantId, eventType, data })`

Partner system receives signed events and updates their own CRM/analytics/order state.

## 11. How Partner Customer Can Login to Your System

There are two common patterns in current code:

### Pattern 1: Standard tenant user login

1. Register user via `POST /api/v1/auth/register`
2. Login via `POST /api/v1/auth/login`
3. Receive JWT token and use authenticated modules

Login example:

```bash
curl -X POST "$BASE_URL/api/v1/auth/login" \
  -H "Content-Type: application/json" \
  -d '{
    "email": "admin@clientone.com",
    "password": "StrongPass123!"
  }'
```

### Pattern 2: Referred signup through partner link

Partner shares referral link with code:

- `https://your-frontend/signup?ref=<PARTNER_REFERRAL_CODE>`

The frontend should pass `referralCode` in register payload:

```bash
curl -X POST "$BASE_URL/api/v1/auth/register" \
  -H "Content-Type: application/json" \
  -d '{
    "tenantName": "Client Referred",
    "userName": "Client Admin",
    "email": "client@referred.com",
    "password": "StrongPass123!",
    "referralCode": "ACME1234"
  }'
```

This creates tenant + admin user, and links that customer to the partner for commission tracking.

## 12. End-to-End Quick Script

```bash
# 1) Login partner user
JWT_TOKEN=$(curl -s -X POST "$BASE_URL/api/v1/auth/login" \
  -H "Content-Type: application/json" \
  -d '{"email":"owner@acme.com","password":"StrongPass123!"}' | jq -r '.data.token')

# 2) Join partner (if not already)
curl -X POST "$BASE_URL/api/v1/partner/join" \
  -H "Authorization: Bearer $JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name":"Acme Agency"}'

# 3) Rotate API key
PARTNER_API_KEY=$(curl -s -X POST "$BASE_URL/api/v1/partner/api-key/migrate" \
  -H "Authorization: Bearer $JWT_TOKEN" | jq -r '.data.apiKey')

# 4) Configure partner webhook URL
curl -X PUT "$BASE_URL/api/v1/partner/settings" \
  -H "Authorization: Bearer $JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"webhookUrl":"https://partner.example.com/marketing-os/webhooks"}'

# 5) Rotate webhook secret and store it in partner system
curl -X POST "$BASE_URL/api/v1/partner/settings/webhook-secret/rotate" \
  -H "Authorization: Bearer $JWT_TOKEN"

# 6) Create tenant under partner via API key
curl -X POST "$BASE_URL/api/v1/api/v1/tenants" \
  -H "x-api-key: $PARTNER_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"name":"Client One","email":"ops@clientone.com"}'
```

## 13. Security and Operational Notes

1. Always store API key and webhook secret in a secure vault.
2. Treat both as one-time reveal credentials.
3. Use idempotency keys for message send retries.
4. Validate webhook signatures with raw body.
5. Keep partner webhook endpoint highly available and return 2xx quickly.
6. If partner webhook fails or times out, your main processing still continues (best-effort callback).

## 14. Source Files (Implementation References)

- `src/modules/partner/partner.routes.ts`
- `src/modules/partner/partner.controller.ts`
- `src/modules/partner/partner.service.ts`
- `src/modules/partner/partner.model.ts`
- `src/modules/tenant/tenant.routes.ts`
- `src/modules/tenant/tenant.controller.ts`
- `src/modules/tenant/tenant.service.ts`
- `src/middlewares/apikey.middleware.ts`
- `src/middlewares/rbac.middleware.ts`
- `src/routes/index.ts`
- `src/routes/v1.router.ts`
- `src/app.ts`
- `src/modules/auth/auth.routes.ts`
- `src/modules/auth/auth.controller.ts`
- `src/modules/auth/auth.service.ts`
- `src/modules/whatsapp/whatsapp.routes.ts`
- `src/modules/whatsapp/controllers/WebhookController.ts`
