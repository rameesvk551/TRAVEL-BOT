const mongoose = require('mongoose');

async function fixPartnerWebhook() {
  try {
    await mongoose.connect('mongodb://localhost:27018/marketing-os');
    console.log('Connected to MongoDB');

    const res = await mongoose.connection.db.collection('partners').updateOne(
      { email: 'wayon@gmail.com' },
      { $set: { webhookUrl: 'http://localhost:6767/api/whatsapp/webhook' } }
    );

    console.log('Update result:', res);
    process.exit(0);
  } catch (err) {
    console.error('Error:', err);
    process.exit(1);
  }
}

fixPartnerWebhook();
