const mongoose = require('mongoose');
const { v4: uuidv4 } = require('uuid');
const bcrypt = require('bcryptjs');

const MONGO_URI = 'mongodb://localhost:27018/marketing-os?directConnection=true';

const PartnerSchema = new mongoose.Schema({
  name: String,
  email: String,
  apiKeyHash: String,
  apiKeyPrefix: String,
  status: String,
}, { timestamps: true });

const Partner = mongoose.model('Partner', PartnerSchema);

async function run() {
  await mongoose.connect(MONGO_URI);
  console.log('Connected to MongoDB');

  let partner = await Partner.findOne({ email: 'rameesvk551@gmail.com' });
  if (!partner) {
    partner = await Partner.findOne();
  }

  if (partner) {
    const randomPart = uuidv4().replace(/-/g, '');
    const apiKey = `mk_live_${partner._id}_${randomPart}`;
    const apiKeyHash = await bcrypt.hash(apiKey, 12);
    const apiKeyPrefix = randomPart.slice(0, 12);

    await Partner.findByIdAndUpdate(partner._id, {
      $set: { apiKeyHash, apiKeyPrefix },
    });

    console.log('PARTNER_ID:', partner._id.toString());
    console.log('API_KEY:', apiKey);
  } else {
    console.log('No partner found');
  }
  process.exit(0);
}

run().catch(err => {
  console.error(err);
  process.exit(1);
});
