import { MongoClient } from 'mongodb';

// Correct URI from EC2 .env
const uri = 'mongodb://localhost:27018/marketing-os?directConnection=true';

async function run() {
  const client = new MongoClient(uri);
  try {
    await client.connect();
    const db = client.db();
    const partners = db.collection('partners');

    console.log('Searching for Wayo partner in marketing-os DB...');
    const partner = await partners.findOne({ name: /Wayo/i });

    if (!partner) {
      console.error('Wayo partner NOT found! Searching all partners...');
      const all = await partners.find({}).toArray();
      console.log('All partners:', all.map(p => p.name));
      return;
    }

    console.log('Found Partner:', partner.name, 'Current URL:', partner.webhookUrl);

    const result = await partners.updateOne(
      { _id: partner._id },
      { $set: { webhookUrl: 'http://localhost:6767/api/whatsapp/webhook' } }
    );

    console.log('Update result:', result);
    console.log('Wayo Webhook URL corrected to: http://localhost:6767/api/whatsapp/webhook');

  } catch (err) {
    console.error('Database error:', err);
  } finally {
    await client.close();
  }
}

run().catch(console.dir);
