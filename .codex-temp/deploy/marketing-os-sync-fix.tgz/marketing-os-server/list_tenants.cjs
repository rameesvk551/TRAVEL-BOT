const mongoose = require('mongoose');

async function run() {
    try {
        await mongoose.connect('mongodb://localhost:27018/marketing-os?directConnection=true');
        const tenants = await mongoose.connection.db.collection('tenants').find({}).toArray();
        console.log('--- TENANTS START ---');
        console.log(JSON.stringify(tenants.map(t => ({slug: t.slug, id: t._id, partnerId: t.partnerId})), null, 2));
        console.log('--- TENANTS END ---');
        process.exit(0);
    } catch (err) {
        console.error(err);
        process.exit(1);
    }
}

run();
