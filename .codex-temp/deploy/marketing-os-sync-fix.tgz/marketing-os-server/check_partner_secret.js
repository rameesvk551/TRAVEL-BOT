import { MongoClient } from 'mongodb';
import crypto from 'crypto';

// Correct URI from EC2 .env
const uri = 'mongodb://localhost:27018/marketing-os?directConnection=true';
const WAYO_SLUG = 'wayo-82ac6fd3';
const ENCRYPTION_KEY = 'wato_secret_encryption_key_2026_03_29';

function decryptSecret(encryptedData) {
  try {
    const [ivHex, encryptedHex] = encryptedData.split(':');
    if (!ivHex || !encryptedHex) return encryptedData; // Not encrypted?
    
    const key = crypto.createHash('sha256').update(ENCRYPTION_KEY).digest();
    const iv = Buffer.from(ivHex, 'hex');
    const encryptedText = Buffer.from(encryptedHex, 'hex');
    const decipher = crypto.createDecipheriv('aes-256-cbc', key, iv);
    let decrypted = decipher.update(encryptedText);
    decrypted = Buffer.concat([decrypted, decipher.final()]);
    return decrypted.toString();
  } catch (err) {
    console.error('Decryption failed:', err.message);
    return encryptedData;
  }
}

async function run() {
  const client = new MongoClient(uri);
  try {
    await client.connect();
    const db = client.db();
    
    console.log(`1. Finding Partner via Slug: ${WAYO_SLUG}...`);
    const customer = await db.collection('partnercustomers').findOne({ tenantId: WAYO_SLUG });
    if (!customer) throw new Error('Customer not found');
    
    const partner = await db.collection('partners').findOne({ _id: customer.partnerId });
    if (!partner) throw new Error('Partner not found');

    console.log('2. Partner Name:', partner.name);
    console.log('3. Webhook URL:', partner.webhookUrl);
    
    const secret = decryptSecret(partner.webhookSecretEncrypted);
    console.log('4. Decrypted Secret:', secret);

    // Also check the raw encrypted value
    console.log('5. Raw Encrypted Secret:', partner.webhookSecretEncrypted);

  } catch (err) {
    console.error('Error:', err.message);
  } finally {
    await client.close();
  }
}

run().catch(console.dir);
