-- First, find the partner_id for the tenant
UPDATE partners
SET 
  webhook_url = 'http://localhost:6767/api/whatsapp/flow',
  webhook_secret_encrypted = 'N0lSQUltSTlpRW10Y2IrdEozRURuWjMzc0ZHSFFVTEVGRTNVdE1oZnlEYz0=', -- This is 'pkwhsec_wayo_restore_2026' encrypted with the Marketing OS key
  status = 'active'
WHERE id IN (
  SELECT partner_id::uuid FROM tenants WHERE slug = 'b78ba0d3-9efc-464e-bced-30784ae2e58e'
);

-- Also update the webhookUrl in whatsapp_business_configs if it exists for this tenant
UPDATE whatsapp_business_configs
SET webhook_url = 'http://localhost:6767/api/whatsapp/flow'
WHERE tenant_id = 'b78ba0d3-9efc-464e-bced-30784ae2e58e';
