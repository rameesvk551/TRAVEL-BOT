import axios from 'axios';

async function testLogin() {
  try {
    const res = await axios.post('http://localhost:8000/auth/login', {
      email: 'admin@edgesplus.com',
      password: 'password' // We don't know the password, but we can do a mock if needed, or query the DB to force a password update to test
    });
    console.log('Login Response:', res.data.data.user);
  } catch (error: any) {
    console.error('Login Failed:', error.response?.data || error.message);
  }
}

testLogin();
