import { Typography, Button, Avatar } from 'antd';
import {
    ClockCircleOutlined,
    ShoppingOutlined,
    BellOutlined,
    CustomerServiceOutlined,
    SettingOutlined
} from '@ant-design/icons';
import { useAuth } from '../../context/AuthContext';

const { Text } = Typography;

export function AppHeader() {
    const { user } = useAuth();

    return (
        <div style={{ 
            background: '#fff', 
            height: 64, 
            padding: '0 16px 0 24px', 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'space-between',
            borderBottom: '1px solid #E5E7EB',
            position: 'sticky',
            top: 0,
            zIndex: 99
        }}>
            {/* Left Logo */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <div style={{ background: '#00A884', borderRadius: 6, width: 28, height: 28, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <ShoppingOutlined style={{ color: '#fff', fontSize: 16 }} />
                </div>
                <Text style={{ fontSize: 20, fontWeight: 700, color: '#111827' }}>
                    Interakt
                </Text>
            </div>

            {/* Right Section */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
                <div style={{ 
                    display: 'flex', alignItems: 'center', gap: 8, 
                    background: '#E8F5E9', padding: '6px 12px', borderRadius: 4,
                    border: '1px solid #C8E6C9'
                }}>
                    <Text style={{ color: '#2E7D32', fontWeight: 600, fontSize: 13 }}>Trial Plan</Text>
                    <Text style={{ color: '#2E7D32', fontSize: 13 }}><ClockCircleOutlined /> 13 Days Left</Text>
                </div>
                <Button type="primary" style={{
                    background: '#1B4D3E', borderColor: '#1B4D3E', color: '#fff',
                    fontWeight: 600, borderRadius: 4, padding: '0 20px', height: 32
                }}>
                    Subscribe
                </Button>
                <BellOutlined style={{ fontSize: 20, color: '#4B5563', cursor: 'pointer', marginLeft: 8 }} />
                <CustomerServiceOutlined style={{ fontSize: 20, color: '#4B5563', cursor: 'pointer' }} />
                <SettingOutlined style={{ fontSize: 20, color: '#4B5563', cursor: 'pointer' }} />
                <Avatar style={{ background: '#1B4D3E', color: '#fff', fontWeight: 'bold', marginLeft: 8 }} size={32}>
                    {user?.name?.charAt(0).toUpperCase() || 'W'}
                </Avatar>
            </div>
        </div>
    );
}

export default AppHeader;
