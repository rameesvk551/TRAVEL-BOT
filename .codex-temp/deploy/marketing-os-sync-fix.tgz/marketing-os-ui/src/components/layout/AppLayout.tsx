import { useMemo, useState } from 'react';
import type { ReactNode } from 'react';
import { Outlet, useLocation, useNavigate } from 'react-router-dom';
import { Layout, Menu, Typography, Avatar, Drawer, Dropdown } from 'antd';
import type { MenuProps } from 'antd';
import {
    RocketOutlined,
    SettingOutlined,
    MenuFoldOutlined,
    MenuUnfoldOutlined,
    WhatsAppOutlined,
    CloseOutlined,
    ShopOutlined,
    AppstoreOutlined,
    ShoppingCartOutlined,
    UserOutlined,
    LogoutOutlined,
    PartitionOutlined,
    StarOutlined,
    BankOutlined,
    WalletOutlined,
    BookOutlined,
    KeyOutlined,
    TeamOutlined,
} from '@ant-design/icons';
import { useAuth } from '../../context/AuthContext';
import { useResponsive } from '../../hooks/useResponsive';
import { whatsappSectionItems } from '../../features/whatsapp/navigation';
import { AppHeader } from './AppHeader';

const { Sider, Content } = Layout;
const { Text } = Typography;

type MenuItem = Required<MenuProps>['items'][number];

// Removed configureBusinessChildren

const commerceChildren = [
    { key: '/configure-business/products', icon: <AppstoreOutlined />, label: 'Products' },
    { key: '/configure-business/categories', icon: <AppstoreOutlined />, label: 'Categories' },
    { key: '/configure-business/orders', icon: <ShoppingCartOutlined />, label: 'Orders' },
];

const whatsappChildren = whatsappSectionItems.map((item) => ({
    key: item.path,
    icon: item.icon,
    label: item.label,
}));

const partnerChildren = [
    { key: '/partner', icon: <AppstoreOutlined />, label: 'Dashboard' },
    { key: '/partner/tenants', icon: <BankOutlined />, label: 'Tenants' },
    { key: '/partner/customers', icon: <TeamOutlined />, label: 'Customers' },
    { key: '/partner/commissions', icon: <WalletOutlined />, label: 'Commissions' },
    { key: '/partner/withdraw', icon: <WalletOutlined />, label: 'Withdraw' },
    { key: '/partner/api-key', icon: <KeyOutlined />, label: 'API Keys' },
    { key: '/partner/docs', icon: <BookOutlined />, label: 'API Docs' },
    { key: '/partner/settings', icon: <SettingOutlined />, label: 'Settings' },
];

const navItems: MenuItem[] = [
    {
        key: '/', // Added the Dashboard link so they can navigate back to it easily
        icon: <AppstoreOutlined />,
        label: 'Dashboard',
    },
    {
        key: '/flows',
        icon: <PartitionOutlined />,
        label: 'Flows',
    },
    {
        key: '/whatsapp',
        icon: <WhatsAppOutlined />,
        label: 'WhatsApp',
        children: whatsappChildren,
    },
    {
        key: 'whatsapp-commerce',
        icon: <ShopOutlined />,
        label: 'Commerce',
        children: commerceChildren,
    },
    {
        type: 'divider',
    },
    {
        key: '/settings',
        icon: <SettingOutlined />,
        label: 'Settings',
    },
];

const mobilePrimaryNav = [
    {
        key: '/',
        label: 'Dash',
        icon: <AppstoreOutlined />,
        matches: (path: string) => path === '/',
    },
    {
        key: '/whatsapp/chats',
        label: 'WA',
        icon: <WhatsAppOutlined />,
        matches: (path: string) => path.startsWith('/whatsapp'),
    },
    {
        key: '/flows',
        label: 'Flows',
        icon: <PartitionOutlined />,
        matches: (path: string) => path.startsWith('/flows'),
    },
    {
        key: '/configure-business/products',
        label: 'Commerce',
        icon: <ShopOutlined />,
        matches: (path: string) => 
            path === '/configure-business/products' || 
            path === '/configure-business/categories' || 
            path === '/configure-business/orders',
    },

    {
        key: '/partner',
        label: 'Partner',
        icon: <StarOutlined />,
        matches: (path: string) => path.startsWith('/partner'),
    },
    {
        key: '/settings',
        label: 'Settings',
        icon: <SettingOutlined />,
        matches: (path: string) => path.startsWith('/settings'),
    },
];

const whatsappMobileNav = [
    {
        key: '/whatsapp/chats',
        label: 'Chats',
        icon: whatsappSectionItems[0].icon,
        matches: (path: string) => path === '/whatsapp/chats' || path.startsWith('/whatsapp/chats/'),
    },
    {
        key: '/whatsapp/templates',
        label: 'Templates',
        icon: whatsappSectionItems[1].icon,
        matches: (path: string) => path === '/whatsapp/templates' || path.startsWith('/whatsapp/templates/'),
    },
    {
        key: '/whatsapp/broadcast',
        label: 'Broadcast',
        icon: whatsappSectionItems[2].icon,
        matches: (path: string) => path === '/whatsapp/broadcast' || path.startsWith('/whatsapp/broadcast/'),
    },
    {
        key: '/whatsapp/analytics',
        label: 'Analytics',
        icon: whatsappSectionItems[5].icon,
        matches: (path: string) => path === '/whatsapp/analytics' || path.startsWith('/whatsapp/analytics/'),
    },
    {
        key: '/settings',
        label: 'Settings',
        icon: <SettingOutlined />,
        matches: (path: string) => path.startsWith('/settings'),
    },
];

function getSelectedMenuKey(pathname: string) {
    if (pathname === '/') {
        return '/';
    }

    if (pathname.startsWith('/whatsapp')) {
        const child = whatsappChildren.find(
            (item) => pathname === item.key || pathname.startsWith(`${item.key}/`)
        );
        return child?.key ?? '/whatsapp/chats';
    }

    if (pathname.startsWith('/configure-business')) {
        let child: any = commerceChildren.find(
            (item) => pathname === item.key || pathname.startsWith(`${item.key}/`)
        );
        return child?.key ?? '/configure-business/products';
    }

    if (pathname.startsWith('/settings')) {
        return '/settings';
    }

    if (pathname.startsWith('/instagram')) {
        return '/instagram';
    }

    if (pathname.startsWith('/flows')) {
        return '/flows';
    }

    if (pathname.startsWith('/partner')) {
        const child = partnerChildren.find(
            (item) => pathname === item.key || pathname.startsWith(`${item.key}/`)
        );
        return child?.key ?? '/partner';
    }

    return '/crm';
}

export function AppLayout() {
    const [desktopCollapsed, setDesktopCollapsed] = useState(true);
    const [isHovered, setIsHovered] = useState(false);
    const [mobileDrawerOpen, setMobileDrawerOpen] = useState(false);
    const [openKeys, setOpenKeys] = useState<string[]>([]);
    const location = useLocation();
    const navigate = useNavigate();
    const { user, logout } = useAuth();
    const { isMobile, isTablet } = useResponsive();
    
    // Sidebar is physically collapsed if:
    // 1. Not mobile AND
    // 2. Either it's a tablet OR desktop is set to collapsed AND
    // 3. User is NOT hovering over it
    const isEffectivelyCollapsed = !isMobile && (isTablet || desktopCollapsed);
    const collapsed = isEffectivelyCollapsed && !isHovered;

    const selectedKey = useMemo(() => getSelectedMenuKey(location.pathname), [location.pathname]);
    const userInitial = user?.name?.charAt(0).toUpperCase() || 'U';
    // Let layout shift on hover to match standard Sider behavior
    const sidebarWidth = collapsed ? 84 : 288;
    const mobileNavItems = location.pathname.startsWith('/whatsapp') ? whatsappMobileNav : mobilePrimaryNav;
    const menuOpenKeys = collapsed && !isMobile
        ? []
        : Array.from(new Set([
            ...(location.pathname.startsWith('/whatsapp') ? ['/whatsapp'] : []),
            ...(location.pathname.startsWith('/configure-business') ? 
                (commerceChildren.some(c => location.pathname === c.key || location.pathname.startsWith(`${c.key}/`)) ? ['whatsapp-commerce'] : []) 
                : []),
            ...(location.pathname.startsWith('/flows') ? ['/flows'] : []),
            ...(location.pathname.startsWith('/partner') ? ['partner-section'] : []),
            ...openKeys,
        ]));

    const handleMenuClick: MenuProps['onClick'] = ({ key }) => {
        navigate(key);
        setMobileDrawerOpen(false);
    };

    const userMenuItems: MenuProps['items'] = [
        {
            key: 'profile',
            label: 'Profile',
            icon: <UserOutlined />,
            disabled: true,
        },
        {
            key: 'partner',
            label: user?.partnerId ? 'Partner Dashboard' : 'Become a Partner',
            icon: <StarOutlined style={{ color: user?.partnerId ? '#F59E0B' : '#10B981' }} />,
            onClick: () => navigate(user?.partnerId ? '/partner' : '/partner/join'),
        },
        {
            type: 'divider',
        },
        {
            key: 'logout',
            label: 'Log out',
            icon: <LogoutOutlined />,
            danger: true,
            onClick: () => logout(),
        },
    ];

    const sidebarContent = (
        <div style={{ display: 'flex', minHeight: '100%', flexDirection: 'column' }}>
            <div
                style={{
                    height: 'var(--header-height, 64px)',
                    display: 'flex',
                    alignItems: 'center',
                    padding: collapsed && !isMobile ? '0 20px' : '0 24px',
                    borderBottom: '1px solid rgba(255,255,255,0.06)',
                    gap: 14,
                    cursor: 'pointer',
                    transition: 'all 0.2s ease',
                }}
                onClick={() => {
                    navigate('/');
                    setMobileDrawerOpen(false);
                }}
            >
                <div
                    style={{
                        width: 40,
                        height: 40,
                        borderRadius: 14,
                        background: 'linear-gradient(135deg, #4F46E5 0%, #06B6D4 100%)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        flexShrink: 0,
                        boxShadow: '0 14px 28px rgba(79,70,229,0.34)',
                    }}
                >
                    <RocketOutlined style={{ color: '#fff', fontSize: 18 }} />
                </div>
                {(!collapsed || isMobile) && (
                    <div style={{ overflow: 'hidden', flex: 1 }}>
                        <Text
                            strong
                            style={{
                                color: '#fff',
                                fontSize: 16,
                                whiteSpace: 'nowrap',
                                display: 'block',
                                lineHeight: 1.1,
                                fontFamily: "'Plus Jakarta Sans', 'Inter', sans-serif",
                            }}
                        >
                            Marketing OS
                        </Text>
                        <Text
                            style={{
                                color: '#94A3B8',
                                fontSize: 11,
                                whiteSpace: 'nowrap',
                                display: 'block',
                                marginTop: 2,
                                letterSpacing: '0.08em',
                                textTransform: 'uppercase',
                            }}
                        >
                            Mobile-first workspace
                        </Text>
                    </div>
                )}
                {isMobile && (
                    <CloseOutlined
                        style={{ color: '#94A3B8', fontSize: 18, marginLeft: 'auto', cursor: 'pointer' }}
                        onClick={(event) => {
                            event.stopPropagation();
                            setMobileDrawerOpen(false);
                        }}
                    />
                )}
            </div>

            {!collapsed && !isMobile && (
                <div style={{ padding: '18px 24px 0' }}>
                    <Text style={{ color: '#64748B', fontSize: 11, letterSpacing: '0.12em', textTransform: 'uppercase' }}>
                        Workspace
                    </Text>
                </div>
            )}

            <Menu
                mode="inline"
                selectedKeys={[selectedKey]}
                onClick={handleMenuClick}
                openKeys={menuOpenKeys}
                onOpenChange={(keys) => setOpenKeys(keys as string[])}
                items={useMemo(() => {
                    const isPartnerPage = location.pathname.startsWith('/partner');
                    const showPartnerSection = user?.partnerId || isPartnerPage;
                    
                    return [
                        ...navItems,
                        ...(showPartnerSection ? [
                            {
                                key: 'partner-section',
                                icon: <StarOutlined style={{ color: '#F59E0B' }} />,
                                label: 'Partner',
                                children: partnerChildren,
                            }
                        ] : [])
                    ];
                }, [user?.partnerId, location.pathname])}
                style={{
                    background: 'transparent',
                    border: 'none',
                    padding: '12px 10px 0',
                    flex: 1,
                }}
                theme="dark"
            />

            <div style={{ marginTop: 'auto', padding: collapsed && !isMobile ? '0 12px 16px' : '0 16px 16px' }}>
                <Dropdown menu={{ items: userMenuItems }} placement="topRight" trigger={['click']}>
                    <div
                        style={{
                            display: 'flex',
                            alignItems: 'center',
                            gap: 12,
                            padding: collapsed && !isMobile ? '12px 10px' : '14px 14px',
                            borderRadius: 20,
                            background: 'rgba(148,163,184,0.08)',
                            border: '1px solid rgba(148,163,184,0.12)',
                            cursor: 'pointer',
                            transition: 'background 0.2s',
                        }}
                        className="user-profile-trigger"
                    >
                        <Avatar
                            size={collapsed && !isMobile ? 36 : 40}
                            style={{
                                background: 'linear-gradient(135deg, #4F46E5, #06B6D4)',
                                color: '#fff',
                                flexShrink: 0,
                            }}
                            icon={!user?.name ? <UserOutlined /> : undefined}
                        >
                            {user?.name ? userInitial : undefined}
                        </Avatar>
                        {(!collapsed || isMobile) && (
                            <div style={{ minWidth: 0, flex: 1 }}>
                                <Text strong style={{ color: '#F8FAFC', display: 'block', lineHeight: 1.2 }}>
                                    {user?.name || 'User'}
                                </Text>
                                <Text
                                    style={{
                                        color: '#94A3B8',
                                        fontSize: 12,
                                        display: 'block',
                                        whiteSpace: 'nowrap',
                                        overflow: 'hidden',
                                        textOverflow: 'ellipsis',
                                    }}
                                >
                                    {user?.tenantName || user?.email || 'Workspace'}
                                </Text>
                            </div>
                        )}
                    </div>
                </Dropdown>

                {!isMobile && (
                    <button
                        type="button"
                        onClick={() => setDesktopCollapsed((value) => !value)}
                        style={{
                            marginTop: 12,
                            width: '100%',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: collapsed ? 'center' : 'flex-start',
                            gap: 10,
                            padding: '12px 14px',
                            borderRadius: 16,
                            border: '1px solid rgba(148,163,184,0.12)',
                            background: 'transparent',
                            color: '#94A3B8',
                            cursor: 'pointer',
                        }}
                    >
                        {desktopCollapsed ? <MenuUnfoldOutlined /> : <MenuFoldOutlined />}
                        {!collapsed && <span style={{ fontSize: 13, fontWeight: 600 }}>
                            {desktopCollapsed ? 'Pin navigation' : 'Collapse navigation'}
                        </span>}
                    </button>
                )}
            </div>
        </div>
    );

    return (
        <Layout style={{ minHeight: '100svh', background: '#F8FAFC' }}>
            {isMobile ? (
                <Drawer
                    open={mobileDrawerOpen}
                    onClose={() => setMobileDrawerOpen(false)}
                    placement="left"
                    width="min(320px, calc(100vw - 24px))"
                    className="mobile-sidebar-drawer"
                    styles={{ body: { padding: 0, background: '#0F172A' } }}
                >
                    <div style={{ background: '#0F172A', minHeight: '100svh' }}>
                        {sidebarContent}
                    </div>
                </Drawer>
            ) : (
                <Sider
                    collapsible
                    collapsed={collapsed}
                    onCollapse={setDesktopCollapsed}
                    onMouseEnter={() => setIsHovered(true)}
                    onMouseLeave={() => setIsHovered(false)}
                    trigger={null}
                    width={288}
                    collapsedWidth={84}
                    style={{
                        background: '#0F172A',
                        borderRight: '1px solid rgba(255,255,255,0.06)',
                        overflow: 'hidden',
                        height: '100svh',
                        position: 'fixed',
                        left: 0,
                        top: 0,
                        bottom: 0,
                        zIndex: 100,
                    }}
                >
                    {sidebarContent}
                </Sider>
            )}

            <Layout
                style={{
                    marginLeft: isMobile ? 0 : sidebarWidth,
                    transition: 'margin-left 0.2s ease',
                    minHeight: '100svh',
                    display: 'flex',
                    flexDirection: 'column',
                    background: '#F8FAFC' // Simple background, avoiding complex gradients that might show through gaps
                }}
            >
                <AppHeader />
                <Content
                    style={{
                        padding: isMobile
                            ? '0 0 calc(var(--mobile-nav-height, 84px) + 22px)'
                            : 0,
                        flex: 1,
                        display: 'flex',
                        flexDirection: 'column',
                        overflowX: 'hidden',
                    }}
                >
                    <div className="animate-fade-in" style={{ flex: 1, width: '100%', display: 'flex', flexDirection: 'column' }}>
                        <Outlet />
                    </div>
                </Content>

                {isMobile && (
                    <nav className="mobile-bottom-nav" aria-label="Primary navigation">
                        <div className="mobile-bottom-nav__inner">
                            {mobileNavItems.map((item) => {
                                const active = item.matches(location.pathname);

                                return (
                                    <button
                                        key={item.key}
                                        type="button"
                                        className={`mobile-bottom-nav__button${active ? ' mobile-bottom-nav__button--active' : ''}`}
                                        onClick={() => navigate(item.key)}
                                        aria-current={active ? 'page' : undefined}
                                    >
                                        <span className="mobile-bottom-nav__icon">{item.icon as ReactNode}</span>
                                        <span>{item.label}</span>
                                    </button>
                                );
                            })}
                        </div>
                    </nav>
                )}
            </Layout>
        </Layout>
    );
}
