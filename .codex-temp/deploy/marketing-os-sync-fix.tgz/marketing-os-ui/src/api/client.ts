import axios from 'axios';
import config from '../config';

function resolveTenantId(): string {
    if (typeof window === 'undefined') {
        return 'default';
    }

    const urlTenantId = new URLSearchParams(window.location.search).get('tenantId');
    if (urlTenantId) {
        localStorage.setItem('tenantId', urlTenantId);
        return urlTenantId;
    }

    return localStorage.getItem('tenantId') || 'default';
}

// Create Axios client
const client = axios.create({
    baseURL: config.apiUrl,
    headers: {
        'Content-Type': 'application/json',
    },
});

// Add Interceptors for Auth
client.interceptors.request.use((config) => {
    const token = localStorage.getItem('token');
    if (token) {
        config.headers['Authorization'] = `Bearer ${token}`;
    }
    // Tenant ID
    config.headers['x-tenant-id'] = resolveTenantId();
    
    if (config.data instanceof FormData) {
        delete config.headers['Content-Type'];
    }
    
    return config;
});

export default client;
