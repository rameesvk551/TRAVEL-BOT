import { useState } from 'react';
import { Typography, Progress, Button, Collapse, Input } from 'antd';
import {
    PlayCircleOutlined,
    CalendarOutlined,
    FacebookFilled,
    CheckCircleFilled,
    BulbOutlined,
    DownOutlined,
    QrcodeOutlined,
    AndroidOutlined,
    AppleOutlined,
    MessageOutlined,
} from '@ant-design/icons';

const { Text } = Typography;
const { Panel } = Collapse;

export function MainDashboard() {
    const [accessCode, setAccessCode] = useState('');

    return (
        <div style={{ minHeight: '100svh', background: '#F8FAFC' }}>

            <div style={{ padding: '24px' }}>
            <div style={{ display: 'flex', gap: 24 }}>
                <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 24 }}>
                    {/* Access Code Banner */}
                    <div style={{
                        background: 'linear-gradient(90deg, #FFF3E0 0%, #FFE0B2 100%)',
                        borderRadius: 8,
                        padding: '20px 24px',
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center'
                    }}>
                        <div style={{ display: 'flex', gap: 16, alignItems: 'center' }}>
                            <div style={{ background: '#FF9800', padding: 10, borderRadius: 8 }}>
                                <BulbOutlined style={{ color: '#FFF', fontSize: 20 }} />
                            </div>
                            <div>
                                <Text style={{ fontSize: 16, fontWeight: 600, color: '#E65100', display: 'block' }}>
                                    Got any offer access code?
                                </Text>
                                <Text style={{ color: '#E65100', fontSize: 13, opacity: 0.8 }}>
                                    Activate your special discounted offer now!
                                </Text>
                            </div>
                        </div>
                        <div style={{ display: 'flex', gap: 12 }}>
                            <Input
                                placeholder="Enter access code"
                                value={accessCode}
                                onChange={(e) => setAccessCode(e.target.value)}
                                style={{ width: 200, height: 40, borderRadius: 6 }}
                            />
                            <Button
                                type="primary"
                                style={{
                                    background: '#FF9800',
                                    borderColor: '#FF9800',
                                    height: 40,
                                    borderRadius: 6,
                                    fontWeight: 600,
                                    padding: '0 24px'
                                }}
                            >
                                Activate &rarr;
                            </Button>
                        </div>
                    </div>

                    {/* Setup Guide */}
                    <div style={{ background: '#fff', borderRadius: 8, padding: 24, boxShadow: '0 1px 3px rgba(0,0,0,0.05)' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
                            <Text style={{ fontSize: 18, fontWeight: 600, color: '#111827', display: 'flex', alignItems: 'center', gap: 8 }}>
                                <MessageOutlined /> Setup FREE WhatsApp Business Account
                            </Text>
                            <Text style={{ color: '#6B7280', fontSize: 14 }}>3 steps left</Text>
                        </div>

                        <Collapse
                            defaultActiveKey={['1']}
                            ghost
                            expandIconPosition="end"
                            expandIcon={({ isActive }) => <DownOutlined rotate={isActive ? 180 : 0} style={{ color: '#9CA3AF' }} />}
                            style={{
                                background: '#F8FAFC',
                                borderRadius: 8,
                                border: '1px solid #E2E8F0'
                            }}
                        >
                            <Panel
                                header={
                                    <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                                        <div style={{ position: 'relative' }}>
                                            <CheckCircleFilled style={{ color: '#F59E0B', fontSize: 24 }} />
                                        </div>
                                        <Text style={{ fontSize: 15, fontWeight: 600, color: '#1F2937' }}>Apply for WhatsApp Business API</Text>
                                    </div>
                                }
                                key="1"
                                className="setup-panel-custom"
                                style={{ padding: 12 }}
                            >
                                <div style={{ display: 'flex', gap: 24, marginTop: 16 }}>
                                    <div style={{ flex: 1 }}>
                                        <Text style={{ color: '#00A884', fontWeight: 500, fontSize: 14, display: 'block', marginBottom: 12 }}>
                                            Click on Continue With Facebook to apply for WhatsApp Business API
                                        </Text>
                                        <Text style={{ color: '#6B7280', fontSize: 13, display: 'block', marginBottom: 8 }}>
                                            Requirements to apply for WhatsApp Business API
                                        </Text>
                                        <ul style={{ color: '#6B7280', fontSize: 13, paddingLeft: 16, marginBottom: 16, listStyleType: 'circle' }}>
                                            <li>A Registered Business & Working Website.</li>
                                        </ul>
                                        <a href="#" style={{ color: '#00A884', fontSize: 14, display: 'flex', alignItems: 'center', gap: 6, fontWeight: 500 }}>
                                            <PlayCircleOutlined /> How to apply for WhatsApp Business API?
                                        </a>
                                    </div>
                                    <div style={{ width: 340 }}>
                                        <div style={{ background: '#E5E7EB', height: 180, borderRadius: 8, marginBottom: 16, position: 'relative', overflow: 'hidden' }}>
                                            <img
                                                src="https://img.youtube.com/vi/aL3Ff4z4W04/maxresdefault.jpg"
                                                alt="Video thumbnail"
                                                style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                                                onError={(e) => {
                                                    // Fallback if image fails to load
                                                    e.currentTarget.style.display = 'none';
                                                }}
                                            />
                                            <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'rgba(0,0,0,0.1)' }}>
                                                <PlayCircleOutlined style={{ fontSize: 48, color: 'white', opacity: 0.8 }} />
                                            </div>
                                        </div>
                                        <div style={{ display: 'flex', gap: 12 }}>
                                            <Button icon={<CalendarOutlined />} style={{ flex: 1, height: 40, borderRadius: 6 }}>
                                                Schedule Meetings
                                            </Button>
                                            <Button type="primary" icon={<FacebookFilled />} style={{ flex: 1, height: 40, borderRadius: 6, background: '#1877F2', borderColor: '#1877F2' }}>
                                                Continue With Facebook
                                            </Button>
                                        </div>
                                    </div>
                                </div>
                            </Panel>
                        </Collapse>
                        <div style={{ marginTop: 16, paddingLeft: 12 }}>
                            <Button type="text" style={{ color: '#6B7280' }}>
                                All Steps <DownOutlined />
                            </Button>
                        </div>
                    </div>
                </div>

                <div style={{ width: 320, display: 'flex', flexDirection: 'column', gap: 24 }}>
                    {/* Right Sidebar */}
                    <div style={{ background: '#fff', borderRadius: 8, padding: 24, boxShadow: '0 1px 3px rgba(0,0,0,0.05)' }}>
                        <Text style={{ fontSize: 15, fontWeight: 600, color: '#111827', display: 'block', marginBottom: 16 }}>
                            Scan to download the Mobile app
                        </Text>
                        <div style={{ display: 'flex', gap: 16, marginBottom: 24 }}>
                            <div style={{ background: '#F3F4F6', padding: 8, borderRadius: 8 }}>
                                <QrcodeOutlined style={{ fontSize: 64, color: '#374151' }} />
                            </div>
                            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                                <Button size="small" style={{ background: '#000', color: '#fff', border: 'none', height: 32, display: 'flex', alignItems: 'center', gap: 6 }}>
                                    <AndroidOutlined /> Google Play
                                </Button>
                                <Button size="small" style={{ background: '#000', color: '#fff', border: 'none', height: 32, display: 'flex', alignItems: 'center', gap: 6 }}>
                                    <AppleOutlined /> App Store
                                </Button>
                            </div>
                        </div>

                        <div style={{ borderTop: '1px solid #E5E7EB', paddingTop: 16, marginBottom: 24 }}>
                            <Text style={{ fontSize: 12, color: '#9CA3AF', background: '#fff', padding: '0 8px', marginTop: -24, display: 'inline-block', marginBottom: 12 }}>
                                Key Features
                            </Text>
                            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px 0' }}>
                                <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, color: '#4B5563' }}>
                                    <div style={{ width: 6, height: 6, borderRadius: '50%', background: '#10B981' }} /> Real-time notifications
                                </div>
                                <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, color: '#4B5563' }}>
                                    <div style={{ width: 6, height: 6, borderRadius: '50%', background: '#10B981' }} /> Live Chat
                                </div>
                                <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, color: '#4B5563' }}>
                                    <div style={{ width: 6, height: 6, borderRadius: '50%', background: '#10B981' }} /> Ads Management
                                </div>
                                <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, color: '#4B5563' }}>
                                    <div style={{ width: 6, height: 6, borderRadius: '50%', background: '#10B981' }} /> Analytics Dashboard
                                </div>
                            </div>
                        </div>

                        <div style={{ marginBottom: 24 }}>
                            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8, fontSize: 13 }}>
                                <Text style={{ color: '#4B5563' }}>Free Service Conversation</Text>
                            </div>
                            <Progress percent={3} showInfo={false} strokeColor="#00A884" trailColor="#E5E7EB" style={{ marginBottom: 4 }} />
                            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, color: '#6B7280' }}>
                                <span>0</span>
                                <span>Unlimited</span>
                            </div>
                        </div>

                        <div style={{ marginBottom: 16 }}>
                            <Text style={{ fontSize: 13, color: '#4B5563', display: 'block', marginBottom: 4 }}>
                                WhatsApp Conversation Credits (WCC)
                            </Text>
                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                                <Text style={{ fontSize: 18, fontWeight: 600 }}>₹ 50.00</Text>
                                <Button type="primary" size="small" style={{ background: '#00695C', borderColor: '#00695C' }}>
                                    Buy More
                                </Button>
                            </div>
                        </div>

                        <div style={{ marginBottom: 16, borderTop: '1px solid #E5E7EB', paddingTop: 16 }}>
                            <Text style={{ fontSize: 13, color: '#4B5563', display: 'block', marginBottom: 4 }}>
                                Advertisement Credits
                            </Text>
                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                                <Text style={{ fontSize: 18, fontWeight: 600 }}>₹ 0</Text>
                                <Button size="small">
                                    Buy Credits
                                </Button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </div>
            {/* Feedback / Chat widget floaters normally go in Layout, not the page body, but we'll leave that to the Layout wrapper */}
        </div>
    );
}

export default MainDashboard;
