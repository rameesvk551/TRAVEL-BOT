import React, { useState } from 'react';
import {
    Card, Table, Input, Select, DatePicker, Tag, Typography, Button, Space, Drawer,
    Descriptions, Divider, Statistic, Row, Col, Modal, Form, Tooltip
} from 'antd';
import {
    SearchOutlined, EyeOutlined, FilterOutlined, PlusOutlined,
    WhatsAppOutlined, DollarOutlined, ShoppingCartOutlined,
    ClockCircleOutlined, CheckCircleOutlined, EnvironmentOutlined
} from '@ant-design/icons';
import type { ColumnsType } from 'antd/es/table';
import { useOrders, useUpdateOrderStatus, useOrderStats, useCreateManualOrder, useSendInvoice } from '../hooks/useOrderQueries';
import type { Order, OrderQuery } from '../types';
import dayjs from 'dayjs';

const { Title, Text } = Typography;
const { RangePicker } = DatePicker;

const orderStatusColors: Record<string, string> = {
    pending: 'warning',
    confirmed: 'processing',
    shipped: 'purple',
    delivered: 'success',
    cancelled: 'error',
};

const paymentStatusColors: Record<string, string> = {
    pending: 'warning',
    paid: 'success',
    failed: 'error',
    refunded: 'default',
};

export const OrdersPage: React.FC = () => {
    const [queryParams, setQueryParams] = useState<OrderQuery>({ page: 1, limit: 10 });
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
    const [drawerVisible, setDrawerVisible] = useState(false);
    const [createModalVisible, setCreateModalVisible] = useState(false);
    const [createForm] = Form.useForm();

    const { data: ordersData, isLoading } = useOrders(queryParams);
    const { data: statsData } = useOrderStats();
    const updateStatusMutation = useUpdateOrderStatus();
    const createOrderMutation = useCreateManualOrder();
    const sendInvoiceMutation = useSendInvoice();

    const handleSearch = (value: string) => {
        setQueryParams(prev => ({ ...prev, search: value, page: 1 }));
    };

    const handleFilterChange = (key: string, value: any) => {
        setQueryParams(prev => ({ ...prev, [key]: value, page: 1 }));
    };

    const handleDateRange = (_dates: any, dateStrings: [string, string]) => {
        setQueryParams(prev => ({
            ...prev,
            startDate: dateStrings[0] || undefined,
            endDate: dateStrings[1] || undefined,
            page: 1,
        }));
    };

    const handleTableChange = (pagination: any) => {
        setQueryParams(prev => ({
            ...prev,
            page: pagination.current,
            limit: pagination.pageSize,
        }));
    };

    const viewOrderDetails = (order: Order) => {
        setSelectedOrder(order);
        setDrawerVisible(true);
    };

    const handleStatusUpdate = (orderId: string, type: 'orderStatus' | 'paymentStatus', value: string) => {
        updateStatusMutation.mutate({
            id: orderId,
            data: { [type]: value }
        });
        if (selectedOrder && selectedOrder._id === orderId) {
            setSelectedOrder({ ...selectedOrder, [type]: value } as Order);
        }
    };

    const handleCreateOrder = (values: any) => {
        createOrderMutation.mutate({
            customerName: values.customerName,
            phoneNumber: values.phoneNumber,
            products: values.products || [],
            notes: values.notes,
            source: 'manual',
        }, {
            onSuccess: () => {
                setCreateModalVisible(false);
                createForm.resetFields();
            },
        });
    };

    const columns: ColumnsType<Order> = [
        {
            title: 'Order ID',
            dataIndex: 'orderId',
            key: 'orderId',
            render: (text) => <Text strong>{text}</Text>,
        },
        {
            title: 'Customer',
            dataIndex: 'customerName',
            key: 'customerName',
            render: (text, record) => (
                <div>
                    <div>{text}</div>
                    <div style={{ fontSize: 12, color: '#8c8c8c' }}>{record.phoneNumber}</div>
                </div>
            )
        },
        {
            title: 'Date',
            dataIndex: 'createdAt',
            key: 'createdAt',
            render: (date) => dayjs(date).format('MMM D, YYYY h:mm A'),
        },
        {
            title: 'Total',
            dataIndex: 'totalAmount',
            key: 'totalAmount',
            render: (amount) => <Text strong>₹{amount}</Text>,
        },
        {
            title: 'Order Status',
            dataIndex: 'orderStatus',
            key: 'orderStatus',
            render: (status: string) => (
                <Tag color={orderStatusColors[status] || 'default'}>
                    {status.toUpperCase()}
                </Tag>
            ),
        },
        {
            title: 'Payment',
            dataIndex: 'paymentStatus',
            key: 'paymentStatus',
            render: (status: string) => (
                <Tag color={paymentStatusColors[status] || 'default'}>
                    {status.toUpperCase()}
                </Tag>
            ),
        },
        {
            title: 'Action',
            key: 'action',
            width: 80,
            render: (_, record) => (
                <Button type="text" icon={<EyeOutlined />} onClick={() => viewOrderDetails(record)}>
                    View
                </Button>
            ),
        },
    ];

    return (
        <div>
            {/* ── Stats Cards ── */}
            <Row gutter={16} style={{ marginBottom: 24 }}>
                <Col xs={24} sm={12} md={6}>
                    <Card style={{ borderRadius: 12 }}>
                        <Statistic
                            title="Total Orders"
                            value={statsData?.totalOrders || 0}
                            prefix={<ShoppingCartOutlined style={{ color: '#4F46E5' }} />}
                        />
                    </Card>
                </Col>
                <Col xs={24} sm={12} md={6}>
                    <Card style={{ borderRadius: 12 }}>
                        <Statistic
                            title="Revenue"
                            value={statsData?.totalRevenue || 0}
                            prefix={<DollarOutlined style={{ color: '#10B981' }} />}
                            formatter={(value) => `₹${Number(value).toLocaleString()}`}
                        />
                    </Card>
                </Col>
                <Col xs={24} sm={12} md={6}>
                    <Card style={{ borderRadius: 12 }}>
                        <Statistic
                            title="Pending Orders"
                            value={statsData?.pendingOrders || 0}
                            prefix={<ClockCircleOutlined style={{ color: '#F59E0B' }} />}
                        />
                    </Card>
                </Col>
                <Col xs={24} sm={12} md={6}>
                    <Card style={{ borderRadius: 12 }}>
                        <Statistic
                            title="Paid"
                            value={statsData?.paidOrders || 0}
                            prefix={<CheckCircleOutlined style={{ color: '#10B981' }} />}
                        />
                    </Card>
                </Col>
            </Row>

            {/* ── Main Table ── */}
            <Card style={{ borderRadius: 12 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 24, alignItems: 'center' }}>
                    <div>
                        <Title level={4} style={{ margin: 0 }}>Orders</Title>
                        <Text type="secondary">View and manage customer orders</Text>
                    </div>
                    <Button
                        type="primary"
                        icon={<PlusOutlined />}
                        onClick={() => setCreateModalVisible(true)}
                    >
                        Create Order
                    </Button>
                </div>

                <div style={{ marginBottom: 16, display: 'flex', gap: 16, flexWrap: 'wrap' }}>
                    <Input
                        placeholder="Search order ID or customer..."
                        prefix={<SearchOutlined />}
                        style={{ width: 250 }}
                        value={searchTerm}
                        onChange={e => setSearchTerm(e.target.value)}
                        onPressEnter={() => handleSearch(searchTerm)}
                    />

                    <Select
                        placeholder="Order Status"
                        style={{ width: 150 }}
                        allowClear
                        onChange={(val) => handleFilterChange('orderStatus', val)}
                        options={[
                            { label: 'Pending', value: 'pending' },
                            { label: 'Confirmed', value: 'confirmed' },
                            { label: 'Shipped', value: 'shipped' },
                            { label: 'Delivered', value: 'delivered' },
                            { label: 'Cancelled', value: 'cancelled' },
                        ]}
                    />

                    <Select
                        placeholder="Payment Status"
                        style={{ width: 150 }}
                        allowClear
                        onChange={(val) => handleFilterChange('paymentStatus', val)}
                        options={[
                            { label: 'Pending', value: 'pending' },
                            { label: 'Paid', value: 'paid' },
                            { label: 'Failed', value: 'failed' },
                            { label: 'Refunded', value: 'refunded' },
                        ]}
                    />

                    <RangePicker onChange={handleDateRange} />

                    <Button onClick={() => handleSearch(searchTerm)} icon={<FilterOutlined />}>Filter</Button>
                </div>

                <Table
                    columns={columns}
                    dataSource={ordersData?.data || []}
                    rowKey="_id"
                    loading={isLoading}
                    pagination={{
                        current: queryParams.page,
                        pageSize: queryParams.limit,
                        total: ordersData?.total || 0,
                        showSizeChanger: true,
                    }}
                    onChange={handleTableChange}
                />
            </Card>

            {/* ── Order Details Drawer ── */}
            <Drawer
                title={`Order Details: ${selectedOrder?.orderId}`}
                placement="right"
                width={600}
                onClose={() => setDrawerVisible(false)}
                open={drawerVisible}
            >
                {selectedOrder && (
                    <div>
                        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 24 }}>
                            <Space direction="vertical">
                                <Text type="secondary">Order Date</Text>
                                <Text strong>{dayjs(selectedOrder.createdAt).format('MMMM D, YYYY h:mm A')}</Text>
                            </Space>
                            <Space direction="vertical">
                                <Text type="secondary">Source</Text>
                                <Tag color="blue">{selectedOrder.source.toUpperCase()}</Tag>
                            </Space>
                        </div>

                        <Divider />

                        <Title level={5}>Customer Information</Title>
                        <Descriptions column={2} style={{ marginBottom: 24 }}>
                            <Descriptions.Item label="Name">{selectedOrder.customerName}</Descriptions.Item>
                            <Descriptions.Item label="Phone">{selectedOrder.phoneNumber}</Descriptions.Item>
                        </Descriptions>

                        {/* ── Shipping Address ── */}
                        {(selectedOrder as any).shippingAddress && (
                            <>
                                <Divider />
                                <Title level={5}><EnvironmentOutlined style={{ marginRight: 8 }} />Shipping Address</Title>
                                <Card size="small" style={{ background: '#F8FAFC', borderRadius: 8, marginBottom: 16 }} bordered={false}>
                                    <Text strong>{(selectedOrder as any).shippingAddress.name}</Text>
                                    <br />
                                    <Text>{(selectedOrder as any).shippingAddress.addressLine1}</Text>
                                    {(selectedOrder as any).shippingAddress.addressLine2 && (
                                        <><br /><Text>{(selectedOrder as any).shippingAddress.addressLine2}</Text></>
                                    )}
                                    <br />
                                    <Text>{(selectedOrder as any).shippingAddress.city}, {(selectedOrder as any).shippingAddress.state} - {(selectedOrder as any).shippingAddress.pincode}</Text>
                                </Card>
                            </>
                        )}

                        <Divider />

                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
                            <Title level={5} style={{ margin: 0 }}>Order Status</Title>
                            <Space>
                                <Select
                                    value={selectedOrder.orderStatus}
                                    style={{ width: 130 }}
                                    onChange={(val) => handleStatusUpdate(selectedOrder._id, 'orderStatus', val)}
                                    options={[
                                        { label: 'Pending', value: 'pending' },
                                        { label: 'Confirmed', value: 'confirmed' },
                                        { label: 'Shipped', value: 'shipped' },
                                        { label: 'Delivered', value: 'delivered' },
                                        { label: 'Cancelled', value: 'cancelled' },
                                    ]}
                                />
                                <Select
                                    value={selectedOrder.paymentStatus}
                                    style={{ width: 130 }}
                                    onChange={(val) => handleStatusUpdate(selectedOrder._id, 'paymentStatus', val)}
                                    options={[
                                        { label: 'Pending (Pay)', value: 'pending' },
                                        { label: 'Paid', value: 'paid' },
                                        { label: 'Failed', value: 'failed' },
                                        { label: 'Refunded', value: 'refunded' },
                                    ]}
                                />
                            </Space>
                        </div>

                        {/* ── Payment Method ── */}
                        {(selectedOrder as any).paymentMethod && (
                            <div style={{ marginBottom: 16 }}>
                                <Text type="secondary">Payment Method: </Text>
                                <Tag color={(selectedOrder as any).paymentMethod === 'cod' ? 'orange' : 'blue'}>
                                    {((selectedOrder as any).paymentMethod || '').toUpperCase()}
                                </Tag>
                            </div>
                        )}

                        <Divider />

                        <Title level={5}>Order Items</Title>
                        <Table
                            dataSource={selectedOrder.products}
                            rowKey={(record) => typeof record.product === 'object' ? record.product._id : record.product}
                            pagination={false}
                            columns={[
                                {
                                    title: 'Product',
                                    key: 'product',
                                    render: (_, record) => typeof record.product === 'object' ? record.product.productName : 'Product ID',
                                },
                                {
                                    title: 'Price',
                                    dataIndex: 'price',
                                    key: 'price',
                                    render: (price) => `₹${price}`,
                                },
                                {
                                    title: 'Qty',
                                    dataIndex: 'quantity',
                                    key: 'quantity',
                                },
                                {
                                    title: 'Total',
                                    key: 'total',
                                    render: (_, record) => <Text strong>₹{record.price * record.quantity}</Text>,
                                },
                            ]}
                        />

                        <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 24 }}>
                            <Space direction="vertical" align="end">
                                <Title level={4} style={{ margin: 0 }}>Total: ₹{selectedOrder.totalAmount}</Title>
                                {selectedOrder.notes && (
                                    <Text type="secondary" style={{ fontStyle: 'italic' }}>Note: {selectedOrder.notes}</Text>
                                )}
                            </Space>
                        </div>

                        {/* ── Actions ── */}
                        {selectedOrder.source === 'whatsapp' && selectedOrder.phoneNumber && (
                            <>
                                <Divider />
                                <Space>
                                    <Tooltip title="Send payment invoice via WhatsApp">
                                        <Button
                                            type="primary"
                                            icon={<WhatsAppOutlined />}
                                            onClick={() => sendInvoiceMutation.mutate(selectedOrder._id)}
                                            loading={sendInvoiceMutation.isPending}
                                            style={{ background: '#25D366', borderColor: '#25D366' }}
                                        >
                                            Send WhatsApp Invoice
                                        </Button>
                                    </Tooltip>
                                </Space>
                            </>
                        )}
                    </div>
                )}
            </Drawer>

            {/* ── Create Order Modal ── */}
            <Modal
                title="Create Manual Order"
                open={createModalVisible}
                onCancel={() => setCreateModalVisible(false)}
                onOk={() => createForm.submit()}
                confirmLoading={createOrderMutation.isPending}
                width={500}
            >
                <Form
                    form={createForm}
                    layout="vertical"
                    onFinish={handleCreateOrder}
                >
                    <Form.Item
                        label="Customer Name"
                        name="customerName"
                        rules={[{ required: true, message: 'Please enter customer name' }]}
                    >
                        <Input placeholder="Customer full name" />
                    </Form.Item>

                    <Form.Item
                        label="Phone Number"
                        name="phoneNumber"
                        rules={[{ required: true, message: 'Please enter phone number' }]}
                    >
                        <Input placeholder="e.g., 91XXXXXXXXXX" />
                    </Form.Item>

                    <Form.Item
                        label="Notes"
                        name="notes"
                    >
                        <Input.TextArea rows={3} placeholder="Optional notes" />
                    </Form.Item>
                </Form>
            </Modal>
        </div>
    );
};
