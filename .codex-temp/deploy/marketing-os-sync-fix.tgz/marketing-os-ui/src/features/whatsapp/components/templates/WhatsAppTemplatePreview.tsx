import clsx from 'clsx';
import { Globe, Phone, Reply } from 'lucide-react';

import { formatWhatsAppBody, type TemplateButton } from './templateUtils';

interface WhatsAppTemplatePreviewProps {
  header?: string;
  body: string;
  footer?: string;
  buttons?: TemplateButton[];
  sampleValues?: Record<string, string>;
  compact?: boolean;
  className?: string;
}

const buttonIcons = {
  URL: Globe,
  PHONE_NUMBER: Phone,
  QUICK_REPLY: Reply,
} as const;

export function WhatsAppTemplatePreview({
  header,
  body,
  footer,
  buttons = [],
  sampleValues = {},
  compact = false,
  className,
}: WhatsAppTemplatePreviewProps) {
  const bodyParts = formatWhatsAppBody(body, sampleValues);

  return (
    <div
      className={clsx(
        'overflow-hidden rounded-[24px] border border-emerald-100 bg-[#E8F5E9] p-3 shadow-[0_16px_30px_rgba(22,101,52,0.08)]',
        compact ? 'rounded-[20px] p-2.5' : '',
        className
      )}
    >
      <div className="flex items-center justify-between rounded-[18px] bg-[#0f766e] px-3 py-2 text-[11px] font-semibold uppercase tracking-[0.18em] text-emerald-50">
        <span>WhatsApp Preview</span>
        <span className="rounded-full bg-white/16 px-2 py-1 text-[10px] tracking-[0.12em] text-white/90">
          Live
        </span>
      </div>

      <div className={clsx('mt-3 flex', compact ? 'justify-start' : 'justify-end')}>
        <div className={clsx('relative max-w-[92%]', compact ? 'max-w-full' : '')}>
          <div
            className={clsx(
              'rounded-[20px] rounded-tr-md bg-white px-4 py-3 text-slate-900 shadow-[0_12px_24px_rgba(15,23,42,0.08)]',
              compact ? 'rounded-[16px] px-3 py-2.5 text-sm' : ''
            )}
          >
            {header ? (
              <div className={clsx('mb-1.5 font-semibold text-slate-950', compact ? 'text-sm' : 'text-[15px]')}>
                {header}
              </div>
            ) : null}

            <div className={clsx('space-x-0.5 leading-relaxed text-slate-700', compact ? 'text-[13px]' : 'text-sm')}>
              {bodyParts.length > 0 ? (
                bodyParts.map((part) =>
                  part.isVariable ? (
                    <span
                      key={part.key}
                      className="rounded-md bg-cyan-50 px-1.5 py-0.5 font-semibold text-cyan-700"
                    >
                      {part.value || part.raw}
                    </span>
                  ) : (
                    <span key={part.key}>{part.text}</span>
                  )
                )
              ) : (
                <span className="text-slate-400">Your template preview will appear here.</span>
              )}
            </div>

            {footer ? (
              <div className="mt-2 text-[11px] text-slate-400">{footer}</div>
            ) : null}

            <div className="mt-2 flex items-center justify-end gap-1 text-[11px] text-slate-400">
              <span>12:32</span>
              <span className="text-cyan-600">✓✓</span>
            </div>
          </div>

          <span className="absolute -right-2 top-0 h-0 w-0 border-b-[10px] border-l-0 border-r-[10px] border-t-0 border-b-white border-r-transparent" />
        </div>
      </div>

      {buttons.length > 0 ? (
        <div className="mt-2 overflow-hidden rounded-[18px] border border-emerald-100 bg-white shadow-[0_10px_24px_rgba(15,23,42,0.06)]">
          {buttons.slice(0, compact ? 2 : 3).map((button, index) => {
            const Icon = buttonIcons[button.type];

            return (
              <div
                key={`${button.type}-${button.text}-${index}`}
                className="flex items-center justify-center gap-2 border-t border-slate-100 px-3 py-2.5 text-center text-sm font-semibold text-emerald-700 first:border-t-0"
              >
                <Icon size={14} />
                <span>{button.text || 'Action button'}</span>
              </div>
            );
          })}
        </div>
      ) : null}
    </div>
  );
}
