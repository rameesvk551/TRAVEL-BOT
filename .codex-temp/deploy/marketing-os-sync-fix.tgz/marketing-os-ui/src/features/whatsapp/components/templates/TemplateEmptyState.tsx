interface TemplateEmptyStateProps {
  onCreate: () => void;
}

export function TemplateEmptyState({ onCreate }: TemplateEmptyStateProps) {
  return (
    <section className="overflow-hidden rounded-[32px] border border-slate-200/80 bg-[linear-gradient(135deg,rgba(255,253,248,0.98)_0%,rgba(255,255,255,0.98)_48%,rgba(243,247,255,0.96)_100%)] shadow-[0_20px_48px_rgba(15,23,42,0.07)]">
      <div className="p-6 sm:p-8">
        <div className="max-w-5xl">
          <div className="inline-flex items-center rounded-full border border-slate-200 bg-white/80 px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.18em] text-slate-500">
            Start small
          </div>
          <h2 className="mt-5 text-3xl font-bold tracking-tight text-slate-950 sm:text-[2.4rem]">No templates yet</h2>
          <p className="mt-3 max-w-2xl text-[15px] leading-7 text-slate-600">
            Keep this library lean. Most teams begin with one utility template for updates, one campaign template for
            offers, and one OTP template only if login flows need it.
          </p>

          <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:items-center">
            <button
              type="button"
              onClick={onCreate}
              className="inline-flex min-h-[52px] items-center justify-center rounded-2xl bg-slate-950 px-6 text-sm font-semibold text-white shadow-[0_16px_30px_rgba(15,23,42,0.16)] transition hover:bg-slate-800"
            >
              Create your first template
            </button>
            <p className="text-sm leading-6 text-slate-500">
              Tip: utility templates usually make the cleanest first approval pass.
            </p>
          </div>

          <div className="mt-8 grid gap-3 sm:grid-cols-3">
            <div className="rounded-[22px] border border-white/80 bg-white/78 p-4 shadow-[0_10px_24px_rgba(15,23,42,0.04)]">
              <div className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-400">Utility</div>
              <div className="mt-2 text-base font-semibold text-slate-950">Order and service updates</div>
              <p className="mt-2 text-sm leading-6 text-slate-500">Delivery alerts, reminders, and operational nudges.</p>
            </div>

            <div className="rounded-[22px] border border-white/80 bg-white/78 p-4 shadow-[0_10px_24px_rgba(15,23,42,0.04)]">
              <div className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-400">Marketing</div>
              <div className="mt-2 text-base font-semibold text-slate-950">Launches and timed offers</div>
              <p className="mt-2 text-sm leading-6 text-slate-500">Promotions that feel timely without becoming spammy.</p>
            </div>

            <div className="rounded-[22px] border border-white/80 bg-white/78 p-4 shadow-[0_10px_24px_rgba(15,23,42,0.04)]">
              <div className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-400">Authentication</div>
              <div className="mt-2 text-base font-semibold text-slate-950">OTP and secure sign-in</div>
              <p className="mt-2 text-sm leading-6 text-slate-500">Only add these when your product flow genuinely needs them.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
