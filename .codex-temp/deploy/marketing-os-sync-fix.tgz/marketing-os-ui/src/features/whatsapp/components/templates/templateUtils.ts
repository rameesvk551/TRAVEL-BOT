import { formatDistanceToNow } from 'date-fns';

export type TemplateStatus =
  | 'APPROVED'
  | 'PENDING'
  | 'REJECTED'
  | 'DRAFT'
  | 'PAUSED'
  | 'DISABLED';

export type TemplateFilter = 'ALL' | TemplateStatus;
export type TemplateCategory = 'MARKETING' | 'UTILITY' | 'AUTHENTICATION' | 'SERVICE';
export type TemplateButtonType = 'URL' | 'PHONE_NUMBER' | 'QUICK_REPLY';
export type TemplatePresetKind = 'IMAGE' | 'TEXT' | 'FILE';
export type TemplatePresetCollection = 'TRENDING' | 'GENERAL' | 'TOP_RATED';
export type TemplatePresetIndustry = 'ECOMMERCE' | 'EDUCATION' | 'BANKING' | 'WEBINAR';
export type TemplatePresetIconKey =
  | 'offer'
  | 'cancel'
  | 'payment'
  | 'delivery'
  | 'upsell'
  | 'launch'
  | 'lesson'
  | 'bank'
  | 'event';

export interface TemplateButton {
  type: TemplateButtonType;
  text: string;
  value?: string;
}

export interface TemplateDraftValues {
  name: string;
  category: TemplateCategory;
  language: string;
  header: string;
  body: string;
  footer: string;
  buttons: TemplateButton[];
}

export interface TemplatePreset {
  id: string;
  title: string;
  summary: string;
  kind: TemplatePresetKind;
  collection: TemplatePresetCollection;
  industry: TemplatePresetIndustry;
  iconKey: TemplatePresetIconKey;
  draft: TemplateDraftValues;
}

export interface NormalizedTemplate {
  id: string;
  name: string;
  category: TemplateCategory;
  language: string;
  status: TemplateStatus;
  header: string;
  body: string;
  footer: string;
  buttons: TemplateButton[];
  preview: string;
  components: Array<Record<string, unknown>>;
  variableTokens: string[];
  rejectionReason: string | null;
  updatedAt: string | null;
  createdAt: string | null;
}

export const templateStatusFilters: Array<{ key: TemplateFilter; label: string }> = [
  { key: 'ALL', label: 'All' },
  { key: 'APPROVED', label: 'Approved' },
  { key: 'PENDING', label: 'Pending' },
  { key: 'REJECTED', label: 'Rejected' },
];

export const templateCategories: Array<{ value: TemplateCategory; label: string; description: string }> = [
  { value: 'MARKETING', label: 'Marketing', description: 'Promotions and offer campaigns' },
  { value: 'UTILITY', label: 'Utility', description: 'Operational updates and reminders' },
  { value: 'AUTHENTICATION', label: 'Authentication', description: 'OTP and verification templates' },
  { value: 'SERVICE', label: 'Service', description: 'Customer care and support flows' },
];

export const templateLanguages = [
  { value: 'en_US', label: 'English (US)' },
  { value: 'en_GB', label: 'English (UK)' },
  { value: 'hi', label: 'Hindi' },
];

export const exampleTemplateIdeas: TemplateDraftValues[] = [
  {
    name: 'welcome_offer_v1',
    category: 'MARKETING',
    language: 'en_US',
    header: 'Limited-time access',
    body: 'Hi {{1}}, your VIP WhatsApp offer is live. Use code {{2}} before tonight to unlock a 15% upgrade.',
    footer: 'Valid until 11:59 PM',
    buttons: [{ type: 'URL', text: 'Claim offer', value: 'https://marketingos.app/offers' }],
  },
  {
    name: 'order_update_ready',
    category: 'UTILITY',
    language: 'en_US',
    header: 'Order update',
    body: 'Hey {{1}}, your order {{2}} is packed and ready for dispatch. Track it anytime from your dashboard.',
    footer: 'Reply HELP for support',
    buttons: [{ type: 'QUICK_REPLY', text: 'Track order' }],
  },
  {
    name: 'otp_login_secure',
    category: 'AUTHENTICATION',
    language: 'en_US',
    header: 'Secure sign in',
    body: 'Your verification code is {{1}}. It expires in {{2}} minutes and should not be shared with anyone.',
    footer: 'Marketing OS Security',
    buttons: [],
  },
];

export const prebuiltTemplatePresets: TemplatePreset[] = [
  {
    id: 'limited_offer_blast',
    title: 'Offer Message',
    summary: 'Flash-sale WhatsApp copy for ecommerce campaigns with coupon and urgency.',
    kind: 'IMAGE',
    collection: 'TRENDING',
    industry: 'ECOMMERCE',
    iconKey: 'offer',
    draft: {
      name: 'limited_offer_blast',
      category: 'MARKETING',
      language: 'en_US',
      header: 'Limited offer',
      body:
        'Final hours to go, {{1}}. Use code {{2}} to unlock {{3}} off your cart before midnight.',
      footer: 'Ends tonight',
      buttons: [{ type: 'URL', text: 'Shop now', value: 'https://marketingos.app/offers' }],
    },
  },
  {
    id: 'order_cancelled_recovery',
    title: 'Order Cancelled',
    summary: 'A calm follow-up message after a failed or cancelled order with an easy next step.',
    kind: 'TEXT',
    collection: 'GENERAL',
    industry: 'ECOMMERCE',
    iconKey: 'cancel',
    draft: {
      name: 'order_cancelled_recovery',
      category: 'UTILITY',
      language: 'en_US',
      header: 'Order update',
      body:
        'Hi {{1}}, your order {{2}} was cancelled before payment confirmation. We saved your cart so you can place it again in one tap.',
      footer: 'Reply HELP for support',
      buttons: [{ type: 'QUICK_REPLY', text: 'Reorder now' }],
    },
  },
  {
    id: 'cod_to_prepaid_nudge',
    title: 'C.O.D to Prepaid',
    summary: 'Payment-conversion template that nudges COD shoppers toward prepaid checkout.',
    kind: 'IMAGE',
    collection: 'TOP_RATED',
    industry: 'ECOMMERCE',
    iconKey: 'payment',
    draft: {
      name: 'cod_to_prepaid_nudge',
      category: 'MARKETING',
      language: 'en_US',
      header: 'Complete payment',
      body:
        'Hey {{1}}, switch your order {{2}} to prepaid today and grab {{3}} off instantly. Your items are reserved for the next 2 hours.',
      footer: 'Secure checkout',
      buttons: [{ type: 'URL', text: 'Pay now', value: 'https://marketingos.app/pay' }],
    },
  },
  {
    id: 'delivery_tracking_update',
    title: 'Delivery Tracking',
    summary: 'Operational shipping update with tracking CTA and support fallback.',
    kind: 'TEXT',
    collection: 'GENERAL',
    industry: 'ECOMMERCE',
    iconKey: 'delivery',
    draft: {
      name: 'delivery_tracking_update',
      category: 'UTILITY',
      language: 'en_US',
      header: 'Your package is moving',
      body:
        'Good news, {{1}}. Your order {{2}} has shipped and is expected by {{3}}. Track the live delivery status below.',
      footer: 'Tracking updates refresh automatically',
      buttons: [{ type: 'URL', text: 'Track package', value: 'https://marketingos.app/track' }],
    },
  },
  {
    id: 'upsell_after_purchase',
    title: 'Order + Upsell',
    summary: 'Post-purchase recommendation template that extends order value with matching add-ons.',
    kind: 'IMAGE',
    collection: 'TRENDING',
    industry: 'ECOMMERCE',
    iconKey: 'upsell',
    draft: {
      name: 'upsell_after_purchase',
      category: 'MARKETING',
      language: 'en_US',
      header: 'Complete your order',
      body:
        'Thanks for shopping, {{1}}. Customers who bought {{2}} usually add {{3}} before dispatch. Add it now with a one-tap checkout.',
      footer: 'Exclusive add-on pricing',
      buttons: [{ type: 'URL', text: 'Add to order', value: 'https://marketingos.app/upsell' }],
    },
  },
  {
    id: 'new_product_launch_drop',
    title: 'New Product Launch',
    summary: 'Launch-day announcement built for drops, waitlists, and limited inventory releases.',
    kind: 'FILE',
    collection: 'TOP_RATED',
    industry: 'ECOMMERCE',
    iconKey: 'launch',
    draft: {
      name: 'new_product_launch_drop',
      category: 'MARKETING',
      language: 'en_US',
      header: 'Launch day is here',
      body:
        'Hi {{1}}, {{2}} is officially live. Tap below to order early and get priority shipping while launch stock lasts.',
      footer: 'Early-access batch',
      buttons: [{ type: 'URL', text: 'View product', value: 'https://marketingos.app/launch' }],
    },
  },
  {
    id: 'course_enrollment_welcome',
    title: 'Course Enrollment',
    summary: 'Education onboarding template for confirming a student seat and next steps.',
    kind: 'TEXT',
    collection: 'GENERAL',
    industry: 'EDUCATION',
    iconKey: 'lesson',
    draft: {
      name: 'course_enrollment_welcome',
      category: 'SERVICE',
      language: 'en_US',
      header: 'Enrollment confirmed',
      body:
        'Welcome, {{1}}. Your seat for {{2}} is confirmed. We have shared your start date, portal access, and support contact below.',
      footer: 'Reply START for onboarding help',
      buttons: [{ type: 'QUICK_REPLY', text: 'Open portal' }],
    },
  },
  {
    id: 'loan_emi_reminder',
    title: 'EMI Reminder',
    summary: 'Banking reminder template for due payments, autopay, and account reassurance.',
    kind: 'TEXT',
    collection: 'TOP_RATED',
    industry: 'BANKING',
    iconKey: 'bank',
    draft: {
      name: 'loan_emi_reminder',
      category: 'UTILITY',
      language: 'en_US',
      header: 'Upcoming EMI reminder',
      body:
        'Hi {{1}}, your EMI of {{2}} is due on {{3}}. Pay now or confirm autopay to avoid a late fee on your account.',
      footer: 'Secure bank notification',
      buttons: [{ type: 'URL', text: 'Pay EMI', value: 'https://marketingos.app/banking/pay' }],
    },
  },
  {
    id: 'webinar_event_reminder',
    title: 'Webinar Reminder',
    summary: 'Event reminder with time, speaker, and a direct join link for better attendance.',
    kind: 'TEXT',
    collection: 'TRENDING',
    industry: 'WEBINAR',
    iconKey: 'event',
    draft: {
      name: 'webinar_event_reminder',
      category: 'SERVICE',
      language: 'en_US',
      header: 'You are registered',
      body:
        'Hey {{1}}, your webinar {{2}} starts at {{3}}. Join a few minutes early to grab the worksheet and live Q&A seat.',
      footer: 'Reminder sent by Marketing OS',
      buttons: [{ type: 'URL', text: 'Join webinar', value: 'https://marketingos.app/webinar/join' }],
    },
  },
];

export const defaultTemplateDraft = (): TemplateDraftValues => ({
  name: '',
  category: 'UTILITY',
  language: 'en_US',
  header: '',
  body: '',
  footer: '',
  buttons: [],
});

export const templateToDraft = (template?: NormalizedTemplate | null): TemplateDraftValues => {
  if (!template) {
    return defaultTemplateDraft();
  }

  return {
    name: template.name,
    category: template.category,
    language: template.language,
    header: template.header,
    body: template.body,
    footer: template.footer,
    buttons: template.buttons,
  };
};

export const createTemplatePreviewModel = (
  values: TemplateDraftValues,
  overrides: Partial<
    Pick<NormalizedTemplate, 'id' | 'status' | 'rejectionReason' | 'updatedAt' | 'createdAt'>
  > = {}
): NormalizedTemplate => ({
  id: overrides.id || crypto.randomUUID(),
  name: values.name,
  category: values.category,
  language: values.language,
  status: overrides.status || 'DRAFT',
  header: values.header.trim(),
  body: values.body.trim(),
  footer: values.footer.trim(),
  buttons: values.buttons,
  preview: values.body.trim() || 'Add a message body to preview this template.',
  components: buildTemplateComponents(values),
  variableTokens: extractVariables(values.body),
  rejectionReason: overrides.rejectionReason || null,
  updatedAt: overrides.updatedAt || null,
  createdAt: overrides.createdAt || null,
});

export const extractVariables = (text: string): string[] => {
  const regex = /\{\{(\d+)\}\}/g;
  const matches = Array.from(text.matchAll(regex));
  const vars = new Set(matches.map((match) => match[1]));
  return Array.from(vars).sort((a, b) => Number(a) - Number(b));
};

export const formatWhatsAppBody = (text: string, sampleValues: Record<string, string>) => {
  if (!text) return [];

  return text.split(/(\{\{\d+\}\})/g).map((part, index) => {
    const match = part.match(/\{\{(\d+)\}\}/);
    if (match) {
      const token = match[1];
      return {
        key: `token-${index}`,
        isVariable: true as const,
        value: sampleValues[token] || '',
        raw: part,
      };
    }

    return {
      key: `text-${index}`,
      isVariable: false as const,
      text: part,
    };
  });
};

export const buildTemplateComponents = (values: TemplateDraftValues) => {
  const components: Array<Record<string, unknown>> = [];

  if (values.header.trim()) {
    components.push({
      type: 'HEADER',
      format: 'TEXT',
      text: values.header.trim(),
    });
  }

  components.push({
    type: 'BODY',
    text: values.body.trim(),
  });

  if (values.footer.trim()) {
    components.push({
      type: 'FOOTER',
      text: values.footer.trim(),
    });
  }

  if (values.buttons.length > 0) {
    components.push({
      type: 'BUTTONS',
      buttons: values.buttons.map((button) => ({
        type: button.type,
        text: button.text.trim(),
        ...(button.type === 'URL' && button.value ? { url: button.value.trim() } : {}),
        ...(button.type === 'PHONE_NUMBER' && button.value
          ? { phone_number: `+${button.value.replace(/\D/g, '')}` }
          : {}),
      })),
    });
  }

  return components;
};

export const normalizeTemplateName = (value: string) =>
  value
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9_\s]/g, '')
    .replace(/\s+/g, '_')
    .replace(/_+/g, '_');

export const formatTemplateDisplayName = (value: string) =>
  value
    .trim()
    .split(/[_\s]+/)
    .filter(Boolean)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(' ');

export const parseTemplateComponents = (rawComponents: unknown) => {
  if (Array.isArray(rawComponents)) {
    return rawComponents as Array<Record<string, unknown>>;
  }

  if (typeof rawComponents === 'string' && rawComponents.trim()) {
    try {
      const parsed = JSON.parse(rawComponents);
      return Array.isArray(parsed) ? (parsed as Array<Record<string, unknown>>) : [];
    } catch {
      return [];
    }
  }

  return [];
};

const normalizeStatus = (value: unknown): TemplateStatus => {
  const status = String(value || 'DRAFT').toUpperCase();

  if (status === 'APPROVED' || status === 'PENDING' || status === 'REJECTED' || status === 'PAUSED' || status === 'DISABLED') {
    return status;
  }

  return 'DRAFT';
};

const extractBodyFromComponents = (components: Array<Record<string, unknown>>) =>
  String(components.find((component) => component.type === 'BODY')?.text || '');

const extractHeaderFromComponents = (components: Array<Record<string, unknown>>) => {
  const header = components.find((component) => component.type === 'HEADER');

  if (!header || header.format !== 'TEXT') {
    return '';
  }

  return String(header.text || '');
};

const extractFooterFromComponents = (components: Array<Record<string, unknown>>) =>
  String(components.find((component) => component.type === 'FOOTER')?.text || '');

const extractButtonsFromComponents = (components: Array<Record<string, unknown>>): TemplateButton[] => {
  const buttonComponent = components.find((component) => component.type === 'BUTTONS');
  const buttons = Array.isArray(buttonComponent?.buttons)
    ? (buttonComponent?.buttons as Array<Record<string, unknown>>)
    : [];

  return buttons.map((button) => ({
    type: String(button.type || 'QUICK_REPLY') as TemplateButtonType,
    text: String(button.text || ''),
    value: String(button.url || button.phone_number || ''),
  }));
};

export const normalizeTemplate = (template: Record<string, unknown>): NormalizedTemplate => {
  const components = parseTemplateComponents(template.components);
  const body = String(template.body_content || template.bodyContent || extractBodyFromComponents(components) || '');
  const header = String(template.header_content || template.headerContent || extractHeaderFromComponents(components) || '');
  const footer = String(template.footer_content || template.footerContent || extractFooterFromComponents(components) || '');
  const buttons = extractButtonsFromComponents(components);

  return {
    id: String(template.id || crypto.randomUUID()),
    name: String(template.template_name || template.templateName || template.name || 'untitled_template'),
    category: String(template.category || 'UTILITY').toUpperCase() as TemplateCategory,
    language: String(template.language || 'en_US'),
    status: normalizeStatus(template.status),
    header,
    body,
    footer,
    buttons,
    preview: body || 'Add a message body to preview this template.',
    components,
    variableTokens: extractVariables(body),
    rejectionReason: template.rejection_reason ? String(template.rejection_reason) : null,
    updatedAt: template.updated_at ? String(template.updated_at) : template.updatedAt ? String(template.updatedAt) : null,
    createdAt: template.created_at ? String(template.created_at) : template.createdAt ? String(template.createdAt) : null,
  };
};

export const getStatusMeta = (status: TemplateStatus) => {
  switch (status) {
    case 'APPROVED':
      return {
        label: 'Approved',
        tone: 'text-emerald-700',
        badge: 'border-emerald-200 bg-emerald-50 text-emerald-700',
        glow: 'from-emerald-500/14 via-emerald-400/8 to-transparent',
      };
    case 'PENDING':
      return {
        label: 'Pending',
        tone: 'text-amber-700',
        badge: 'border-amber-200 bg-amber-50 text-amber-700',
        glow: 'from-amber-500/14 via-amber-400/8 to-transparent',
      };
    case 'REJECTED':
      return {
        label: 'Rejected',
        tone: 'text-rose-700',
        badge: 'border-rose-200 bg-rose-50 text-rose-700',
        glow: 'from-rose-500/14 via-rose-400/8 to-transparent',
      };
    case 'PAUSED':
      return {
        label: 'Paused',
        tone: 'text-slate-700',
        badge: 'border-slate-200 bg-slate-100 text-slate-700',
        glow: 'from-slate-500/14 via-slate-400/8 to-transparent',
      };
    case 'DISABLED':
      return {
        label: 'Disabled',
        tone: 'text-slate-700',
        badge: 'border-slate-200 bg-slate-100 text-slate-700',
        glow: 'from-slate-500/14 via-slate-400/8 to-transparent',
      };
    default:
      return {
        label: 'Draft',
        tone: 'text-indigo-700',
        badge: 'border-indigo-200 bg-indigo-50 text-indigo-700',
        glow: 'from-indigo-500/14 via-cyan-400/10 to-transparent',
      };
  }
};

export const formatTemplateTimestamp = (value: string | null) => {
  if (!value) {
    return 'Updated recently';
  }

  try {
    return `Updated ${formatDistanceToNow(new Date(value), { addSuffix: true })}`;
  } catch {
    return 'Updated recently';
  }
};

export const buildTemplateStats = (templates: NormalizedTemplate[]) => {
  const totals = templates.reduce(
    (accumulator, template) => {
      accumulator.total += 1;
      if (template.status === 'APPROVED') accumulator.approved += 1;
      if (template.status === 'PENDING') accumulator.pending += 1;
      if (template.status === 'REJECTED') accumulator.rejected += 1;
      return accumulator;
    },
    { total: 0, approved: 0, pending: 0, rejected: 0 }
  );

  return [
    {
      key: 'total',
      label: 'Total',
      value: totals.total,
      helper: 'All saved templates',
      accent: 'from-slate-900 via-indigo-700 to-cyan-500',
    },
    {
      key: 'approved',
      label: 'Approved',
      value: totals.approved,
      helper: 'Live and send-ready',
      accent: 'from-emerald-500 via-teal-500 to-cyan-500',
    },
    {
      key: 'pending',
      label: 'Pending',
      value: totals.pending,
      helper: 'Waiting for Meta review',
      accent: 'from-amber-400 via-orange-400 to-rose-400',
    },
    {
      key: 'rejected',
      label: 'Rejected',
      value: totals.rejected,
      helper: 'Needs edits before resend',
      accent: 'from-rose-500 via-fuchsia-500 to-indigo-500',
    },
  ];
};
