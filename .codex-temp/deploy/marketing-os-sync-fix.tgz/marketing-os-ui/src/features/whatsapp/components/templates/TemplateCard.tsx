import { Dropdown } from 'antd';
import type { MenuProps } from 'antd';
import { ArrowUpRight, Copy, MoreHorizontal, PenSquare, Send, Trash2 } from 'lucide-react';

import { WhatsAppTemplatePreview } from './WhatsAppTemplatePreview';
import { formatTemplateTimestamp, getStatusMeta, type NormalizedTemplate } from './templateUtils';

interface TemplateCardProps {
  template: NormalizedTemplate;
  onOpen: () => void;
  onEdit: () => void;
  onDuplicate: () => void;
  onSubmit: () => void;
  onDelete: () => void;
  isBusy?: boolean;
  busyAction?: string | null;
}

export function TemplateCard({
  template,
  onOpen,
  onEdit,
  onDuplicate,
  onSubmit,
  onDelete,
  isBusy = false,
  busyAction = null,
}: TemplateCardProps) {
  const statusMeta = getStatusMeta(template.status);

  const menuItems: MenuProps['items'] = [
    {
      key: 'open',
      label: 'Open details',
      icon: <ArrowUpRight size={14} />,
      onClick: onOpen,
    },
    {
      key: 'edit',
      label: 'Edit template',
      icon: <PenSquare size={14} />,
      onClick: onEdit,
    },
    {
      key: 'duplicate',
      label: 'Duplicate',
      icon: <Copy size={14} />,
      onClick: onDuplicate,
    },
    ...(template.status !== 'APPROVED'
      ? [
          {
            key: 'submit',
            label: 'Submit for review',
            icon: <Send size={14} />,
            onClick: onSubmit,
          },
        ]
      : []),
    {
      key: 'delete',
      danger: true,
      label: 'Delete',
      icon: <Trash2 size={14} />,
      onClick: onDelete,
    },
  ];

  const quickActionClassName =
    'inline-flex min-h-[40px] items-center justify-center rounded-2xl border border-slate-200 bg-white px-3 text-sm font-semibold text-slate-600 transition hover:border-slate-300 hover:bg-slate-50 hover:text-slate-900';

  return (
    <article
      onClick={onOpen}
      className="group relative flex h-full cursor-pointer flex-col overflow-hidden rounded-[28px] border border-slate-200/80 bg-[linear-gradient(180deg,rgba(255,255,255,0.99),rgba(248,250,252,0.95))] shadow-[0_16px_38px_rgba(15,23,42,0.06)] transition-transform duration-200 hover:-translate-y-0.5 hover:shadow-[0_24px_48px_rgba(15,23,42,0.1)]"
    >
      <div className={`absolute inset-x-5 top-0 h-[3px] rounded-b-full bg-gradient-to-r ${statusMeta.glow}`} />
      <div className={`absolute inset-x-6 top-0 h-20 bg-gradient-to-b ${statusMeta.glow} opacity-60 blur-2xl`} />

      <div className="relative flex items-start justify-between gap-4 p-5 pb-3">
        <div className="min-w-0">
          <span className={`inline-flex rounded-full border px-3 py-1 text-xs font-semibold ${statusMeta.badge}`}>
            {statusMeta.label}
          </span>
          <h3 className="mt-3 truncate text-lg font-bold text-slate-950">{template.name}</h3>
          <div className="mt-1 text-sm text-slate-500">
            {template.category} / {template.language}
          </div>
        </div>

        <Dropdown menu={{ items: menuItems }} trigger={['click']} placement="bottomRight">
          <button
            type="button"
            aria-label={`Open actions for ${template.name}`}
            onClick={(event) => event.stopPropagation()}
            className="inline-flex h-11 w-11 items-center justify-center rounded-2xl border border-slate-200 bg-white text-slate-500 shadow-[0_10px_22px_rgba(15,23,42,0.05)] transition hover:border-slate-300 hover:text-slate-900"
          >
            <MoreHorizontal size={18} />
          </button>
        </Dropdown>
      </div>

      <div className="relative px-5">
        <p
          className="min-h-[44px] text-sm leading-6 text-slate-600"
          style={{
            display: '-webkit-box',
            WebkitLineClamp: 2,
            WebkitBoxOrient: 'vertical',
            overflow: 'hidden',
          }}
        >
          {template.preview}
        </p>
      </div>

      <div className="relative px-5 pt-4">
        <WhatsAppTemplatePreview
          header={template.header}
          body={template.body}
          footer={template.footer}
          buttons={template.buttons}
          compact
        />
      </div>

      <div className="mt-auto flex items-center justify-between gap-3 border-t border-slate-100/90 px-5 py-4">
        <div className="min-w-0">
          <div className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-400">Last activity</div>
          <div className="mt-1 text-sm text-slate-600">{formatTemplateTimestamp(template.updatedAt || template.createdAt)}</div>
        </div>

        <div className="hidden items-center gap-2 opacity-0 transition-opacity duration-200 lg:flex lg:group-hover:opacity-100">
          <button
            type="button"
            className={quickActionClassName}
            onClick={(event) => {
              event.stopPropagation();
              onEdit();
            }}
          >
            Edit
          </button>
          <button
            type="button"
            className={quickActionClassName}
            onClick={(event) => {
              event.stopPropagation();
              onDuplicate();
            }}
          >
            Duplicate
          </button>
        </div>

        {isBusy ? (
          <div className="rounded-full border border-indigo-100 bg-indigo-50 px-3 py-1 text-xs font-semibold uppercase tracking-[0.14em] text-indigo-700">
            {busyAction || 'working'}
          </div>
        ) : null}
      </div>
    </article>
  );
}
