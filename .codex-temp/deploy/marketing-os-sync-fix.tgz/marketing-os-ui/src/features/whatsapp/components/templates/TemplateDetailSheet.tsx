import { Drawer } from 'antd';
import {
  AlertTriangle,
  CheckCircle2,
  Copy,
  FileText,
  Globe2,
  Languages,
  MessageSquareText,
  Pencil,
  Send,
  Sparkles,
  Trash2,
} from 'lucide-react';

import { useResponsive } from '../../../../hooks/useResponsive';
import { WhatsAppTemplatePreview } from './WhatsAppTemplatePreview';
import {
  formatTemplateDisplayName,
  formatTemplateTimestamp,
  getStatusMeta,
  type NormalizedTemplate,
} from './templateUtils';

interface TemplateDetailSheetProps {
  open: boolean;
  template: NormalizedTemplate | null;
  mode?: 'saved' | 'preset';
  onClose: () => void;
  onEdit: () => void;
  onDuplicate: () => void;
  onSubmit: () => void;
  onDelete: () => void;
  onUseTemplate?: () => void;
  useTemplateLabel?: string;
  isBusy?: boolean;
  busyAction?: string | null;
}

export function TemplateDetailSheet({
  open,
  template,
  mode = 'saved',
  onClose,
  onEdit,
  onDuplicate,
  onSubmit,
  onDelete,
  onUseTemplate,
  useTemplateLabel = 'Use template',
  isBusy = false,
  busyAction = null,
}: TemplateDetailSheetProps) {
  const { isMobile } = useResponsive();

  if (!template) {
    return null;
  }

  const statusMeta = getStatusMeta(template.status);
  const isPreset = mode === 'preset';
  const displayName = formatTemplateDisplayName(template.name);

  return (
    <Drawer
      open={open}
      onClose={onClose}
      placement={isMobile ? 'bottom' : 'right'}
      height={isMobile ? '92vh' : undefined}
      width={isMobile ? undefined : 540}
      title={
        <div className="pr-8">
          <div className="text-[11px] font-semibold uppercase tracking-[0.2em] text-slate-400">
            {isPreset ? 'Template preview' : 'Template details'}
          </div>
          <div className="mt-2 text-2xl font-bold leading-tight text-slate-950">{displayName}</div>
        </div>
      }
      styles={{ body: { padding: 0 } }}
    >
      <div className="h-full overflow-y-auto bg-[radial-gradient(circle_at_top_right,rgba(45,212,191,0.18),transparent_45%),linear-gradient(180deg,#f8fafc,#f1f5f9)]">
        <div className="space-y-6 p-5 sm:p-6">
          <section className="overflow-hidden rounded-[30px] border border-white/75 bg-white/95 p-5 shadow-[0_24px_54px_rgba(15,23,42,0.1)] backdrop-blur">
            <div className="pointer-events-none -mx-5 -mt-5 mb-4 h-16 bg-[linear-gradient(90deg,rgba(15,118,110,0.15),rgba(34,197,94,0.08),transparent)]" />
            <div className="flex items-start justify-between gap-4">
              <div>
                <span className={`inline-flex rounded-full border px-3 py-1 text-xs font-semibold ${statusMeta.badge}`}>
                  {statusMeta.label}
                </span>
                <div className="mt-3 text-sm text-slate-500">
                  {formatTemplateTimestamp(template.updatedAt || template.createdAt)}
                </div>
              </div>
              {isBusy ? (
                <span className="rounded-full border border-indigo-100 bg-indigo-50 px-3 py-1 text-xs font-semibold uppercase tracking-[0.14em] text-indigo-700">
                  {busyAction || 'working'}
                </span>
              ) : null}
            </div>

            {template.rejectionReason ? (
              <div className="mt-5 rounded-[22px] border border-rose-200 bg-[linear-gradient(180deg,#fff1f2,#ffe4e6)] p-4 text-sm text-rose-700">
                <div className="flex items-center gap-2 font-semibold">
                  <AlertTriangle size={16} />
                  Review feedback
                </div>
                <p className="mt-2 leading-6">{template.rejectionReason}</p>
              </div>
            ) : null}

            <WhatsAppTemplatePreview
              className="mt-5"
              header={template.header}
              body={template.body}
              footer={template.footer}
              buttons={template.buttons}
              sampleValues={{ '1': 'Aarav', '2': 'SPRING24' }}
            />
          </section>

          <section className="grid gap-3 sm:grid-cols-3">
            <article className="rounded-[24px] border border-white/75 bg-white/95 p-4 shadow-[0_18px_35px_rgba(15,23,42,0.07)] backdrop-blur">
              <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">
                <FileText size={16} />
                Category
              </div>
              <div className="mt-3 text-lg font-semibold text-slate-950">{template.category}</div>
            </article>

            <article className="rounded-[24px] border border-white/75 bg-white/95 p-4 shadow-[0_18px_35px_rgba(15,23,42,0.07)] backdrop-blur">
              <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">
                <Languages size={16} />
                Language
              </div>
              <div className="mt-3 text-lg font-semibold text-slate-950">{template.language}</div>
            </article>

            <article className="rounded-[24px] border border-white/75 bg-white/95 p-4 shadow-[0_18px_35px_rgba(15,23,42,0.07)] backdrop-blur">
              <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">
                <CheckCircle2 size={16} />
                Variables
              </div>
              <div className="mt-3 text-lg font-semibold text-slate-950">{template.variableTokens.length}</div>
            </article>
          </section>

          <section className="rounded-[28px] border border-white/75 bg-white/95 p-5 shadow-[0_20px_45px_rgba(15,23,42,0.08)] backdrop-blur">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.18em] text-slate-400">
              <MessageSquareText size={15} />
              Message body
            </div>
            <p className="mt-3 whitespace-pre-wrap text-sm leading-7 text-slate-600">{template.body}</p>

            {template.buttons.length > 0 ? (
              <div className="mt-5">
                <div className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-400">Buttons</div>
                <div className="mt-3 space-y-2">
                  {template.buttons.map((button, index) => (
                    <div
                      key={`${button.text}-${index}`}
                      className="flex items-center justify-between rounded-[20px] border border-slate-200 bg-[linear-gradient(180deg,#f8fafc,#f1f5f9)] px-4 py-3 text-sm"
                    >
                      <div>
                        <div className="font-semibold text-slate-900">{button.text}</div>
                        <div className="mt-1 text-slate-500">{button.type}</div>
                      </div>
                      {button.value ? (
                        <div className="flex items-center gap-2 text-slate-500">
                          <Globe2 size={14} />
                          <span className="max-w-[180px] truncate">{button.value}</span>
                        </div>
                      ) : null}
                    </div>
                  ))}
                </div>
              </div>
            ) : null}
          </section>
        </div>

        <div className="sticky bottom-0 border-t border-slate-200/80 bg-white/90 px-5 py-4 backdrop-blur sm:px-6">
          <div className="flex flex-wrap gap-3">
            <button
              type="button"
              onClick={onEdit}
              className="inline-flex min-h-[48px] items-center justify-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 text-sm font-semibold text-slate-700 transition hover:border-teal-200 hover:text-teal-700"
            >
              <Pencil size={16} />
              {isPreset ? 'Customize' : 'Edit'}
            </button>

            {isPreset ? (
              <button
                type="button"
                onClick={onUseTemplate}
                className="inline-flex min-h-[48px] items-center justify-center gap-2 rounded-2xl bg-[linear-gradient(135deg,#0f172a,#0f766e)] px-4 text-sm font-semibold text-white shadow-[0_16px_30px_rgba(15,23,42,0.2)] transition hover:brightness-110"
              >
                <Sparkles size={16} />
                {useTemplateLabel}
              </button>
            ) : null}

            {!isPreset ? (
              <button
                type="button"
                onClick={onSubmit}
                className="inline-flex min-h-[48px] items-center justify-center gap-2 rounded-2xl bg-[linear-gradient(135deg,#0f172a,#0f766e)] px-4 text-sm font-semibold text-white shadow-[0_16px_30px_rgba(15,23,42,0.2)] transition hover:brightness-110"
              >
                <Send size={16} />
                Submit
              </button>
            ) : null}

            {!isPreset ? (
              <button
                type="button"
                onClick={onDuplicate}
                className="inline-flex min-h-[48px] items-center justify-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 text-sm font-semibold text-slate-700 transition hover:border-teal-200 hover:text-teal-700"
              >
                <Copy size={16} />
                Duplicate
              </button>
            ) : null}

            {!isPreset ? (
              <button
                type="button"
                onClick={onDelete}
                className="inline-flex min-h-[48px] items-center justify-center gap-2 rounded-2xl border border-rose-200 bg-white px-4 text-sm font-semibold text-rose-600 transition hover:bg-rose-50"
              >
                <Trash2 size={16} />
                Delete
              </button>
            ) : null}
          </div>
        </div>
      </div>
    </Drawer>
  );
}
