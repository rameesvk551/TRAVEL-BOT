// WhatsAppChats.tsx — pure render shell.
// All logic lives in hooks/useChats.ts

import React, { useState } from 'react';
import { Input, Avatar, Badge, Tag, Tooltip, Spin, Modal } from 'antd';
import {
    ArrowLeftOutlined,
    SendOutlined,
    PhoneOutlined,
    WhatsAppOutlined,
    CheckOutlined,
    SearchOutlined,
    PaperClipOutlined,
    MoreOutlined,
    MessageOutlined,
    PlusOutlined,
    FileTextOutlined,
    ShopOutlined,
    CaretDownOutlined,
    AudioOutlined,
    ThunderboltOutlined,
} from '@ant-design/icons';
import { useChats, pickColor, initials, formatTime } from '../hooks/useChats';
import { useResponsive } from '../../../hooks/useResponsive';

interface ConversationSummary {
    id: string;
    displayName?: string;
    contactName?: string;
    phoneNumber?: string;
    provider?: string;
    providerHandle?: string;
    providerHandleId?: string;
    chatInbox?: string;
    assignee?: string;
    createdAt?: string | Date;
    unreadCount?: number;
    lastMessageAt?: string | Date;
    lastMessagePreview?: string;
    state?: string;
}

interface OrderItem {
    product_retailer_id?: string;
    quantity?: number;
    item_price?: string | number;
    currency?: string;
}

interface OrderContent {
    catalog_id?: string;
    text?: string;
    product_items?: OrderItem[];
}

interface InteractiveButtonOption {
    id?: string;
    title?: string;
    reply?: {
        title?: string;
    };
}

interface InteractiveAction {
    product_retailer_id?: string;
}

interface InteractiveBody {
    text?: string;
}

interface InteractiveContent {
    type?: string;
    header?: string;
    footer?: string;
    body?: string | InteractiveBody;
    action?: InteractiveAction;
    buttons?: InteractiveButtonOption[];
}

interface MessageContent extends InteractiveContent {
    order?: OrderContent;
}

interface ChatMessage {
    id: string;
    direction?: string;
    messageType?: string;
    type?: string;
    textContent?: {
        body?: string;
    };
    content?: MessageContent;
    textBody?: string;
    body?: string;
    templateContent?: {
        templateName?: string;
    };
    metadata?: {
        templateName?: string;
    };
    orderContent?: OrderContent;
    interactiveContent?: InteractiveContent;
    selectedButtonId?: string;
    selectedListItemId?: string;
    timestamp?: string | Date;
    createdAt?: string | Date;
    providerTimestamp?: string | Date;
    status?: string;
}

interface ApprovedTemplate {
    id: string;
    template_name?: string;
    templateName?: string;
    language?: string;
    body_content?: string;
    bodyContent?: string;
    category?: string;
}

const getConversationName = (conversation?: Partial<ConversationSummary> | null) =>
    conversation?.displayName || conversation?.contactName || conversation?.phoneNumber || 'Unknown';

const getInteractiveBodyText = (value?: string | InteractiveBody) =>
    typeof value === 'string' ? value : value?.text || '';

const formatPanelTime = (d?: string | Date) => {
    if (!d) return '-';
    const date = new Date(d);
    if (Number.isNaN(date.getTime())) return '-';
    return date.toLocaleString([], {
        month: 'short',
        day: 'numeric',
        hour: 'numeric',
        minute: '2-digit',
    });
};

const digitsOnly = (value?: string) => (value || '').replace(/\D/g, '');

const WhatsAppChats: React.FC = () => {
    const { isMobile, width } = useResponsive();
    const isCompactLayout = width < 1100;
    const {
        selectedConversationId, setSelectedConversationId,
        messageText, setMessageText,
        searchQuery, setSearchQuery,
        messagesEndRef,
        newChatModalOpen, setNewChatModalOpen,
        templatePickerOpen, setTemplatePickerOpen,
        isConnected,
        isLoadingConversations, isLoadingMessages, isSending, isNewChatLoading,
        isLoadingTemplates, isSendingTemplate,
        conversations, messages, activeConv, filteredConversations,
        templates,
        handleSend, handleStartNewChat, handleSendTemplate, handleSendCatalog, handleGeneratePaymentLink, isGeneratingPaymentLink,
    } = useChats();

    const [newChatPhone, setNewChatPhone] = useState('');
    const [newChatName, setNewChatName] = useState('');
    const [assignee, setAssignee] = useState('Unassigned');

    const onNewChatSubmit = () => {
        if (!newChatPhone.trim()) return;
        handleStartNewChat(newChatPhone.trim(), newChatName.trim() || undefined);
        setNewChatPhone('');
        setNewChatName('');
    };

    const allConversations = conversations as ConversationSummary[];
    const visibleConversations = filteredConversations as ConversationSummary[];
    const chatMessages = messages as ChatMessage[];
    const activeConversation = (activeConv as ConversationSummary | undefined) ?? null;
    const approvedTemplates = templates as ApprovedTemplate[];
    const activePhone = activeConversation?.phoneNumber || '-';
    const activeDigits = digitsOnly(activePhone);
    const leadId = activeDigits ? `DEMO-${activeDigits.slice(-6).padStart(6, '0')}` : '-';
    const providerHandle = activeConversation?.providerHandle || activeConversation?.phoneNumber || '-';
    const providerHandleId = activeConversation?.providerHandleId || (activeDigits ? `${activeDigits}1` : '-');
    const chatStartedAt = formatPanelTime(activeConversation?.createdAt || activeConversation?.lastMessageAt);

    const showConversationList = !isCompactLayout || !selectedConversationId;
    const showConversationPanel = !isCompactLayout || Boolean(selectedConversationId);

    return (
        <div style={{ ...S.root, ...(isCompactLayout ? S.rootCompact : {}), ...(isMobile ? S.rootMobile : {}) }}>
            {/* ─────────── LEFT PANEL ─────────── */}
            {showConversationList ? <div style={{ ...S.leftPanel, ...(isCompactLayout ? S.leftPanelMobile : {}) }}>
                <div style={S.leftHeaderWrapper}>
                    <div style={S.leftTopRow}>
                        <div style={S.leftTitle}>CHATS</div>
                        <div style={S.leftTopActions}>
                            <span style={S.leftSpaceLabel}>Spaces</span>
                            <button style={S.iconBtn} aria-label="More">
                                <MoreOutlined style={{ fontSize: 15, color: '#6b7280' }} />
                            </button>
                            <button onClick={() => setNewChatModalOpen(true)} style={S.iconBtn} aria-label="New chat">
                                <PlusOutlined style={{ fontSize: 15, color: '#6b7280' }} />
                            </button>
                        </div>
                    </div>
                    <div style={S.inboxRow}>
                        <button style={S.inboxBtn}>
                            <span style={{ fontSize: 12, fontWeight: 600, color: '#4b5563' }}>Inbox</span>
                            <CaretDownOutlined style={{ fontSize: 11, color: '#6b7280' }} />
                        </button>
                        <span style={{ ...S.connectionBadge, color: isConnected ? '#15803d' : '#4338CA', background: isConnected ? '#DCFCE7' : '#EEF2FF' }}>
                            <span style={{ ...S.connectionDot, background: isConnected ? '#22c55e' : '#6366F1' }} />
                            {isConnected ? 'Live' : 'Syncing'}
                        </span>
                    </div>
                </div>

                <div style={S.searchWrap}>
                    <Input
                        placeholder="Search"
                        prefix={<SearchOutlined style={{ color: '#8696a0' }} />}
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        style={S.searchInput}
                        allowClear
                    />
                </div>

                <div style={S.chatList}>
                    {isLoadingConversations ? (
                        <div style={S.centered}><Spin /></div>
                    ) : visibleConversations.length === 0 ? (
                        <div style={S.emptyList}>
                            <div style={S.emptyIconBadge}>
                                <MessageOutlined style={{ fontSize: 40, color: '#64748B' }} />
                            </div>
                            <div style={{ color: '#0F172A', fontSize: 20, fontWeight: 700, marginBottom: 8 }}>
                                {allConversations.length === 0 ? 'No conversations yet' : 'No results found'}
                            </div>
                            <div style={{ color: '#64748B', fontSize: 14, lineHeight: 1.6, maxWidth: 280 }}>
                                {allConversations.length === 0
                                    ? 'Start a WhatsApp conversation and it will appear here with live updates.'
                                    : 'Try another phone number or name, or clear the search to see your full inbox.'}
                            </div>
                            {allConversations.length === 0 ? (
                                <button onClick={() => setNewChatModalOpen(true)} style={{ ...S.newChatBtn, marginTop: 16 }}>
                                    <PlusOutlined /> Start a Conversation
                                </button>
                            ) : (
                                <button onClick={() => setSearchQuery('')} style={{ ...S.clearSearchBtn, marginTop: 16 }}>
                                    Clear search
                                </button>
                            )}
                        </div>
                    ) : (
                        visibleConversations.map((conv) => {
                            const name = getConversationName(conv);
                            const isActive = selectedConversationId === conv.id;
                            const color = pickColor(name);
                            return (
                                <div
                                    key={conv.id}
                                    onClick={() => setSelectedConversationId(conv.id)}
                                    style={{ ...S.chatItem, ...(isCompactLayout ? S.chatItemMobile : {}), background: isActive ? '#f3f4f6' : '#fff' }}
                                >
                                    <Badge count={conv.unreadCount} size="small" offset={[-4, 4]}>
                                        <Avatar size={49} style={{ backgroundColor: color, fontSize: 16, fontWeight: 600, flexShrink: 0 }}>
                                            {initials(name)}
                                        </Avatar>
                                    </Badge>
                                    <div style={S.chatMeta}>
                                        <div style={S.chatMetaTop}>
                                            <span style={S.chatName}>{name}</span>
                                            <span style={{ ...S.chatTime, color: conv.unreadCount ? '#00a884' : '#8696a0' }}>
                                                {formatTime(conv.lastMessageAt)}
                                            </span>
                                        </div>
                                        <div style={S.chatPreview}>{conv.lastMessagePreview || 'No messages yet'}</div>
                                    </div>
                                </div>
                            );
                        })
                    )}
                </div>
            </div> : null}

            {/* ─────────── RIGHT PANEL ─────────── */}
            {showConversationPanel ? <div style={{ ...S.rightPanel, ...(isCompactLayout ? S.rightPanelMobile : {}) }}>
                {selectedConversationId && activeConversation ? (
                    <>
                        <div style={{ ...S.chatHeader, ...(isCompactLayout ? S.chatHeaderMobile : {}) }}>
                            <div style={{ display: 'flex', alignItems: 'center', gap: 12, flex: 1, minWidth: 0 }}>
                                {isCompactLayout && (
                                    <button
                                        type="button"
                                        onClick={() => setSelectedConversationId(null)}
                                        style={S.mobileBackBtn}
                                        aria-label="Back to chats"
                                    >
                                        <ArrowLeftOutlined style={{ fontSize: 18, color: '#54656f' }} />
                                    </button>
                                )}
                                <Avatar size={40} style={{ backgroundColor: pickColor(getConversationName(activeConversation)), fontWeight: 600 }}>
                                    {initials(getConversationName(activeConversation))}
                                </Avatar>
                                <div style={{ minWidth: 0 }}>
                                    <div style={{ fontWeight: 700, fontSize: 25, color: '#1f2937', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', lineHeight: 1.1 }}>
                                        {getConversationName(activeConversation)}
                                    </div>
                                    <div style={{ fontSize: 14, color: '#6b7280', display: 'flex', alignItems: 'center', gap: 6, flexWrap: 'wrap' }}>
                                        <PhoneOutlined /> {activeConversation.phoneNumber}
                                    </div>
                                </div>
                            </div>
                            <div style={S.chatHeaderActions}>
                                {!isCompactLayout && (
                                    <select value={assignee} onChange={(e) => setAssignee(e.target.value)} style={S.assigneeSelect}>
                                        <option value="Unassigned">Select Assignee</option>
                                        <option value="Support Agent">Support Agent</option>
                                        <option value="Sales Agent">Sales Agent</option>
                                    </select>
                                )}
                                {!isCompactLayout && <button style={S.closeChatBtn}>Close Chat</button>}
                            </div>
                        </div>

                        <div style={{ ...S.messagesArea, ...(isCompactLayout ? S.messagesAreaMobile : {}) }}>
                            {isLoadingMessages ? (
                                <div style={S.centered}><Spin /></div>
                            ) : chatMessages.length === 0 ? (
                                <div style={S.centered}>
                                    <div style={{ textAlign: 'center', color: '#8696a0' }}>
                                        <WhatsAppOutlined style={{ fontSize: 48, marginBottom: 8 }} />
                                        <div>No messages yet. Send one below!</div>
                                    </div>
                                </div>
                            ) : (
                                <div style={{ display: 'flex', flexDirection: 'column', gap: 4, padding: '8px 0' }}>
                                    {chatMessages.map((msg) => {
                                        const isOut = msg.direction === 'OUTBOUND';
                                        const msgType = msg.messageType || msg.type || 'TEXT';
                                        const contentBody = getInteractiveBodyText(msg.content?.body);
                                        let body: React.ReactNode = '';

                                        if (msgType === 'TEXT' || msgType === 'text') {
                                            body = msg.textContent?.body || contentBody || msg.textBody || msg.body || '';
                                        } else if (msgType === 'INTERACTIVE' && !isOut && (msg.selectedButtonId || msg.selectedListItemId)) {
                                            // Handle inbound interactive replies (button/list clicks)
                                            body = (
                                                <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                                                    <CheckOutlined style={{ fontSize: 12, color: '#00a884' }} />
                                                    <span>{msg.textContent?.body || msg.textBody || 'Selection made'}</span>
                                                </div>
                                            );
                                        } else if (msgType === 'TEMPLATE' || msgType === 'template') {
                                            body = `Template: ${msg.templateContent?.templateName || msg.metadata?.templateName || 'Unknown'}`;
                                        } else if (msgType === 'ORDER') {
                                            const order = msg.orderContent || msg.content?.order;
                                            if (order) {
                                                body = (
                                                    <div style={{ background: isOut ? 'rgba(255,255,255,0.6)' : '#f0f2f5', padding: 8, borderRadius: 8, border: '1px solid rgba(0,0,0,0.05)', minWidth: 200 }}>
                                                        <div style={{ fontWeight: 600, marginBottom: 8, color: '#111b21' }}>Received Order</div>
                                                        <div style={{ fontSize: 13, marginBottom: 8, color: '#54656f' }}>Catalog: {order.catalog_id}</div>
                                                        {order.text && <div style={{ fontSize: 13, marginBottom: 8, fontStyle: 'italic', color: '#111b21' }}>"{order.text}"</div>}
                                                        {order.product_items?.map((item: OrderItem, idx: number) => (
                                                            <div key={idx} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, marginBottom: 4, background: 'rgba(255,255,255,0.5)', padding: 4, borderRadius: 4 }}>
                                                                <span style={{ color: '#111b21' }}>{item.product_retailer_id} ({item.quantity}x)</span>
                                                                <span style={{ fontWeight: 600, color: '#111b21' }}>{item.item_price} {item.currency}</span>
                                                            </div>
                                                        ))}
                                                        <button
                                                            disabled={isGeneratingPaymentLink}
                                                            onClick={() => handleGeneratePaymentLink(msg.id)}
                                                            style={{ ...S.newChatBtn, width: '100%', marginTop: 8, justifyContent: 'center', background: isGeneratingPaymentLink ? '#cccccc' : '#25D366' }}>
                                                            {isGeneratingPaymentLink ? 'Generating...' : 'Generate Payment Link'}
                                                        </button>
                                                    </div>
                                                );
                                            } else {
                                                body = 'Order details missing';
                                            }
                                        } else if (msgType === 'INTERACTIVE') {
                                            const interactive = msg.interactiveContent || msg.content;
                                            const interactiveBody = getInteractiveBodyText(interactive?.body);
                                            if (interactive?.type === 'CATALOG_MESSAGE') {
                                                body = (
                                                    <div style={{ background: isOut ? '#d9fdd3' : '#fff', padding: 8, borderRadius: 8, border: '1px solid rgba(0,0,0,0.05)', width: 200, display: 'flex', flexDirection: 'column' }}>
                                                        <div style={{ fontSize: 13, marginBottom: 8, color: '#111b21', whiteSpace: 'pre-wrap' }}>{interactiveBody || 'View our catalog on WhatsApp'}</div>
                                                        <div style={{ fontWeight: 600, color: '#00a884', textAlign: 'center', padding: '10px 0 2px', borderTop: '1px solid rgba(0,0,0,0.05)', marginTop: 'auto' }}>
                                                            View Catalog
                                                        </div>
                                                    </div>
                                                );
                                            } else if (interactive?.type === 'PRODUCT') {
                                                body = (
                                                    <div style={{ background: isOut ? '#d9fdd3' : '#fff', padding: 8, borderRadius: 8, border: '1px solid rgba(0,0,0,0.05)', width: 200, display: 'flex', flexDirection: 'column' }}>
                                                        <div style={{ fontSize: 13, marginBottom: 8, color: '#111b21', whiteSpace: 'pre-wrap' }}>{interactiveBody || 'Product preview'}</div>
                                                        <div style={{ fontSize: 12, color: '#8696a0', marginBottom: 8 }}>ID: {interactive.action?.product_retailer_id}</div>
                                                        <div style={{ fontWeight: 600, color: '#00a884', textAlign: 'center', padding: '10px 0 2px', borderTop: '1px solid rgba(0,0,0,0.05)', marginTop: 'auto' }}>
                                                            View Product
                                                        </div>
                                                    </div>
                                                );
                                            } else if (interactive?.type === 'BUTTON') {
                                                body = (
                                                    <div style={{ background: isOut ? '#d9fdd3' : '#fff', padding: 8, borderRadius: 8, border: '1px solid rgba(0,0,0,0.05)', minWidth: 200, display: 'flex', flexDirection: 'column' }}>
                                                        {interactive.header && <div style={{ fontWeight: 600, fontSize: 13, marginBottom: 4, color: '#111b21' }}>{interactive.header}</div>}
                                                        <div style={{ fontSize: 14, marginBottom: 8, color: '#111b21', whiteSpace: 'pre-wrap' }}>{interactiveBody}</div>
                                                        {interactive.footer && <div style={{ fontSize: 11, color: '#8696a0', marginBottom: 8 }}>{interactive.footer}</div>}
                                                        <div style={{ display: 'flex', flexDirection: 'column', gap: 1, borderTop: '1px solid rgba(0,0,0,0.05)', marginTop: 4 }}>
                                                            {interactive.buttons?.map((btn: InteractiveButtonOption) => (
                                                                <div key={btn.id || btn.title || btn.reply?.title || 'button'} style={{ padding: '8px 0', textAlign: 'center', color: '#00a884', fontWeight: 600, fontSize: 13, cursor: 'default' }}>
                                                                    {btn.title || btn.reply?.title}
                                                                </div>
                                                            ))}
                                                        </div>
                                                    </div>
                                                );
                                            } else if (interactive?.type === 'LIST') {
                                                body = (
                                                    <div style={{ background: isOut ? '#d9fdd3' : '#fff', padding: 8, borderRadius: 8, border: '1px solid rgba(0,0,0,0.05)', minWidth: 200, display: 'flex', flexDirection: 'column' }}>
                                                        {interactive.header && <div style={{ fontWeight: 600, fontSize: 13, marginBottom: 4, color: '#111b21' }}>{interactive.header}</div>}
                                                        <div style={{ fontSize: 14, marginBottom: 8, color: '#111b21', whiteSpace: 'pre-wrap' }}>{interactiveBody}</div>
                                                        {interactive.footer && <div style={{ fontSize: 11, color: '#8696a0', marginBottom: 8 }}>{interactive.footer}</div>}
                                                        <div style={{ fontWeight: 600, color: '#00a884', textAlign: 'center', padding: '10px 0 2px', borderTop: '1px solid rgba(0,0,0,0.05)', marginTop: 'auto' }}>
                                                            View List
                                                        </div>
                                                    </div>
                                                );
                                            } else if (interactive?.type === 'PRODUCT_LIST') {
                                                body = (
                                                    <div style={{ background: isOut ? '#d9fdd3' : '#fff', padding: 8, borderRadius: 8, border: '1px solid rgba(0,0,0,0.05)', minWidth: 200, display: 'flex', flexDirection: 'column' }}>
                                                        {interactive.header && <div style={{ fontWeight: 600, fontSize: 13, marginBottom: 4, color: '#111b21' }}>{interactive.header}</div>}
                                                        <div style={{ fontSize: 14, marginBottom: 8, color: '#111b21', whiteSpace: 'pre-wrap' }}>{interactiveBody}</div>
                                                        {interactive.footer && <div style={{ fontSize: 11, color: '#8696a0', marginBottom: 8 }}>{interactive.footer}</div>}
                                                        <div style={{ fontWeight: 600, color: '#00a884', textAlign: 'center', padding: '10px 0 2px', borderTop: '1px solid rgba(0,0,0,0.05)', marginTop: 'auto' }}>
                                                            View Items
                                                        </div>
                                                    </div>
                                                );
                                            } else {
                                                body = interactiveBody || 'Interactive message';
                                            }
                                        } else {
                                            body = `${msgType} attachment`;
                                        }
                                        return (
                                            <div key={msg.id} style={{ display: 'flex', justifyContent: isOut ? 'flex-end' : 'flex-start' }}>
                                                <div style={{
                                                    ...S.bubble,
                                                    ...(isCompactLayout ? S.bubbleMobile : {}),
                                                    backgroundColor: isOut ? '#d9fdd3' : '#fff',
                                                    borderTopLeftRadius: isOut ? 8 : 0,
                                                    borderTopRightRadius: isOut ? 0 : 8,
                                                }}>
                                                    <div style={{ fontSize: 14, color: '#111b21', lineHeight: 1.45, whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>
                                                        {body}
                                                    </div>
                                                    <div style={{ display: 'flex', justifyContent: 'flex-end', alignItems: 'center', gap: 4, marginTop: 2 }}>
                                                        <span style={{ fontSize: 11, color: '#8696a0' }}>
                                                            {formatTime(msg.timestamp || msg.createdAt || msg.providerTimestamp)}
                                                        </span>
                                                        {isOut && (
                                                            <span>
                                                                {msg.status === 'READ' || msg.status === 'read'
                                                                    ? <CheckOutlined style={{ fontSize: 12, color: '#53bdeb' }} />
                                                                    : <CheckOutlined style={{ fontSize: 12, color: '#8696a0' }} />}
                                                            </span>
                                                        )}
                                                    </div>
                                                </div>
                                            </div>
                                        );
                                    })}
                                    <div ref={messagesEndRef} />
                                </div>
                            )}
                        </div>

                        <div style={{ ...S.inputArea, ...(isCompactLayout ? S.inputAreaMobile : {}) }}>
                            {!isCompactLayout && <ThunderboltOutlined style={{ fontSize: 18, color: '#4b5563', cursor: 'pointer', flexShrink: 0 }} />}
                            {!isCompactLayout && <PaperClipOutlined style={{ fontSize: 18, color: '#4b5563', cursor: 'pointer', flexShrink: 0 }} />}
                            <Tooltip title="Send Template">
                                <FileTextOutlined
                                    onClick={() => setTemplatePickerOpen(true)}
                                    style={{ fontSize: isCompactLayout ? 18 : 18, color: '#4b5563', cursor: 'pointer', flexShrink: 0, transition: 'color 0.2s' }}
                                />
                            </Tooltip>
                            <Tooltip title="Send Catalog">
                                <ShopOutlined
                                    onClick={handleSendCatalog}
                                    style={{ fontSize: isCompactLayout ? 18 : 18, color: '#4b5563', cursor: 'pointer', flexShrink: 0, transition: 'color 0.2s' }}
                                />
                            </Tooltip>
                            <input
                                value={messageText}
                                onChange={(e) => setMessageText(e.target.value)}
                                onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); } }}
                                placeholder="Type a message"
                                style={{ ...S.textInput, ...(isCompactLayout ? S.textInputMobile : {}) }}
                            />
                            <button
                                onClick={handleSend}
                                disabled={!messageText.trim() || isSending}
                                style={{ ...S.sendBtn, ...(isCompactLayout ? S.sendBtnMobile : {}), opacity: messageText.trim() ? 1 : 0.5 }}
                            >
                                {isCompactLayout ? <SendOutlined style={{ fontSize: 18, color: '#6b7280' }} /> : <AudioOutlined style={{ fontSize: 18, color: '#6b7280' }} />}
                            </button>
                        </div>
                    </>
                ) : !isCompactLayout ? (
                    <div style={S.emptyState}>
                        <div style={S.emptyStateInner}>
                            <div style={S.emptyIcon}>
                                <WhatsAppOutlined style={{ fontSize: 64, color: '#00a884' }} />
                            </div>
                            <h2 style={{ fontSize: 28, fontWeight: 300, color: '#41525d', margin: '24px 0 12px' }}>
                                WhatsApp Conversations
                            </h2>
                            <p style={{ fontSize: 14, color: '#8696a0', maxWidth: 460, textAlign: 'center', lineHeight: 1.6 }}>
                                Send and receive messages from your customers. Select a conversation
                                from the list to start chatting, or click <b>+ New Chat</b> to start a new conversation.
                            </p>
                            <div style={{ width: 400, height: 1, background: 'linear-gradient(90deg, transparent, #e0e0e0, transparent)', margin: '24px 0' }} />
                            <div style={{ display: 'flex', alignItems: 'center', gap: 8, color: '#8696a0', fontSize: 13 }}>
                                <span style={{ width: 8, height: 8, borderRadius: '50%', background: '#00a884' }} />
                                End-to-end encrypted
                            </div>
                        </div>
                    </div>
                ) : null}
            </div> : null}

            {!isCompactLayout && selectedConversationId && activeConversation ? (
                <aside style={S.detailsRail}>
                    <section style={S.detailSection}>
                        <h4 style={S.detailHeading}>CHAT DETAILS</h4>
                        <div style={S.detailRow}><span style={S.detailLabel}>Start Time:</span><span style={S.detailValue}>{chatStartedAt}</span></div>
                        <div style={S.detailRow}><span style={S.detailLabel}>Chat Inbox:</span><span style={S.detailValue}>{activeConversation.chatInbox || 'No chat inbox'}</span></div>
                        <div style={S.detailRow}><span style={S.detailLabel}>Provider:</span><span style={S.detailValue}>{activeConversation.provider || 'WhatsApp'}</span></div>
                        <div style={S.detailRow}><span style={S.detailLabel}>Provider Handle:</span><span style={S.detailValue}>{providerHandle}</span></div>
                        <div style={S.detailRow}><span style={S.detailLabel}>Prov. Handle ID:</span><span style={S.detailValue}>{providerHandleId}</span></div>
                        <div style={S.detailRow}><span style={S.detailLabel}>Plugin:</span><span style={{ ...S.detailValue, color: '#1d4ed8' }}>configure</span></div>
                    </section>

                    <section style={S.detailSection}>
                        <h4 style={S.detailHeading}>CHATBOT DETAILS</h4>
                        <div style={S.emptyText}>No chatbot is assigned</div>
                    </section>

                    <section style={S.detailSection}>
                        <h4 style={S.detailHeading}>RELATED ITEMS</h4>
                        <div style={{ fontWeight: 600, color: '#374151', marginBottom: 10 }}>Lead</div>
                        <div style={S.detailRow}><span style={S.detailLabel}>Customer Name</span><span style={S.detailValue}>{getConversationName(activeConversation)}</span></div>
                        <div style={S.detailRow}><span style={S.detailLabel}>Lead Id</span><span style={S.detailValue}>{leadId}</span></div>
                        <div style={S.detailRow}><span style={S.detailLabel}>Phone Number</span><span style={S.detailValue}>{activePhone}</span></div>
                    </section>

                    <section style={S.detailSection}>
                        <h4 style={S.detailHeading}>REMINDERS</h4>
                    </section>
                </aside>
            ) : null}

            {/* ─────────── NEW CHAT MODAL ─────────── */}
            <Modal
                title={<span style={{ display: 'flex', alignItems: 'center', gap: 8 }}><WhatsAppOutlined style={{ color: '#00a884' }} /> New Conversation</span>}
                open={newChatModalOpen}
                onCancel={() => { setNewChatModalOpen(false); setNewChatPhone(''); setNewChatName(''); }}
                onOk={onNewChatSubmit}
                okText={isNewChatLoading ? 'Creating...' : 'Start Chat'}
                okButtonProps={{ disabled: !newChatPhone.trim() || isNewChatLoading, style: { background: '#00a884', borderColor: '#00a884' } }}
                destroyOnClose
                width={isCompactLayout ? 'calc(100vw - 24px)' : 460}
                style={{ top: isMobile ? 18 : 72 }}
            >
                <div style={{ display: 'flex', flexDirection: 'column', gap: 16, padding: '12px 0' }}>
                    <div>
                        <label style={{ fontWeight: 600, fontSize: 13, color: '#111b21', display: 'block', marginBottom: 6 }}>
                            Phone Number <span style={{ color: '#f5222d' }}>*</span>
                        </label>
                        <Input
                            placeholder="e.g. +91 98765 43210"
                            prefix={<PhoneOutlined style={{ color: '#8696a0' }} />}
                            value={newChatPhone}
                            onChange={(e) => setNewChatPhone(e.target.value)}
                            onPressEnter={onNewChatSubmit}
                            size="large"
                            style={{ borderRadius: 8 }}
                        />
                        <div style={{ fontSize: 12, color: '#8696a0', marginTop: 4 }}>
                            Include country code (e.g. +91 for India)
                        </div>
                    </div>
                    <div>
                        <label style={{ fontWeight: 600, fontSize: 13, color: '#111b21', display: 'block', marginBottom: 6 }}>
                            Contact Name <span style={{ color: '#8696a0', fontWeight: 400 }}>(optional)</span>
                        </label>
                        <Input
                            placeholder="e.g. John Doe"
                            value={newChatName}
                            onChange={(e) => setNewChatName(e.target.value)}
                            onPressEnter={onNewChatSubmit}
                            size="large"
                            style={{ borderRadius: 8 }}
                        />
                    </div>
                </div>
            </Modal>

            {/* ─────────── TEMPLATE PICKER MODAL ─────────── */}
            <Modal
                title={<span style={{ display: 'flex', alignItems: 'center', gap: 8 }}><FileTextOutlined style={{ color: '#00a884' }} /> Send Template Message</span>}
                open={templatePickerOpen}
                onCancel={() => setTemplatePickerOpen(false)}
                footer={null}
                destroyOnClose
                width={isCompactLayout ? 'calc(100vw - 24px)' : 520}
                style={{ top: isMobile ? 18 : 72 }}
            >
                <div style={{ padding: '8px 0' }}>
                    <p style={{ color: '#8696a0', fontSize: 13, marginBottom: 16 }}>
                        Select an approved template to send. Templates allow you to start conversations without opt-in.
                    </p>
                    {isLoadingTemplates ? (
                        <div style={{ textAlign: 'center', padding: 32 }}><Spin /></div>
                    ) : approvedTemplates.length === 0 ? (
                        <div style={{ textAlign: 'center', padding: 32, color: '#8696a0' }}>
                            <FileTextOutlined style={{ fontSize: 40, marginBottom: 8 }} />
                            <div>No approved templates found</div>
                            <div style={{ fontSize: 12, marginTop: 4 }}>Create and approve templates in the Templates tab</div>
                        </div>
                    ) : (
                        <div style={{ display: 'flex', flexDirection: 'column', gap: 8, maxHeight: 400, overflowY: 'auto' }}>
                            {approvedTemplates.map((tpl) => (
                                <div
                                    key={tpl.id}
                                    onClick={() => !isSendingTemplate && handleSendTemplate(tpl.template_name || tpl.templateName || '', tpl.language)}
                                    style={{
                                        padding: '12px 16px', borderRadius: 8, border: '1px solid #e9edef',
                                        cursor: isSendingTemplate ? 'wait' : 'pointer', transition: 'all 0.2s',
                                        background: '#fff',
                                    }}
                                    onMouseEnter={(e) => { (e.currentTarget as HTMLDivElement).style.background = '#f0f9f4'; (e.currentTarget as HTMLDivElement).style.borderColor = '#00a884'; }}
                                    onMouseLeave={(e) => { (e.currentTarget as HTMLDivElement).style.background = '#fff'; (e.currentTarget as HTMLDivElement).style.borderColor = '#e9edef'; }}
                                >
                                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
                                        <span style={{ fontWeight: 600, color: '#111b21', fontSize: 14 }}>
                                            {tpl.template_name || tpl.templateName}
                                        </span>
                                        <Tag color="green" style={{ fontSize: 10, lineHeight: '16px', padding: '0 6px' }}>
                                            {tpl.language || 'en'}
                                        </Tag>
                                    </div>
                                    <div style={{ fontSize: 13, color: '#667781', lineHeight: 1.4 }}>
                                        {tpl.body_content || tpl.bodyContent || 'No preview available'}
                                    </div>
                                    {tpl.category && (
                                        <Tag style={{ marginTop: 6, fontSize: 10 }}>{tpl.category}</Tag>
                                    )}
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </Modal>
        </div>
    );
};

/* ── STYLES ── */
const S: Record<string, React.CSSProperties> = {
    root: { display: 'flex', height: 'calc(100svh - 64px)', minHeight: 560, background: '#f3f4f6', overflow: 'hidden' },
    rootCompact: { minHeight: 'calc(100svh - 64px)', height: 'calc(100svh - 64px)' },
    rootMobile: { height: 'calc(100svh - 64px)', minHeight: 'calc(100svh - 64px)' },
    leftPanel: { width: 280, minWidth: 260, borderRight: '1px solid #e5e7eb', display: 'flex', flexDirection: 'column', background: '#fff' },
    leftPanelMobile: { width: '100%', minWidth: 0, borderRight: 'none' },
    leftHeaderWrapper: { padding: '10px 12px', background: '#fff', borderBottom: '1px solid #e5e7eb' },
    leftTopRow: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
    leftTitle: { fontSize: 13, letterSpacing: 0.3, fontWeight: 700, color: '#111827' },
    leftTopActions: { display: 'flex', alignItems: 'center', gap: 4 },
    leftSpaceLabel: { fontSize: 13, color: '#6b7280', marginRight: 2 },
    iconBtn: { width: 24, height: 24, borderRadius: 12, border: 'none', background: 'transparent', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' },
    inboxRow: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10 },
    inboxBtn: { display: 'inline-flex', alignItems: 'center', gap: 6, background: 'transparent', border: 'none', cursor: 'pointer', padding: 0, fontSize: 12, outline: 'none' },
    connectionBadge: { display: 'inline-flex', alignItems: 'center', gap: 6, padding: '2px 8px', borderRadius: 999, fontSize: 11, fontWeight: 700 },
    connectionDot: { width: 8, height: 8, borderRadius: 999, flexShrink: 0 },
    searchWrap: { padding: '8px 10px', background: '#fff' },
    searchInput: { borderRadius: 6, border: '1px solid #e5e7eb', background: '#fff', height: 34 },
    chatList: { flex: 1, overflowY: 'auto' as const, padding: '2px 0 0' },
    chatItem: { display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px', cursor: 'pointer', borderBottom: '1px solid #f3f4f6', transition: 'background 0.12s', marginBottom: 0 },
    chatItemMobile: { padding: '12px' },
    chatMeta: { flex: 1, minWidth: 0 },
    chatMetaTop: { display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 1 },
    chatName: { fontSize: 15, fontWeight: 600, color: '#1f2937', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' as const },
    chatTime: { fontSize: 11, flexShrink: 0, marginLeft: 8 },
    chatPreview: { fontSize: 13, color: '#6b7280', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' as const },
    emptyList: { display: 'flex', flexDirection: 'column' as const, alignItems: 'center', justifyContent: 'center', height: '100%', padding: 24, textAlign: 'center' },
    emptyIconBadge: { width: 76, height: 76, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'linear-gradient(135deg, #E2E8F0 0%, #F8FAFC 100%)', marginBottom: 16 },
    clearSearchBtn: { padding: '11px 16px', borderRadius: 14, border: '1px solid #CBD5E1', background: '#fff', color: '#0F172A', fontWeight: 600, fontSize: 14, cursor: 'pointer' },
    rightPanel: {
        flex: 1, display: 'flex', flexDirection: 'column' as const, background: '#ececec', position: 'relative' as const,
    },
    rightPanelMobile: { width: '100%' },
    chatHeader: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px 14px', minHeight: 68, background: '#f7f7f7', borderBottom: '1px solid #ddd' },
    chatHeaderMobile: { padding: '12px 14px', minHeight: 64, height: 'auto' },
    chatHeaderActions: { display: 'flex', alignItems: 'center', gap: 8, marginLeft: 12 },
    assigneeSelect: { height: 32, minWidth: 180, borderRadius: 4, border: '1px solid #d1d5db', background: '#fff', color: '#374151', padding: '0 10px', outline: 'none' },
    closeChatBtn: { height: 32, border: '1px solid #d1d5db', background: '#fff', borderRadius: 4, color: '#374151', padding: '0 10px', cursor: 'pointer', fontWeight: 500 },
    messagesArea: { flex: 1, overflowY: 'auto' as const, padding: '18px 48px', background: '#ececec' },
    messagesAreaMobile: { padding: '14px 14px 10px' },
    bubble: { maxWidth: '66%', padding: '9px 11px 6px 11px', borderRadius: 8, boxShadow: 'none' },
    bubbleMobile: { maxWidth: '86%' },
    inputArea: { display: 'flex', alignItems: 'center', gap: 12, padding: '12px 14px', background: '#f3f4f6', borderTop: '1px solid #ddd' },
    inputAreaMobile: { gap: 8, padding: '10px 12px calc(10px + env(safe-area-inset-bottom))' },
    textInput: { flex: 1, border: '1px solid #d1d5db', borderRadius: 6, padding: '9px 12px', fontSize: 16, outline: 'none', background: '#fff', color: '#111827' },
    textInputMobile: { minWidth: 0, padding: '11px 14px' },
    sendBtn: { width: 24, height: 24, borderRadius: 12, border: 'none', background: 'transparent', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', flexShrink: 0, transition: 'opacity 0.2s' },
    sendBtnMobile: { width: 40, height: 40 },
    newChatBtn: { padding: '5px 14px', borderRadius: 6, border: 'none', background: '#00a884', color: '#fff', fontWeight: 600, fontSize: 13, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6 },
    newChatBtnMobile: { padding: '7px 14px' },
    mobileBackBtn: { width: 36, height: 36, borderRadius: 18, border: 'none', background: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', boxShadow: '0 1px 2px rgba(15,23,42,0.08)', flexShrink: 0 },
    emptyState: { flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#f0f2f5' },
    emptyStateInner: { display: 'flex', flexDirection: 'column' as const, alignItems: 'center' },
    emptyIcon: { width: 120, height: 120, borderRadius: '50%', background: 'linear-gradient(135deg, #e8f8e8 0%, #d5f5e3 100%)', display: 'flex', alignItems: 'center', justifyContent: 'center' },
    centered: { display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%' },
    detailsRail: { width: 300, minWidth: 280, borderLeft: '1px solid #d1d5db', background: '#f9fafb', overflowY: 'auto', paddingBottom: 20 },
    detailSection: { borderBottom: '1px solid #e5e7eb', padding: '14px 14px 12px' },
    detailHeading: { margin: 0, fontSize: 12, fontWeight: 700, color: '#111827', letterSpacing: 0.2, marginBottom: 12 },
    detailRow: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, alignItems: 'start', marginBottom: 8 },
    detailLabel: { color: '#6b7280', fontSize: 13, lineHeight: 1.3 },
    detailValue: { color: '#111827', fontSize: 13, fontWeight: 500, lineHeight: 1.3, textAlign: 'right' },
    emptyText: { color: '#6b7280', fontSize: 13 },
};

export default WhatsAppChats;
