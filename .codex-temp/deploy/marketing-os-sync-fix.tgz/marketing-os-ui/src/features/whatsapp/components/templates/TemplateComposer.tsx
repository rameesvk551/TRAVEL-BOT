import { Drawer, message } from 'antd';
import { Plus, Sparkles, Trash2 } from 'lucide-react';
import { useState } from 'react';

import { useResponsive } from '../../../../hooks/useResponsive';
import { WhatsAppTemplatePreview } from './WhatsAppTemplatePreview';
import {
  extractVariables,
  normalizeTemplateName,
  templateCategories,
  templateLanguages,
  templateToDraft,
  type NormalizedTemplate,
  type TemplateButton,
  type TemplateButtonType,
  type TemplateDraftValues,
} from './templateUtils';

interface TemplateComposerProps {
  open: boolean;
  mode: 'create' | 'edit';
  template: NormalizedTemplate | null;
  draftValues?: TemplateDraftValues | null;
  isSaving: boolean;
  onClose: () => void;
  onSave: (values: TemplateDraftValues) => Promise<void>;
}

const emptyButton = (): TemplateButton => ({
  type: 'QUICK_REPLY',
  text: '',
  value: '',
});

export function TemplateComposer({
  open,
  mode,
  template,
  draftValues = null,
  isSaving,
  onClose,
  onSave,
}: TemplateComposerProps) {
  const { isMobile } = useResponsive();
  const initialValues = draftValues || templateToDraft(template);
  const [values, setValues] = useState<TemplateDraftValues>(initialValues);
  const [sampleValues, setSampleValues] = useState<Record<string, string>>({});

  const variableTokens = extractVariables(values.body);
  const isEditing = mode === 'edit';

  const updateValue = <K extends keyof TemplateDraftValues>(key: K, nextValue: TemplateDraftValues[K]) => {
    setValues((current) => ({ ...current, [key]: nextValue }));
  };

  const updateButton = (index: number, key: keyof TemplateButton, nextValue: string) => {
    setValues((current) => ({
      ...current,
      buttons: current.buttons.map((button, buttonIndex) =>
        buttonIndex === index ? { ...button, [key]: nextValue } : button
      ),
    }));
  };

  const validate = () => {
    if (!values.name.trim()) {
      message.error('Template name is required');
      return false;
    }

    if (!/^[a-z0-9_]+$/.test(values.name.trim())) {
      message.error('Template name can use lowercase letters, numbers, and underscores only');
      return false;
    }

    if (!values.body.trim()) {
      message.error('Message content is required');
      return false;
    }

    for (const button of values.buttons) {
      if (!button.text.trim()) {
        message.error('Each button needs a label');
        return false;
      }

      if (button.type !== 'QUICK_REPLY' && !button.value?.trim()) {
        message.error('Buttons with links or phone numbers need a value');
        return false;
      }
    }

    return true;
  };

  const handleSave = async () => {
    if (!validate()) {
      return;
    }

    try {
      await onSave({
        ...values,
        name: normalizeTemplateName(values.name),
      });
    } catch {
      // Toasts are handled in the data hook.
    }
  };

  return (
    <Drawer
      open={open}
      onClose={onClose}
      placement={isMobile ? 'bottom' : 'right'}
      height={isMobile ? '94vh' : undefined}
      width={isMobile ? undefined : 980}
      title={
        <div>
          <div className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-400">
            {isEditing ? 'Edit template' : 'Create template'}
          </div>
          <div className="mt-1 text-xl font-bold text-slate-950">
            {isEditing ? values.name || 'Update template' : 'Design a new WhatsApp template'}
          </div>
        </div>
      }
      styles={{ body: { padding: 0 } }}
      footer={
        <div className="flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={onClose}
            className="inline-flex min-h-[48px] items-center justify-center rounded-2xl border border-slate-200 px-4 text-sm font-semibold text-slate-700 transition hover:border-slate-300"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleSave}
            disabled={isSaving}
            className="inline-flex min-h-[48px] items-center justify-center rounded-2xl bg-slate-950 px-5 text-sm font-semibold text-white shadow-[0_18px_30px_rgba(15,23,42,0.18)] transition hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-60"
          >
            {isSaving ? 'Saving...' : isEditing ? 'Save changes' : 'Create template'}
          </button>
        </div>
      }
    >
      <div className="grid gap-0 bg-[#F8FAFC] lg:grid-cols-[minmax(0,1fr)_360px]">
        <div className="space-y-5 p-5 sm:p-6">
          <section className="rounded-[28px] border border-white/70 bg-white p-5 shadow-[0_20px_45px_rgba(15,23,42,0.08)]">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-400">Template setup</div>
                <div className="mt-2 text-lg font-semibold text-slate-950">Core details</div>
              </div>
              {isEditing ? (
                <span className="rounded-full border border-slate-200 bg-slate-50 px-3 py-1 text-xs font-semibold text-slate-500">
                  Name, category, and language stay locked
                </span>
              ) : null}
            </div>

            <div className="mt-5 grid gap-4 md:grid-cols-2">
              <label className="block">
                <span className="text-sm font-semibold text-slate-700">Template name</span>
                <input
                  value={values.name}
                  disabled={isEditing}
                  onChange={(event) => updateValue('name', normalizeTemplateName(event.target.value))}
                  placeholder="welcome_offer_v1"
                  className="mt-2 min-h-[52px] w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 text-sm text-slate-900 outline-none transition focus:border-indigo-300 focus:bg-white disabled:cursor-not-allowed disabled:opacity-60"
                />
              </label>

              <label className="block">
                <span className="text-sm font-semibold text-slate-700">Category</span>
                <select
                  value={values.category}
                  disabled={isEditing}
                  onChange={(event) => updateValue('category', event.target.value as TemplateDraftValues['category'])}
                  className="mt-2 min-h-[52px] w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 text-sm text-slate-900 outline-none transition focus:border-indigo-300 focus:bg-white disabled:cursor-not-allowed disabled:opacity-60"
                >
                  {templateCategories.map((category) => (
                    <option key={category.value} value={category.value}>
                      {category.label}
                    </option>
                  ))}
                </select>
              </label>

              <label className="block md:col-span-2">
                <span className="text-sm font-semibold text-slate-700">Language</span>
                <select
                  value={values.language}
                  disabled={isEditing}
                  onChange={(event) => updateValue('language', event.target.value)}
                  className="mt-2 min-h-[52px] w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 text-sm text-slate-900 outline-none transition focus:border-indigo-300 focus:bg-white disabled:cursor-not-allowed disabled:opacity-60"
                >
                  {templateLanguages.map((language) => (
                    <option key={language.value} value={language.value}>
                      {language.label}
                    </option>
                  ))}
                </select>
              </label>
            </div>
          </section>

          <section className="rounded-[28px] border border-white/70 bg-white p-5 shadow-[0_20px_45px_rgba(15,23,42,0.08)]">
            <div className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-400">Message</div>
            <div className="mt-2 text-lg font-semibold text-slate-950">WhatsApp content</div>

            <div className="mt-5 space-y-4">
              <label className="block">
                <span className="text-sm font-semibold text-slate-700">Header</span>
                <input
                  value={values.header}
                  onChange={(event) => updateValue('header', event.target.value)}
                  placeholder="Limited-time access"
                  className="mt-2 min-h-[52px] w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 text-sm text-slate-900 outline-none transition focus:border-indigo-300 focus:bg-white"
                />
              </label>

              <label className="block">
                <span className="text-sm font-semibold text-slate-700">Body</span>
                <textarea
                  value={values.body}
                  onChange={(event) => updateValue('body', event.target.value)}
                  placeholder="Hi {{1}}, your VIP offer is ready. Use code {{2}} before tonight."
                  rows={7}
                  className="mt-2 w-full rounded-[24px] border border-slate-200 bg-slate-50 px-4 py-4 text-sm leading-7 text-slate-900 outline-none transition focus:border-indigo-300 focus:bg-white"
                />
              </label>

              <label className="block">
                <span className="text-sm font-semibold text-slate-700">Footer</span>
                <input
                  value={values.footer}
                  onChange={(event) => updateValue('footer', event.target.value)}
                  placeholder="Reply STOP to unsubscribe"
                  className="mt-2 min-h-[52px] w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 text-sm text-slate-900 outline-none transition focus:border-indigo-300 focus:bg-white"
                />
              </label>
            </div>
          </section>

          {variableTokens.length > 0 ? (
            <section className="rounded-[28px] border border-cyan-100 bg-cyan-50/80 p-5 shadow-[0_18px_35px_rgba(6,182,212,0.08)]">
              <div className="flex items-center gap-2 text-cyan-700">
                <Sparkles size={16} />
                <div className="text-sm font-semibold">Live sample data</div>
              </div>
              <p className="mt-2 text-sm leading-6 text-cyan-800/80">
                Add sample values so mobile previews feel like real WhatsApp messages while you edit.
              </p>
              <div className="mt-4 grid gap-3 sm:grid-cols-2">
                {variableTokens.map((token) => (
                  <label key={token} className="block">
                    <span className="text-sm font-semibold text-cyan-900">{`{{${token}}}`}</span>
                    <input
                      value={sampleValues[token] || ''}
                      onChange={(event) =>
                        setSampleValues((current) => ({
                          ...current,
                          [token]: event.target.value,
                        }))
                      }
                      placeholder={`Sample for {{${token}}}`}
                      className="mt-2 min-h-[48px] w-full rounded-2xl border border-cyan-100 bg-white px-4 text-sm text-slate-900 outline-none transition focus:border-cyan-300"
                    />
                  </label>
                ))}
              </div>
            </section>
          ) : null}

          <section className="rounded-[28px] border border-white/70 bg-white p-5 shadow-[0_20px_45px_rgba(15,23,42,0.08)]">
            <div className="flex items-center justify-between gap-3">
              <div>
                <div className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-400">Actions</div>
                <div className="mt-2 text-lg font-semibold text-slate-950">Buttons</div>
              </div>
              <button
                type="button"
                onClick={() =>
                  setValues((current) => ({
                    ...current,
                    buttons: current.buttons.length >= 3 ? current.buttons : [...current.buttons, emptyButton()],
                  }))
                }
                disabled={values.buttons.length >= 3}
                className="inline-flex min-h-[44px] items-center justify-center gap-2 rounded-2xl border border-slate-200 px-4 text-sm font-semibold text-slate-700 transition hover:border-indigo-200 hover:text-indigo-700 disabled:cursor-not-allowed disabled:opacity-50"
              >
                <Plus size={16} />
                Add button
              </button>
            </div>

            <div className="mt-5 space-y-4">
              {values.buttons.length === 0 ? (
                <div className="rounded-[22px] border border-dashed border-slate-200 bg-slate-50 px-4 py-5 text-sm text-slate-500">
                  Add up to 3 WhatsApp action buttons for quick replies, links, or call actions.
                </div>
              ) : (
                values.buttons.map((button, index) => (
                  <div key={`button-${index}`} className="rounded-[24px] border border-slate-200 bg-slate-50 p-4">
                    <div className="flex items-start justify-between gap-3">
                      <div className="grid flex-1 gap-4 md:grid-cols-[160px_minmax(0,1fr)]">
                        <label className="block">
                          <span className="text-sm font-semibold text-slate-700">Type</span>
                          <select
                            value={button.type}
                            onChange={(event) => updateButton(index, 'type', event.target.value as TemplateButtonType)}
                            className="mt-2 min-h-[48px] w-full rounded-2xl border border-slate-200 bg-white px-4 text-sm text-slate-900 outline-none transition focus:border-indigo-300"
                          >
                            <option value="QUICK_REPLY">Quick reply</option>
                            <option value="URL">URL</option>
                            <option value="PHONE_NUMBER">Phone number</option>
                          </select>
                        </label>

                        <label className="block">
                          <span className="text-sm font-semibold text-slate-700">Label</span>
                          <input
                            value={button.text}
                            onChange={(event) => updateButton(index, 'text', event.target.value)}
                            placeholder="Track order"
                            className="mt-2 min-h-[48px] w-full rounded-2xl border border-slate-200 bg-white px-4 text-sm text-slate-900 outline-none transition focus:border-indigo-300"
                          />
                        </label>
                      </div>

                      <button
                        type="button"
                        onClick={() =>
                          setValues((current) => ({
                            ...current,
                            buttons: current.buttons.filter((_, buttonIndex) => buttonIndex !== index),
                          }))
                        }
                        className="inline-flex h-11 w-11 items-center justify-center rounded-2xl border border-slate-200 bg-white text-slate-500 transition hover:border-rose-200 hover:text-rose-600"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>

                    {button.type !== 'QUICK_REPLY' ? (
                      <label className="mt-4 block">
                        <span className="text-sm font-semibold text-slate-700">
                          {button.type === 'URL' ? 'Destination URL' : 'Phone number'}
                        </span>
                        <input
                          value={button.value || ''}
                          onChange={(event) => updateButton(index, 'value', event.target.value)}
                          placeholder={button.type === 'URL' ? 'https://marketingos.app/demo' : '+91 98765 43210'}
                          className="mt-2 min-h-[48px] w-full rounded-2xl border border-slate-200 bg-white px-4 text-sm text-slate-900 outline-none transition focus:border-indigo-300"
                        />
                      </label>
                    ) : null}
                  </div>
                ))
              )}
            </div>
          </section>
        </div>

        <aside className="border-t border-white/70 bg-gradient-to-br from-slate-950 via-slate-900 to-indigo-950 p-5 text-white lg:sticky lg:top-0 lg:h-[calc(100vh-120px)] lg:border-l lg:border-t-0 lg:p-6">
          <div className="rounded-[30px] border border-white/12 bg-white/8 p-5 shadow-[0_30px_60px_rgba(2,6,23,0.32)] backdrop-blur">
            <div className="text-xs font-semibold uppercase tracking-[0.18em] text-white/60">Live preview</div>
            <div className="mt-2 text-2xl font-semibold">What customers will see</div>
            <p className="mt-2 text-sm leading-6 text-white/70">
              Preview the template inside a WhatsApp-style message bubble before you submit it to Meta.
            </p>
            <WhatsAppTemplatePreview
              className="mt-5"
              header={values.header}
              body={values.body}
              footer={values.footer}
              buttons={values.buttons}
              sampleValues={sampleValues}
            />
          </div>
        </aside>
      </div>
    </Drawer>
  );
}
