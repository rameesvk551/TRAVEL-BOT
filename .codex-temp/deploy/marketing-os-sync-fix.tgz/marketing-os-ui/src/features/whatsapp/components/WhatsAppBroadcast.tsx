// WhatsAppBroadcast.tsx — Broadcast tab with history + new broadcast form.
// All broadcast creation logic lives in hooks/useBroadcast.ts

import React, { useState } from 'react';
import {
    Card, Steps, Form, Select, Button, Input, Radio, DatePicker,
    Typography, Space, Tag, Alert, Row, Col, Statistic, Divider, Segmented,
} from 'antd';
import {
    ScheduleOutlined, SendOutlined, FileTextOutlined,
    PhoneOutlined, CloudUploadOutlined, UserOutlined, UploadOutlined,
    ArrowLeftOutlined,
} from '@ant-design/icons';
import { useBroadcast } from '../hooks/useBroadcast';
import BroadcastHistory from './BroadcastHistory';
import './whatsapp-broadcast.css';

const { Title, Text, Paragraph } = Typography;
const { Option } = Select;
const { TextArea } = Input;

const WhatsAppBroadcast: React.FC = () => {
    const [showNewForm, setShowNewForm] = useState(false);
    const {
        form, currentStep, selectedTemplate, recipientCount, templates,
        isSending,
        handleTemplateChange, onRecipientsChange, next, prev, handleSend,
    } = useBroadcast();

    const steps = [
        { title: 'Template', description: 'Choose one', icon: <FileTextOutlined /> },
        { title: 'Recipients', description: 'Select audience', icon: <UserOutlined /> },
        { title: 'Send', description: 'Review and confirm', icon: <ScheduleOutlined /> },
    ];

    // Show history by default, toggle to new broadcast form
    if (!showNewForm) {
        return <BroadcastHistory onNewBroadcast={() => setShowNewForm(true)} />;
    }

    return (
        <div className="broadcast-shell animate-fade-in">
            <Card bordered={false} className="broadcast-card" styles={{ body: { padding: 0 } }}>
                <div className="broadcast-topbar">
                    <Button
                        type="text"
                        icon={<ArrowLeftOutlined />}
                        onClick={() => setShowNewForm(false)}
                        className="broadcast-back-btn"
                    >
                        Back to Broadcast History
                    </Button>
                </div>

                <div className="broadcast-hero">
                    <Tag color="default" className="broadcast-hero-tag">WhatsApp Broadcast</Tag>
                    <Title level={2} className="broadcast-hero-title">Create Broadcast</Title>
                    <Text type="secondary" className="broadcast-hero-subtitle">
                        Pick a template, choose recipients, and send.
                    </Text>
                </div>

                <div className="broadcast-steps-wrap">
                    <Steps current={currentStep} items={steps} responsive={false} />
                </div>

                <Form form={form} layout="vertical" initialValues={{ recipientSource: 'manual', schedule: 'now' }}>
                    <div className="broadcast-stage">
                        {currentStep === 0 && (
                            <div className="animate-fade-in">
                                <Form.Item name="templateId" label={<Text strong>Select a Template</Text>} rules={[{ required: true, message: 'Please select a template' }]}>
                                    <Select placeholder="Search and select an approved template..." onChange={handleTemplateChange} size="large" style={{ width: '100%' }} showSearch optionFilterProp="children">
                                        {templates.map((t: any) => (
                                            <Option key={t.id} value={t.id}>{t.template_name || t.name} ({t.language})</Option>
                                        ))}
                                    </Select>
                                </Form.Item>

                                {selectedTemplate && (
                                    <div className="broadcast-template-layout">
                                        <div className="broadcast-template-meta">
                                            <Card title="Template Details" size="small" bordered={false} className="broadcast-soft-panel">
                                                <Space direction="vertical">
                                                    <div><Text type="secondary">Name: </Text><Text strong>{selectedTemplate.template_name || selectedTemplate.name}</Text></div>
                                                    <div><Text type="secondary">Language: </Text><Tag>{selectedTemplate.language}</Tag></div>
                                                    <div><Text type="secondary">Category: </Text><Tag color="blue">{selectedTemplate.category}</Tag></div>
                                                </Space>
                                            </Card>
                                        </div>
                                        <div className="broadcast-template-preview">
                                            <div className="broadcast-chat-bg">
                                                <div className="broadcast-chat-bubble">
                                                    <Paragraph style={{ margin: 0, fontSize: 15, lineHeight: 1.5 }}>
                                                        {selectedTemplate.components?.find((c: any) => c.type === 'BODY')?.text}
                                                    </Paragraph>
                                                    <div style={{ textAlign: 'right', marginTop: 4 }}>
                                                        <Text type="secondary" style={{ fontSize: 11 }}>12:05 PM</Text>
                                                    </div>
                                                </div>
                                            </div>
                                            <Text type="secondary" className="broadcast-preview-caption">Message Preview</Text>
                                        </div>
                                    </div>
                                )}
                            </div>
                        )}

                        {currentStep === 1 && (
                            <div className="animate-fade-in">
                                <Form.Item label={<Text strong>How would you like to add recipients?</Text>}>
                                    <Form.Item name="recipientSource" noStyle>
                                        <Segmented
                                            options={[
                                                { label: 'Manual', value: 'manual', icon: <PhoneOutlined /> },
                                                { label: 'Upload CSV', value: 'csv', icon: <CloudUploadOutlined /> },
                                                { label: 'Contacts', value: 'contacts', icon: <UserOutlined /> },
                                            ]}
                                            block size="large"
                                        />
                                    </Form.Item>
                                </Form.Item>

                                <Divider style={{ margin: '24px 0' }} />

                                <Form.Item noStyle shouldUpdate={(prev, current) => prev.recipientSource !== current.recipientSource}>
                                    {({ getFieldValue }) => {
                                        const source = getFieldValue('recipientSource');
                                        return source === 'manual' ? (
                                            <Form.Item name="recipients" label="Phone Numbers" rules={[{ required: true, message: 'Please enter at least one phone number' }]} help="Enter phone numbers with country code (e.g., 15551234567), one per line.">
                                                <TextArea rows={12} onChange={onRecipientsChange} placeholder={"15551234567\n919876543210"} style={{ fontFamily: 'monospace' }} />
                                            </Form.Item>
                                        ) : source === 'csv' ? (
                                            <div style={{ padding: 60, textAlign: 'center', background: '#fafafa', border: '2px dashed #d9d9d9', borderRadius: 12, cursor: 'pointer' }}>
                                                <p className="ant-upload-drag-icon"><UploadOutlined style={{ fontSize: 48, color: '#1890ff', opacity: 0.8 }} /></p>
                                                <Title level={4} style={{ marginTop: 16 }}>Upload CSV</Title>
                                                <p className="ant-upload-hint">Drag a file here or choose one from your device.</p>
                                                <Button style={{ marginTop: 16 }}>Select File</Button>
                                            </div>
                                        ) : (
                                            <div style={{ padding: '24px', background: '#fafafa', borderRadius: 8, border: '1px solid #f0f0f0' }}>
                                                <Title level={5} style={{ marginTop: 0 }}>Audience Tags</Title>
                                                <Text type="secondary" style={{ display: 'block', marginBottom: 16 }}>
                                                    Select tags to target contacts. Leave empty to target all opted-in contacts.
                                                </Text>
                                                <Form.Item name="audienceTags" tooltip="e.g. vip, new_customer, newsletter">
                                                    <Select
                                                        mode="tags"
                                                        style={{ width: '100%' }}
                                                        placeholder="Type a tag and press Enter"
                                                        size="large"
                                                        onChange={onRecipientsChange}
                                                    />
                                                </Form.Item>
                                            </div>
                                        );
                                    }}
                                </Form.Item>

                                <div className="broadcast-audience-count">
                                    <Tag color="cyan" style={{ fontSize: 14, padding: '4px 12px' }}>
                                        <UserOutlined /> {recipientCount} Recipients Identified
                                    </Tag>
                                </div>
                            </div>
                        )}

                        {currentStep === 2 && (
                            <div className="animate-fade-in">
                                <Alert message="Ready to send" description="Check your details before sending." type="info" showIcon style={{ marginBottom: 32 }} />
                                <Row gutter={32}>
                                    <Col xs={24} lg={14}>
                                        <Card title="Campaign Overview" bordered={false} className="broadcast-soft-panel broadcast-fill-height">
                                            <Statistic title="Total Recipients" value={recipientCount} prefix={<UserOutlined style={{ color: '#1890ff' }} />} valueStyle={{ fontWeight: 600 }} />
                                            <Divider />
                                            <div style={{ marginBottom: 16 }}>
                                                <Text type="secondary">Template:</Text>
                                                <div style={{ fontSize: 16, fontWeight: 500 }}>{selectedTemplate?.template_name || selectedTemplate?.name}</div>
                                            </div>
                                            <div><Text type="secondary">Language:</Text><div>{selectedTemplate?.language}</div></div>
                                        </Card>
                                    </Col>
                                    <Col xs={24} lg={10}>
                                        <Card title="Scheduling" bordered={false} className="broadcast-fill-height broadcast-schedule-panel">
                                            <Form.Item name="schedule" label="When should this send?">
                                                <Radio.Group style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                                                    <Radio value="now">
                                                        <Space direction="vertical" size={2}>
                                                            <Text strong>Send now</Text>
                                                            <Text type="secondary" style={{ fontSize: 12 }}>Start as soon as it is processed</Text>
                                                        </Space>
                                                    </Radio>
                                                    <Radio value="later">
                                                        <Space direction="vertical" size={2}>
                                                            <Text strong>Schedule</Text>
                                                            <Text type="secondary" style={{ fontSize: 12 }}>Pick a date and time</Text>
                                                        </Space>
                                                    </Radio>
                                                </Radio.Group>
                                            </Form.Item>
                                            <Form.Item noStyle shouldUpdate={(prev, current) => prev.schedule !== current.schedule}>
                                                {({ getFieldValue }) => getFieldValue('schedule') === 'later' && (
                                                    <Form.Item name="scheduledTime" rules={[{ required: true }]}>
                                                        <DatePicker showTime style={{ width: '100%' }} size="large" />
                                                    </Form.Item>
                                                )}
                                            </Form.Item>
                                            <Divider style={{ margin: '12px 0' }} />
                                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                                                <Text type="secondary">Estimated cost</Text>
                                                <Title level={4} style={{ margin: 0, color: '#52c41a' }}>${(recipientCount * 0.05).toFixed(2)}</Title>
                                            </div>
                                        </Card>
                                    </Col>
                                </Row>
                            </div>
                        )}
                    </div>

                    <Divider style={{ margin: '40px 0 24px 0' }} />

                    <div className="broadcast-footer-actions">
                        <Button onClick={prev} disabled={currentStep === 0} size="large" style={{ minWidth: 100 }}>Back</Button>
                        {currentStep < steps.length - 1 ? (
                            <Button type="primary" onClick={next} size="large" style={{ minWidth: 120 }}>Continue</Button>
                        ) : (
                            <Button type="primary" icon={<SendOutlined />} onClick={handleSend} size="large" loading={isSending} style={{ minWidth: 160 }}>
                                Send Broadcast
                            </Button>
                        )}
                    </div>
                </Form>
            </Card>
        </div>
    );
};

export default WhatsAppBroadcast;
