import { startTransition, useDeferredValue, useMemo, useState, type ReactNode } from 'react';
import {
  AlertCircle,
  ArrowUpRight,
  BadgeCheck,
  CalendarClock,
  ChevronDown,
  Clock3,
  Compass,
  Flame,
  GraduationCap,
  Landmark,
  LayoutGrid,
  PackageX,
  Plus,
  RefreshCw,
  Rocket,
  Search,
  ShoppingBasket,
  Star,
  TicketPercent,
  Truck,
  WalletCards,
} from 'lucide-react';

import { useTemplates } from '../hooks/useTemplates';
import { TemplateComposer } from './templates/TemplateComposer';
import { TemplateDetailSheet } from './templates/TemplateDetailSheet';
import {
  createTemplatePreviewModel,
  defaultTemplateDraft,
  formatTemplateDisplayName,
  getStatusMeta,
  prebuiltTemplatePresets,
  templateToDraft,
  type NormalizedTemplate,
  type TemplateDraftValues,
  type TemplatePresetCollection,
  type TemplatePresetIconKey,
  type TemplatePresetIndustry,
  type TemplatePresetKind,
  type TemplateStatus,
} from './templates/templateUtils';

type GalleryTab = 'EXPLORE' | 'ALL' | 'DRAFT' | 'PENDING' | 'APPROVED' | 'ACTION_REQUIRED';
type ExploreCollectionFilter = 'ALL' | TemplatePresetCollection;
type TemplateSource = 'preset' | 'saved';

interface GalleryItem {
  id: string;
  source: TemplateSource;
  template: NormalizedTemplate;
  title: string;
  kind: TemplatePresetKind;
  iconKey: TemplatePresetIconKey;
  summary: string;
  collection?: TemplatePresetCollection;
  industry?: TemplatePresetIndustry;
}

const pageTabs: Array<{
  key: GalleryTab;
  label: string;
  icon: typeof Compass;
}> = [
  { key: 'EXPLORE', label: 'Template Library', icon: Compass },
  { key: 'ALL', label: 'All', icon: LayoutGrid },
  { key: 'DRAFT', label: 'Draft', icon: ArrowUpRight },
  { key: 'PENDING', label: 'Pending', icon: Clock3 },
  { key: 'APPROVED', label: 'Approved', icon: BadgeCheck },
  { key: 'ACTION_REQUIRED', label: 'Action Required', icon: AlertCircle },
];

const collectionOptions: Array<{
  key: TemplatePresetCollection;
  label: string;
  icon: typeof Flame;
}> = [
  { key: 'TRENDING', label: 'Trending', icon: Flame },
  { key: 'GENERAL', label: 'General', icon: Compass },
  { key: 'TOP_RATED', label: 'Top Rated', icon: Star },
];

const industryOptions: Array<{
  key: TemplatePresetIndustry;
  label: string;
  icon: typeof ShoppingBasket;
}> = [
  { key: 'ECOMMERCE', label: 'Ecommerce', icon: ShoppingBasket },
  { key: 'EDUCATION', label: 'Education', icon: GraduationCap },
  { key: 'BANKING', label: 'Banking', icon: Landmark },
  { key: 'WEBINAR', label: 'Webinar', icon: CalendarClock },
];

const kindToneMap: Record<TemplatePresetKind, string> = {
  IMAGE: 'border-amber-200 bg-amber-50 text-amber-700',
  TEXT: 'border-cyan-200 bg-cyan-50 text-cyan-700',
  FILE: 'border-pink-200 bg-pink-50 text-pink-700',
};

const iconToneMap: Record<
  TemplatePresetIconKey,
  {
    icon: typeof TicketPercent;
    shellClassName: string;
    iconClassName: string;
    glowClassName: string;
  }
> = {
  offer: {
    icon: TicketPercent,
    shellClassName: 'border-rose-100 bg-rose-50',
    iconClassName: 'text-rose-500',
    glowClassName: 'from-rose-200 via-amber-100 to-transparent',
  },
  cancel: {
    icon: PackageX,
    shellClassName: 'border-violet-100 bg-violet-50',
    iconClassName: 'text-violet-500',
    glowClassName: 'from-violet-200 via-fuchsia-100 to-transparent',
  },
  payment: {
    icon: WalletCards,
    shellClassName: 'border-sky-100 bg-sky-50',
    iconClassName: 'text-sky-500',
    glowClassName: 'from-sky-200 via-cyan-100 to-transparent',
  },
  delivery: {
    icon: Truck,
    shellClassName: 'border-orange-100 bg-orange-50',
    iconClassName: 'text-orange-500',
    glowClassName: 'from-orange-200 via-amber-100 to-transparent',
  },
  upsell: {
    icon: ShoppingBasket,
    shellClassName: 'border-lime-100 bg-lime-50',
    iconClassName: 'text-lime-600',
    glowClassName: 'from-lime-200 via-emerald-100 to-transparent',
  },
  launch: {
    icon: Rocket,
    shellClassName: 'border-pink-100 bg-pink-50',
    iconClassName: 'text-pink-500',
    glowClassName: 'from-pink-200 via-rose-100 to-transparent',
  },
  lesson: {
    icon: GraduationCap,
    shellClassName: 'border-indigo-100 bg-indigo-50',
    iconClassName: 'text-indigo-500',
    glowClassName: 'from-indigo-200 via-blue-100 to-transparent',
  },
  bank: {
    icon: Landmark,
    shellClassName: 'border-emerald-100 bg-emerald-50',
    iconClassName: 'text-emerald-600',
    glowClassName: 'from-emerald-200 via-teal-100 to-transparent',
  },
  event: {
    icon: CalendarClock,
    shellClassName: 'border-cyan-100 bg-cyan-50',
    iconClassName: 'text-cyan-600',
    glowClassName: 'from-cyan-200 via-sky-100 to-transparent',
  },
};

const loadingCards = Array.from({ length: 6 }, (_, index) => index);

const matchesGalleryItem = (item: GalleryItem, query: string) => {
  const haystack = [
    item.title,
    item.template.name,
    item.summary,
    item.template.category,
    item.template.language,
    item.template.status,
    item.template.header,
    item.template.body,
    item.template.footer,
    item.kind,
    item.collection || '',
    item.industry || '',
  ]
    .join(' ')
    .toLowerCase();

  return haystack.includes(query);
};

const getSavedTemplateKind = (template: NormalizedTemplate): TemplatePresetKind => {
  if (template.category === 'MARKETING') {
    return 'IMAGE';
  }

  if (template.category === 'SERVICE') {
    return 'FILE';
  }

  return 'TEXT';
};

const getSavedTemplateIconKey = (template: NormalizedTemplate): TemplatePresetIconKey => {
  switch (template.category) {
    case 'MARKETING':
      return 'offer';
    case 'AUTHENTICATION':
      return 'bank';
    case 'SERVICE':
      return 'event';
    default:
      return 'delivery';
  }
};

const getTabStatus = (tab: GalleryTab): TemplateStatus | null => {
  switch (tab) {
    case 'DRAFT':
      return 'DRAFT';
    case 'PENDING':
      return 'PENDING';
    case 'APPROVED':
      return 'APPROVED';
    case 'ACTION_REQUIRED':
      return 'REJECTED';
    default:
      return null;
  }
};

const getSavedPrimaryAction = (
  template: NormalizedTemplate,
  isBusy: boolean,
  busyAction: string | null
) => {
  if (isBusy) {
    return {
      label: busyAction === 'submit' ? 'Submitting...' : 'Working...',
      disabled: true,
    };
  }

  if (template.status === 'APPROVED') {
    return { label: 'Approved', disabled: true };
  }

  if (template.status === 'PENDING') {
    return { label: 'Pending', disabled: true };
  }

  return { label: 'Submit', disabled: false };
};

const renderLoadingGrid = () => (
  <section className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
    {loadingCards.map((card) => (
      <div
        key={card}
        className="animate-pulse rounded-lg border border-slate-200 bg-white p-4 shadow-sm"
      >
        <div className="flex items-start justify-between gap-3">
          <div className="h-12 w-12 rounded-full bg-slate-100" />
          <div className="h-6 w-16 rounded-full bg-slate-100" />
        </div>
        <div className="mt-4 h-5 w-32 rounded-full bg-slate-100" />
        <div className="mt-2 h-4 w-20 rounded-full bg-slate-100" />
        <div className="mt-4 h-16 rounded-lg bg-slate-100" />
        <div className="mt-5 flex gap-2">
          <div className="h-8 flex-1 rounded-md bg-slate-100" />
          <div className="h-8 flex-1 rounded-md bg-slate-100" />
        </div>
      </div>
    ))}
  </section>
);

function TemplateGalleryCard({
  item,
  topRight,
  primaryActionLabel,
  primaryActionDisabled,
  onPreview,
  onPrimaryAction,
}: {
  item: GalleryItem;
  topRight: ReactNode;
  primaryActionLabel: string;
  primaryActionDisabled?: boolean;
  onPreview: () => void;
  onPrimaryAction: () => void;
}) {
  const iconTheme = iconToneMap[item.iconKey];
  const Icon = iconTheme.icon;

  return (
    <article className="group flex h-full flex-col rounded-lg border border-[#e8e8e8] bg-white p-3.5 transition hover:border-[#d8d8d8]">
      <div className="flex items-start justify-between gap-3">
        <div className="relative">
          <div className={`absolute inset-0 rounded-full bg-gradient-to-br ${iconTheme.glowClassName} blur-xl opacity-70`} />
          <div
            className={`relative flex h-12 w-12 items-center justify-center rounded-full border ${iconTheme.shellClassName}`}
          >
            <Icon size={22} className={iconTheme.iconClassName} />
          </div>
        </div>
        {topRight}
      </div>

      <div className="mt-3">
        <h3 className="text-[1.05rem] font-semibold leading-tight text-[#2f2f2f]">{item.title}</h3>
        <div className="mt-1.5 flex flex-wrap items-center gap-2 text-[11px]">
          <span
            className={`inline-flex rounded px-1.5 py-[1px] font-semibold uppercase tracking-[0.08em] ${kindToneMap[item.kind]}`}
          >
            {item.kind}
          </span>
          <span className="text-slate-300">•</span>
          <span className="font-medium text-slate-500">
            {item.source === 'preset' ? 'Ready-made' : item.template.category}
          </span>
        </div>
      </div>

      <p
        className="mt-3 min-h-[60px] text-[12px] leading-5 text-slate-600"
        style={{
          display: '-webkit-box',
          WebkitLineClamp: 3,
          WebkitBoxOrient: 'vertical',
          overflow: 'hidden',
        }}
      >
        {item.template.body}
      </p>

      <div className="mt-auto flex items-center gap-2 pt-4">
        <button
          type="button"
          onClick={onPreview}
          className="inline-flex min-h-[32px] items-center justify-center rounded-md border border-[#0f6f75] px-3 text-xs font-semibold text-[#0f6f75] transition hover:bg-[#f3fbfb]"
        >
          Preview
        </button>

        <button
          type="button"
          onClick={onPrimaryAction}
          disabled={primaryActionDisabled}
          className="inline-flex min-h-[32px] flex-1 items-center justify-center rounded-md border border-[#dfdfdf] bg-[#f0f0f0] px-3 text-xs font-semibold text-slate-500 transition hover:bg-[#e8e8e8] disabled:cursor-not-allowed disabled:opacity-70"
        >
          {primaryActionLabel}
        </button>
      </div>
    </article>
  );
}

const WhatsAppTemplates = () => {
  const {
    templates,
    isLoading,
    isSaving,
    isSyncing,
    busyTemplateId,
    busyAction,
    createTemplate,
    updateTemplate,
    submitTemplate,
    requestDeleteTemplate,
    syncTemplates,
  } = useTemplates();

  const [searchValue, setSearchValue] = useState('');
  const [activeTab, setActiveTab] = useState<GalleryTab>('EXPLORE');
  const [activeCollection, setActiveCollection] = useState<ExploreCollectionFilter>('ALL');
  const [activeIndustry, setActiveIndustry] = useState<TemplatePresetIndustry>('ECOMMERCE');
  const [composerOpen, setComposerOpen] = useState(false);
  const [composerMode, setComposerMode] = useState<'create' | 'edit'>('create');
  const [composerTemplate, setComposerTemplate] = useState<NormalizedTemplate | null>(null);
  const [composerDraftValues, setComposerDraftValues] = useState<TemplateDraftValues | null>(null);
  const [detailItem, setDetailItem] = useState<GalleryItem | null>(null);

  const deferredSearch = useDeferredValue(searchValue);

  const presetGalleryItems = useMemo<GalleryItem[]>(
    () =>
      prebuiltTemplatePresets.map((preset) => ({
        id: `preset-${preset.id}`,
        source: 'preset',
        template: createTemplatePreviewModel(preset.draft, {
          id: `preset-${preset.id}`,
          status: 'APPROVED',
        }),
        title: preset.title,
        kind: preset.kind,
        iconKey: preset.iconKey,
        summary: preset.summary,
        collection: preset.collection,
        industry: preset.industry,
      })),
    []
  );

  const savedGalleryItems = useMemo<GalleryItem[]>(
    () =>
      templates.map((template) => ({
        id: template.id,
        source: 'saved',
        template,
        title: formatTemplateDisplayName(template.name),
        kind: getSavedTemplateKind(template),
        iconKey: getSavedTemplateIconKey(template),
        summary: 'Saved template',
      })),
    [templates]
  );

  const visibleItems = useMemo(() => {
    const query = deferredSearch.trim().toLowerCase();

    if (activeTab === 'EXPLORE') {
      return presetGalleryItems.filter((item) => {
        const matchesCollection = activeCollection === 'ALL' ? true : item.collection === activeCollection;
        const matchesIndustry = item.industry === activeIndustry;
        const matchesSearch = query ? matchesGalleryItem(item, query) : true;
        return matchesCollection && matchesIndustry && matchesSearch;
      });
    }

    const statusFilter = getTabStatus(activeTab);

    return savedGalleryItems.filter((item) => {
      const matchesStatus = statusFilter ? item.template.status === statusFilter : true;
      const matchesSearch = query ? matchesGalleryItem(item, query) : true;
      return matchesStatus && matchesSearch;
    });
  }, [activeCollection, activeIndustry, activeTab, deferredSearch, presetGalleryItems, savedGalleryItems]);

  const openCreateComposer = (draftValues: TemplateDraftValues = defaultTemplateDraft()) => {
    setDetailItem(null);
    setComposerMode('create');
    setComposerTemplate(null);
    setComposerDraftValues(draftValues);
    setComposerOpen(true);
  };

  const openEditComposer = (template: NormalizedTemplate) => {
    setDetailItem(null);
    setComposerMode('edit');
    setComposerTemplate(template);
    setComposerDraftValues(null);
    setComposerOpen(true);
  };

  const handleSaveTemplate = async (values: TemplateDraftValues) => {
    if (composerMode === 'edit' && composerTemplate) {
      await updateTemplate(composerTemplate.id, values);
    } else {
      await createTemplate(values);
    }

    setComposerOpen(false);
    setComposerTemplate(null);
    setComposerDraftValues(null);
  };

  const handleDuplicate = (template: NormalizedTemplate) => {
    setDetailItem(null);
    openCreateComposer({
      ...templateToDraft(template),
      name: `${template.name}_copy`,
    });
  };

  const handleDelete = (template: NormalizedTemplate) => {
    if (detailItem?.template.id === template.id) {
      setDetailItem(null);
    }

    requestDeleteTemplate(template);
  };

  const handleSubmit = async (template: NormalizedTemplate) => {
    await submitTemplate(template);

    if (detailItem?.template.id === template.id) {
      setDetailItem(null);
    }
  };

  const handleUsePreset = (item: GalleryItem) => {
    setDetailItem(null);
    openCreateComposer(templateToDraft(item.template));
  };

  const selectExploreCollection = (collection: TemplatePresetCollection) => {
    startTransition(() => {
      setActiveTab('EXPLORE');
      setActiveCollection((current) => (current === collection ? 'ALL' : collection));
    });
  };

  const selectExploreIndustry = (industry: TemplatePresetIndustry) => {
    startTransition(() => {
      setActiveTab('EXPLORE');
      setActiveIndustry(industry);
    });
  };

  const clearFilters = () => {
    setSearchValue('');
    startTransition(() => {
      if (activeTab === 'EXPLORE') {
        setActiveCollection('ALL');
      }
    });
  };

  const hasSavedTemplates = savedGalleryItems.length > 0;
  const showLoadingGrid = activeTab !== 'EXPLORE' && isLoading;
  const activeIndustryLabel = industryOptions.find((option) => option.key === activeIndustry)?.label || 'Templates';

  return (
    <div className="overflow-hidden rounded-md border border-[#ececec] bg-[#f5f5f5]">
      <header className="border-b border-[#e7e7e7] bg-[#f5f5f5] px-4 py-3 sm:px-6">
        <div className="flex items-center justify-between gap-4">
          <div className="text-[1.75rem] font-semibold leading-tight text-[#2a2a2a]">Template Messages</div>

          <button
            type="button"
            onClick={() => openCreateComposer()}
            className="inline-flex h-9 items-center justify-center gap-2 rounded-md border border-[#d9d9d9] bg-[#eaeaea] px-3 text-sm font-medium text-slate-600 transition hover:bg-[#e3e3e3]"
          >
            <Plus size={14} />
            New
          </button>
        </div>
      </header>

      <div className="px-4 py-5 sm:px-6">
        <div className="flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between">
          <label className="relative block max-w-xl xl:w-full xl:max-w-sm">
            <Search
              size={16}
              className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-[#2c8b8b]"
            />
            <input
              value={searchValue}
              onChange={(event) => setSearchValue(event.target.value)}
              placeholder="Search templates (status, name etc.)"
              className="h-9 w-full rounded-md border border-[#dfdfdf] bg-white pl-10 pr-3 text-sm text-slate-900 outline-none transition focus:border-[#5db3b3] focus:ring-2 focus:ring-[#d9f0f0]"
            />
          </label>

          <button
            type="button"
            onClick={() => syncTemplates()}
            disabled={isSyncing}
            className="inline-flex h-9 items-center justify-center gap-2 self-start rounded-md border border-[#d9d9d9] bg-[#eaeaea] px-3 text-sm font-medium text-slate-600 transition hover:bg-[#e3e3e3] disabled:cursor-not-allowed disabled:opacity-70"
          >
            <RefreshCw size={14} className={isSyncing ? 'animate-spin' : ''} />
            {isSyncing ? 'Syncing...' : 'Sync Status'}
          </button>
        </div>

        <nav className="mt-5 overflow-x-auto border-b border-[#dfdfdf]">
          <div className="flex min-w-max items-center gap-10 pr-4">
            {pageTabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = tab.key === activeTab;

              return (
                <button
                  key={tab.key}
                  type="button"
                  onClick={() => {
                    startTransition(() => setActiveTab(tab.key));
                  }}
                  className={`inline-flex min-h-[44px] items-center gap-2 border-b-[3px] px-0.5 text-[15px] font-medium transition ${
                    isActive
                      ? 'border-[#0f6f75] text-[#0f6f75]'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  <Icon size={18} />
                  {tab.label}
                </button>
              );
            })}
          </div>
        </nav>

        <div className={`mt-6 grid gap-6 ${activeTab === 'EXPLORE' ? 'xl:grid-cols-[190px_minmax(0,1fr)]' : ''}`}>
          {activeTab === 'EXPLORE' && (
            <aside className="border-b border-[#dfdfdf] pb-5 xl:border-b-0 xl:border-r xl:pr-5">
            <div className="space-y-2">
              {collectionOptions.map((option) => {
                const Icon = option.icon;
                const active = activeCollection === option.key && activeTab === 'EXPLORE';

                return (
                  <button
                    key={option.key}
                    type="button"
                    onClick={() => selectExploreCollection(option.key)}
                    className={`flex w-full items-center gap-3 rounded-md px-3 py-2.5 text-left text-[15px] transition ${
                      active ? 'bg-[#e7ecef] text-[#1f1f1f]' : 'text-slate-600 hover:bg-white hover:text-slate-900'
                    }`}
                  >
                    <Icon size={16} />
                    {option.label}
                  </button>
                );
              })}
            </div>

            <div className="mt-6">
              <div className="flex items-center justify-between px-3 text-sm font-medium text-slate-600">
                <span>Industry</span>
                <ChevronDown size={15} />
              </div>

              <div className="mt-2 space-y-1.5">
                {industryOptions.map((option) => {
                  const Icon = option.icon;
                  const active = activeIndustry === option.key && activeTab === 'EXPLORE';

                  return (
                    <button
                      key={option.key}
                      type="button"
                      onClick={() => selectExploreIndustry(option.key)}
                      className={`flex w-full items-center gap-3 rounded-md px-3 py-2.5 text-left text-[15px] transition ${
                        active ? 'bg-[#e7ecef] text-[#1f1f1f]' : 'text-slate-600 hover:bg-white hover:text-slate-900'
                      }`}
                    >
                      <Icon size={16} />
                      {option.label}
                    </button>
                  );
                })}
              </div>

              <button
                type="button"
                onClick={() => {
                  startTransition(() => {
                    setActiveTab('EXPLORE');
                    setActiveCollection('ALL');
                  });
                }}
                className="mt-6 px-3 text-sm font-semibold uppercase tracking-[0.16em] text-teal-800"
              >
                More
              </button>
            </div>
          </aside>
          )}

          <section>
            <div className="mb-4 flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
              <div>
                <div className="text-[11px] font-semibold uppercase tracking-[0.13em] text-slate-400">
                  {activeTab === 'EXPLORE' ? 'Preset gallery' : 'Saved library'}
                </div>
                <h2 className="mt-1 text-[20px] font-semibold text-slate-900">
                  {activeTab === 'EXPLORE' ? `${activeIndustryLabel} templates` : 'Your saved templates'}
                </h2>
                <p className="mt-1 text-xs text-slate-500">
                  {activeTab === 'EXPLORE'
                    ? 'Pick a prebuilt starting point and turn it into a send-ready WhatsApp template.'
                    : 'Review the templates already in your workspace and submit the next ones when they are ready.'}
                </p>
              </div>

              <div className="text-xs text-slate-500">
                {visibleItems.length} {visibleItems.length === 1 ? 'template' : 'templates'}
              </div>
            </div>

            {showLoadingGrid ? renderLoadingGrid() : null}

            {!showLoadingGrid && activeTab !== 'EXPLORE' && !hasSavedTemplates ? (
              <section className="rounded-[28px] border border-slate-200 bg-white px-6 py-8 shadow-[0_18px_38px_rgba(15,23,42,0.05)]">
                <div className="max-w-2xl">
                  <div className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-400">No saved templates yet</div>
                  <h3 className="mt-3 text-xl font-semibold text-slate-950">Start with a prebuilt template or create your own</h3>
                  <p className="mt-2 text-sm leading-7 text-slate-500">
                    Your saved library is empty right now. Explore the ready-made ecommerce, education, banking, and webinar templates to fill this page faster.
                  </p>
                  <div className="mt-6 flex flex-wrap gap-3">
                    <button
                      type="button"
                      onClick={() => {
                        startTransition(() => setActiveTab('EXPLORE'));
                      }}
                      className="inline-flex min-h-[44px] items-center justify-center rounded-2xl bg-slate-950 px-4 text-sm font-semibold text-white transition hover:bg-slate-800"
                    >
                      Browse presets
                    </button>
                    <button
                      type="button"
                      onClick={() => openCreateComposer()}
                      className="inline-flex min-h-[44px] items-center justify-center rounded-2xl border border-slate-200 px-4 text-sm font-semibold text-slate-700 transition hover:border-slate-300 hover:bg-slate-50"
                    >
                      Create from scratch
                    </button>
                  </div>
                </div>
              </section>
            ) : null}

            {!showLoadingGrid && (activeTab === 'EXPLORE' || hasSavedTemplates) && visibleItems.length === 0 ? (
              <section className="rounded-[28px] border border-slate-200 bg-white px-6 py-8 shadow-[0_18px_38px_rgba(15,23,42,0.05)]">
                <div className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-400">Nothing in this view</div>
                <h3 className="mt-3 text-xl font-semibold text-slate-950">No templates match your current filters</h3>
                <p className="mt-2 text-sm leading-7 text-slate-500">
                  Try another search, switch industries, or clear the filters to see the full library again.
                </p>
                <button
                  type="button"
                  onClick={clearFilters}
                  className="mt-6 inline-flex min-h-[44px] items-center justify-center rounded-2xl border border-slate-200 px-4 text-sm font-semibold text-slate-700 transition hover:border-slate-300 hover:bg-slate-50"
                >
                  Clear filters
                </button>
              </section>
            ) : null}

            {!showLoadingGrid && visibleItems.length > 0 ? (
              <section className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                {visibleItems.map((item) => {
                  const isBusy = item.source === 'saved' && busyTemplateId === item.template.id;
                  const savedAction = getSavedPrimaryAction(item.template, isBusy, busyAction);
                  const statusMeta = item.source === 'saved' ? getStatusMeta(item.template.status) : null;

                  return (
                    <TemplateGalleryCard
                      key={item.id}
                      item={item}
                      topRight={
                        item.source === 'preset' ? (
                          <span className="inline-flex rounded border border-slate-200 bg-slate-50 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-[0.12em] text-slate-500">
                            Prebuilt
                          </span>
                        ) : (
                          <span className={`inline-flex rounded border px-2 py-0.5 text-[11px] font-semibold ${statusMeta?.badge}`}>
                            {statusMeta?.label}
                          </span>
                        )
                      }
                      primaryActionLabel={item.source === 'preset' ? 'Use Template' : savedAction.label}
                      primaryActionDisabled={item.source === 'preset' ? false : savedAction.disabled}
                      onPreview={() => setDetailItem(item)}
                      onPrimaryAction={() => {
                        if (item.source === 'preset') {
                          handleUsePreset(item);
                          return;
                        }

                        if (!savedAction.disabled) {
                          void handleSubmit(item.template);
                        }
                      }}
                    />
                  );
                })}
              </section>
            ) : null}
          </section>
        </div>
      </div>

      <TemplateComposer
        key={`${composerMode}-${composerTemplate?.id || composerDraftValues?.name || 'new'}-${composerOpen ? 'open' : 'closed'}`}
        open={composerOpen}
        mode={composerMode}
        template={composerTemplate}
        draftValues={composerDraftValues}
        isSaving={isSaving}
        onClose={() => {
          setComposerOpen(false);
          setComposerTemplate(null);
          setComposerDraftValues(null);
        }}
        onSave={handleSaveTemplate}
      />

      <TemplateDetailSheet
        open={Boolean(detailItem)}
        template={detailItem?.template || null}
        mode={detailItem?.source === 'preset' ? 'preset' : 'saved'}
        onClose={() => setDetailItem(null)}
        onEdit={() => {
          if (!detailItem) {
            return;
          }

          if (detailItem.source === 'preset') {
            handleUsePreset(detailItem);
            return;
          }

          openEditComposer(detailItem.template);
        }}
        onDuplicate={() => {
          if (!detailItem || detailItem.source === 'preset') {
            return;
          }

          handleDuplicate(detailItem.template);
        }}
        onSubmit={() => {
          if (!detailItem || detailItem.source === 'preset') {
            return;
          }

          void handleSubmit(detailItem.template);
        }}
        onDelete={() => {
          if (!detailItem || detailItem.source === 'preset') {
            return;
          }

          handleDelete(detailItem.template);
        }}
        onUseTemplate={() => {
          if (!detailItem || detailItem.source !== 'preset') {
            return;
          }

          handleUsePreset(detailItem);
        }}
        useTemplateLabel="Use this template"
        isBusy={Boolean(detailItem && detailItem.source === 'saved' && busyTemplateId === detailItem.template.id)}
        busyAction={detailItem && detailItem.source === 'saved' && busyTemplateId === detailItem.template.id ? busyAction : null}
      />
    </div>
  );
};

export default WhatsAppTemplates;
