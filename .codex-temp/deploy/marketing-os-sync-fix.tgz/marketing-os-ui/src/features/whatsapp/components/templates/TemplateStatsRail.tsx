import { Activity, BadgeCheck, Clock3, ShieldX } from 'lucide-react';

interface TemplateStatsRailProps {
  stats: Array<{
    key: string;
    label: string;
    value: number;
    helper: string;
    accent: string;
  }>;
}

const statIcons = {
  total: Activity,
  approved: BadgeCheck,
  pending: Clock3,
  rejected: ShieldX,
} as const;

const statThemes = {
  total: {
    dot: 'bg-slate-900',
    iconWrap: 'border-slate-200 bg-slate-100 text-slate-700',
    accent: 'from-slate-900/12 via-slate-500/6 to-transparent',
  },
  approved: {
    dot: 'bg-emerald-500',
    iconWrap: 'border-emerald-100 bg-emerald-50 text-emerald-700',
    accent: 'from-emerald-500/14 via-emerald-400/6 to-transparent',
  },
  pending: {
    dot: 'bg-amber-500',
    iconWrap: 'border-amber-100 bg-amber-50 text-amber-700',
    accent: 'from-amber-500/14 via-orange-300/6 to-transparent',
  },
  rejected: {
    dot: 'bg-rose-500',
    iconWrap: 'border-rose-100 bg-rose-50 text-rose-700',
    accent: 'from-rose-500/14 via-rose-300/6 to-transparent',
  },
} as const;

export function TemplateStatsRail({ stats }: TemplateStatsRailProps) {
  return (
    <section aria-label="Template stats">
      <div className="-mx-2 overflow-x-auto px-2 pb-1 md:mx-0 md:px-0">
        <div className="flex gap-3 md:grid md:grid-cols-2 xl:grid-cols-4">
          {stats.map((stat) => {
            const Icon = statIcons[stat.key as keyof typeof statIcons] || Activity;
            const theme = statThemes[stat.key as keyof typeof statThemes] || statThemes.total;

            return (
              <article
                key={stat.key}
                className="relative min-w-[220px] overflow-hidden rounded-[24px] border border-slate-200/80 bg-[linear-gradient(180deg,rgba(255,255,255,0.98),rgba(248,250,252,0.95))] p-4 shadow-[0_14px_34px_rgba(15,23,42,0.06)] md:min-w-0"
              >
                <div className={`pointer-events-none absolute inset-x-4 top-0 h-16 bg-gradient-to-b ${theme.accent} blur-2xl`} />

                <div className="relative flex items-start justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.18em] text-slate-400">
                      <span className={`h-2 w-2 rounded-full ${theme.dot}`} />
                      {stat.label}
                    </div>
                    <div className="mt-4 text-[2.15rem] font-semibold tracking-tight text-slate-950">{stat.value}</div>
                  </div>

                  <div className={`flex h-11 w-11 items-center justify-center rounded-2xl border ${theme.iconWrap}`}>
                    <Icon size={17} />
                  </div>
                </div>

                <p className="relative mt-3 max-w-[18ch] text-sm leading-6 text-slate-500">{stat.helper}</p>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
