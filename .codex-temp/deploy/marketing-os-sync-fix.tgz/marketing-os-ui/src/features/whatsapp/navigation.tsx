import type { ReactNode } from 'react';
import {
  BarChartOutlined,
  ContactsOutlined,
  FileTextOutlined,
  MessageOutlined,
  NotificationOutlined,
  ShopOutlined,
} from '@ant-design/icons';

export type WhatsAppSectionKey =
  | 'chats'
  | 'templates'
  | 'broadcast'
  | 'contacts'
  | 'catalog'
  | 'analytics';

export interface WhatsAppSectionNavItem {
  key: WhatsAppSectionKey;
  path: string;
  label: string;
  description: string;
  icon: ReactNode;
  aliases: string[];
}

export const whatsappSectionItems: WhatsAppSectionNavItem[] = [
  {
    key: 'chats',
    path: '/whatsapp/chats',
    label: 'Chats',
    description: 'Conversations and inbox',
    icon: <MessageOutlined />,
    aliases: ['chat', 'chats'],
  },
  {
    key: 'templates',
    path: '/whatsapp/templates',
    label: 'Templates',
    description: 'Approved and draft messages',
    icon: <FileTextOutlined />,
    aliases: ['template', 'templates'],
  },
  {
    key: 'broadcast',
    path: '/whatsapp/broadcast',
    label: 'Broadcast',
    description: 'Campaign sends and audience runs',
    icon: <NotificationOutlined />,
    aliases: ['broadcast', 'broadcasts'],
  },
  {
    key: 'contacts',
    path: '/whatsapp/contacts',
    label: 'Contacts',
    description: 'Saved people and opt-ins',
    icon: <ContactsOutlined />,
    aliases: ['contact', 'contacts'],
  },
  {
    key: 'catalog',
    path: '/whatsapp/catalog',
    label: 'Catalogs',
    description: 'Products and commerce templates',
    icon: <ShopOutlined />,
    aliases: ['catalog', 'catalogs', 'catlog', 'catlogs'],
  },
  {
    key: 'analytics',
    path: '/whatsapp/analytics',
    label: 'Analytics',
    description: 'Performance and delivery metrics',
    icon: <BarChartOutlined />,
    aliases: ['analytic', 'analytics'],
  },
];

export const normalizeWhatsAppSection = (value?: string): WhatsAppSectionKey | null => {
  const candidate = (value || 'chats').trim().toLowerCase();
  const matchedItem = whatsappSectionItems.find((item) => item.aliases.includes(candidate));

  return matchedItem?.key ?? null;
};

export const getWhatsAppSectionByKey = (key: WhatsAppSectionKey) =>
  whatsappSectionItems.find((item) => item.key === key) || whatsappSectionItems[0];
