import React from 'react';
import { Navigate, useParams } from 'react-router-dom';

import WhatsAppChats from '../components/WhatsAppChats';
import WhatsAppTemplates from '../components/WhatsAppTemplates';
import WhatsAppBroadcast from '../components/WhatsAppBroadcast';
import WhatsAppAnalytics from '../components/WhatsAppAnalytics';
import WhatsAppContacts from '../components/WhatsAppContacts';
import WhatsAppCatalog from '../components/WhatsAppCatalog';
import {
  getWhatsAppSectionByKey,
  normalizeWhatsAppSection,
  type WhatsAppSectionKey,
} from '../navigation';

const whatsappSections: Record<WhatsAppSectionKey, React.ReactNode> = {
  chats: <WhatsAppChats />,
  templates: <WhatsAppTemplates />,
  broadcast: <WhatsAppBroadcast />,
  analytics: <WhatsAppAnalytics />,
  contacts: <WhatsAppContacts />,
  catalog: <WhatsAppCatalog />,
};

const WhatsAppDashboard: React.FC = () => {
  const { section = 'chats' } = useParams<{ section: string }>();
  const normalizedSection = normalizeWhatsAppSection(section);

  if (!normalizedSection) {
    return <Navigate to="/whatsapp/chats" replace />;
  }

  const activeItem = getWhatsAppSectionByKey(normalizedSection);

  if (section !== normalizedSection) {
    return <Navigate to={activeItem.path} replace />;
  }

  const activeSection = whatsappSections[normalizedSection];

  return (
    <div className="w-full h-full">
      <section className="min-w-0 h-full">
        {activeSection}
      </section>
    </div>
  );
};

export default WhatsAppDashboard;
