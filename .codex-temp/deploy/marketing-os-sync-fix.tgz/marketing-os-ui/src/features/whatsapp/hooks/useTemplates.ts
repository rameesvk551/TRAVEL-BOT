import { useState } from 'react';
import { Modal, message } from 'antd';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';

import { templateService } from '../services/templateService';
import {
  buildTemplateComponents,
  extractVariables,
  normalizeTemplate,
  type NormalizedTemplate,
  type TemplateDraftValues,
} from '../components/templates/templateUtils';

type TemplateBusyAction = 'submit' | 'delete' | 'update' | null;

const getMutationErrorMessage = (error: unknown, fallbackMessage: string) => {
  if (
    typeof error === 'object' &&
    error !== null &&
    'response' in error &&
    typeof error.response === 'object' &&
    error.response !== null &&
    'data' in error.response &&
    typeof error.response.data === 'object' &&
    error.response.data !== null &&
    'error' in error.response &&
    typeof error.response.error === 'string'
  ) {
    return error.response.error;
  }

  if (
    typeof error === 'object' &&
    error !== null &&
    'response' in error &&
    typeof error.response === 'object' &&
    error.response !== null &&
    'data' in error.response &&
    typeof error.response.data === 'object' &&
    error.response.data !== null &&
    'error' in error.response.data &&
    typeof error.response.data.error === 'string'
  ) {
    return error.response.data.error;
  }

  return fallbackMessage;
};

export function useTemplates() {
  const queryClient = useQueryClient();
  const [busyTemplateId, setBusyTemplateId] = useState<string | null>(null);
  const [busyAction, setBusyAction] = useState<TemplateBusyAction>(null);

  const { data, isLoading, isFetching } = useQuery({
    queryKey: ['whatsapp-templates'],
    queryFn: () => templateService.getTemplates(),
  });

  const templates = Array.isArray(data?.data)
    ? (data.data as Array<Record<string, unknown>>).map(normalizeTemplate)
    : [];

  const createTemplateMutation = useMutation({
    mutationFn: (values: TemplateDraftValues) =>
      templateService.createTemplate({
        name: values.name,
        category: values.category,
        language: values.language,
        components: buildTemplateComponents(values),
        variables: extractVariables(values.body),
        status: 'DRAFT',
      }),
    onSuccess: (response) => {
      if (response?.warning || response?.data?.warning) {
        message.warning(response?.warning || response?.data?.warning);
      } else {
        message.success('Template saved successfully');
      }

      queryClient.invalidateQueries({ queryKey: ['whatsapp-templates'] });
    },
    onError: () => {
      message.error('Unable to save this template');
    },
  });

  const updateTemplateMutation = useMutation({
    mutationFn: ({ id, values }: { id: string; values: TemplateDraftValues }) =>
      templateService.updateTemplate(id, {
        components: buildTemplateComponents(values),
        variables: extractVariables(values.body),
      }),
    onSuccess: () => {
      message.success('Template updated');
      queryClient.invalidateQueries({ queryKey: ['whatsapp-templates'] });
    },
    onError: () => {
      message.error('Unable to update this template');
    },
    onSettled: () => {
      setBusyTemplateId(null);
      setBusyAction(null);
    },
  });

  const submitTemplateMutation = useMutation({
    mutationFn: (id: string) => templateService.submitTemplate(id),
    onSuccess: () => {
      message.success('Template submitted for approval');
      queryClient.invalidateQueries({ queryKey: ['whatsapp-templates'] });
    },
    onError: (error: unknown) => {
      message.error(getMutationErrorMessage(error, 'Unable to submit this template'));
    },
    onSettled: () => {
      setBusyTemplateId(null);
      setBusyAction(null);
    },
  });

  const deleteTemplateMutation = useMutation({
    mutationFn: (id: string) => templateService.deleteTemplate(id),
    onSuccess: () => {
      message.success('Template deleted');
      queryClient.invalidateQueries({ queryKey: ['whatsapp-templates'] });
    },
    onError: () => {
      message.error('Unable to delete this template');
    },
    onSettled: () => {
      setBusyTemplateId(null);
      setBusyAction(null);
    },
  });

  const syncTemplatesMutation = useMutation({
    mutationFn: () => templateService.syncTemplates(),
    onSuccess: (response) => {
      const syncedCount = Array.isArray(response?.data) ? response.data.length : response?.total || 0;
      message.success(`Synced ${syncedCount} templates from Meta`);
      queryClient.invalidateQueries({ queryKey: ['whatsapp-templates'] });
    },
    onError: (error: unknown) => {
      message.error(getMutationErrorMessage(error, 'Unable to sync templates'));
    },
  });

  const createTemplate = async (values: TemplateDraftValues) => {
    await createTemplateMutation.mutateAsync(values);
  };

  const updateTemplate = async (id: string, values: TemplateDraftValues) => {
    setBusyTemplateId(id);
    setBusyAction('update');
    await updateTemplateMutation.mutateAsync({ id, values });
  };

  const submitTemplate = async (template: NormalizedTemplate) => {
    setBusyTemplateId(template.id);
    setBusyAction('submit');
    await submitTemplateMutation.mutateAsync(template.id);
  };

  const requestDeleteTemplate = (template: NormalizedTemplate) => {
    Modal.confirm({
      title: `Delete ${template.name}?`,
      content:
        template.status === 'APPROVED'
          ? 'Approved templates are preserved as drafts after deletion so you can safely rebuild them later.'
          : 'This action removes the template and cannot be undone.',
      okText: 'Delete',
      okButtonProps: { danger: true },
      centered: true,
      onOk: async () => {
        setBusyTemplateId(template.id);
        setBusyAction('delete');
        await deleteTemplateMutation.mutateAsync(template.id);
      },
    });
  };

  return {
    templates,
    isLoading,
    isRefreshing: isFetching,
    busyTemplateId,
    busyAction,
    isSaving: createTemplateMutation.isPending || updateTemplateMutation.isPending,
    isSyncing: syncTemplatesMutation.isPending,
    createTemplate,
    updateTemplate,
    submitTemplate,
    requestDeleteTemplate,
    syncTemplates: syncTemplatesMutation.mutateAsync,
  };
}
