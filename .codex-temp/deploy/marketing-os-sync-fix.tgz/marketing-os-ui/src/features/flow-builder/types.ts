import type { Node, Edge } from '@xyflow/react';

// ─── Node data payloads ───

export interface TriggerData {
  label: string;
  triggerType: 'keyword' | 'webhook' | 'new_lead' | 'attribute_change';
  keywords?: string[];
  webhookUrl?: string;
}

export interface ButtonItem {
  id: string;
  text: string;
  type: 'quick_reply' | 'url' | 'phone';
  value?: string;
}

export interface ListItem {
  id: string;
  title: string;
  description?: string;
}

export interface MessageData {
  label: string;
  messageType: 'text' | 'image' | 'video' | 'buttons' | 'list';
  headerText?: string;
  bodyText: string;
  footerText?: string;
  mediaUrl?: string;
  buttons?: ButtonItem[];
  listItems?: ListItem[];
}

export interface ConditionBranch {
  id: string;
  label: string;
  condition: string;
}

export interface ConditionData {
  label: string;
  variable: string;
  operator: 'equals' | 'contains' | 'greater_than' | 'less_than' | 'exists';
  value: string;
  branches: ConditionBranch[];
}

export interface DelayData {
  label: string;
  delayType: 'fixed' | 'until';
  duration?: number;
  unit?: 'seconds' | 'minutes' | 'hours' | 'days';
  untilTime?: string;
}

export interface ActionData {
  label: string;
  actionType: 'api_call' | 'google_sheets' | 'crm_sync' | 'webhook';
  url?: string;
  method?: 'GET' | 'POST' | 'PUT' | 'DELETE';
  headers?: Record<string, string>;
  body?: string;
}

export interface TemplateData {
  label: string;
  templateName: string;
  language: string;
  variables: Record<string, string>;
}

export interface DynamicCatalogData {
  label: string;
  dataSource: 'categories' | 'products' | 'featured';
  headerText?: string;
  bodyText: string;
  footerText?: string;
}

export interface AddToCartData {
  label: string;
}

export interface CreateOrderData {
  label: string;
  paymentMethod?: 'cod' | 'online';
}

// ─── Unified node data ───

export type FlowNodeType = 'trigger' | 'message' | 'condition' | 'delay' | 'action' | 'template' | 'dynamic_catalog' | 'add_to_cart' | 'create_order';

export interface BaseNodeData extends Record<string, unknown> {
  nodeType: FlowNodeType;
}

export type FlowNodeData =
  | (BaseNodeData & TriggerData & { nodeType: 'trigger' })
  | (BaseNodeData & MessageData & { nodeType: 'message' })
  | (BaseNodeData & ConditionData & { nodeType: 'condition' })
  | (BaseNodeData & DelayData & { nodeType: 'delay' })
  | (BaseNodeData & ActionData & { nodeType: 'action' })
  | (BaseNodeData & TemplateData & { nodeType: 'template' })
  | (BaseNodeData & DynamicCatalogData & { nodeType: 'dynamic_catalog' })
  | (BaseNodeData & AddToCartData & { nodeType: 'add_to_cart' })
  | (BaseNodeData & CreateOrderData & { nodeType: 'create_order' });

export type FlowNode = Node<FlowNodeData, FlowNodeType>;
export type FlowEdge = Edge;

// ─── Preview types ───

export interface PreviewMessage {
  id: string;
  type: 'sent' | 'received' | 'typing';
  content?: string;
  headerText?: string;
  footerText?: string;
  mediaUrl?: string;
  mediaType?: 'image' | 'video';
  buttons?: ButtonItem[];
  listItems?: ListItem[];
  delay?: number;
  nodeId?: string;
}

// ─── Flow JSON export ───

export interface FlowJSON {
  id?: string;
  name: string;
  trigger: {
    type: string;
    config: Record<string, unknown>;
  };
  steps: FlowStep[];
}

export interface FlowStep {
  id: string;
  type: FlowNodeType;
  data: Record<string, unknown>;
  next?: string | Record<string, string>;
}

// ─── Palette items ───

export interface PaletteItem {
  type: FlowNodeType;
  label: string;
  icon: string;
  description: string;
  category: 'messages' | 'actions';
}

export const PALETTE_ITEMS: PaletteItem[] = [
  { type: 'trigger', label: 'Trigger', icon: '⚡', description: 'Start the flow', category: 'actions' },
  { type: 'message', label: 'Send Message', icon: '💬', description: 'Text, media, buttons', category: 'messages' },
  { type: 'condition', label: 'Condition', icon: '🔀', description: 'If / else branching', category: 'actions' },
  { type: 'delay', label: 'Delay', icon: '⏱️', description: 'Wait before next step', category: 'actions' },
  { type: 'action', label: 'Action', icon: '🔗', description: 'API call, webhook', category: 'actions' },
  { type: 'template', label: 'Template', icon: '📋', description: 'WhatsApp template', category: 'messages' },
  { type: 'dynamic_catalog', label: 'Dynamic Catalog', icon: '📂', description: 'Fetch from DB', category: 'messages' },
  { type: 'add_to_cart', label: 'Add to Cart', icon: '🛒', description: 'Update cart', category: 'actions' },
  { type: 'create_order', label: 'Create Order', icon: '📋', description: 'Finalize order', category: 'actions' },
];
