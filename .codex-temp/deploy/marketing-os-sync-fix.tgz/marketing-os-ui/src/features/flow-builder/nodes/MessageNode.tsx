import { memo } from 'react';
import { Handle, Position, type NodeProps } from '@xyflow/react';
import type { FlowNodeData, MessageData } from '../types';
import { useFlowStore } from '../store/useFlowStore';

function MessageNodeComponent({ id, data, selected }: NodeProps) {
  const d = data as FlowNodeData & MessageData & { nodeType: 'message' };
  const selectNode = useFlowStore((s) => s.selectNode);
  const deleteNode = useFlowStore((s) => s.deleteNode);

  return (
    <div
      onClick={() => selectNode(id)}
      className={`group relative min-w-[220px] max-w-[300px] rounded-2xl bg-white border-2 transition-all duration-200 cursor-pointer
        ${selected ? 'border-[#25D366] shadow-lg shadow-green-100' : 'border-gray-200 shadow-md hover:shadow-lg hover:border-[#25D366]/50'}`}
    >
      {/* Delete */}
      <button
        onClick={(e) => { e.stopPropagation(); deleteNode(id); }}
        className="absolute -top-2 -right-2 w-6 h-6 bg-gray-400 hover:bg-red-500 text-white rounded-full text-xs flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity z-10"
      >
        ×
      </button>

      <Handle type="target" position={Position.Left} className="!w-3 !h-3 !bg-[#25D366] !border-2 !border-white" />

      {/* Header */}
      <div className="bg-white rounded-t-xl px-4 py-2.5 flex items-center gap-2 border-b border-gray-100">
        <div className="w-7 h-7 rounded-lg bg-[#25D366]/10 flex items-center justify-center">
          <span className="text-sm">💬</span>
        </div>
        <span className="font-semibold text-sm text-gray-800">{d.label || 'Message'}</span>
      </div>

      {/* Body */}
      <div className="p-4 space-y-2">
        {d.headerText && (
          <div className="text-xs font-semibold text-gray-700 truncate">{d.headerText}</div>
        )}

        {d.mediaUrl && (
          <div className="w-full h-24 bg-gray-100 rounded-lg flex items-center justify-center text-gray-400 text-xs">
            {d.messageType === 'image' ? '🖼️ Image' : '🎥 Video'}
          </div>
        )}

        <p className="text-sm text-gray-600 line-clamp-3 whitespace-pre-wrap">
          {d.bodyText || 'Type your message...'}
        </p>

        {d.footerText && (
          <p className="text-[11px] text-gray-400">{d.footerText}</p>
        )}

        {/* Buttons */}
        {d.buttons && d.buttons.length > 0 && (
          <div className="space-y-1.5 pt-2 border-t border-gray-100">
            {d.buttons.map((btn) => (
              <div
                key={btn.id}
                className="flex items-center gap-2 bg-[#25D366]/5 border border-[#25D366]/20 rounded-lg px-3 py-1.5"
              >
                <span className="text-[#25D366] text-xs">×</span>
                <span className="text-sm text-[#25D366] font-medium flex-1 text-center">{btn.text}</span>
                <Handle
                  type="source"
                  position={Position.Right}
                  id={`btn-${btn.id}`}
                  className="!relative !transform-none !top-auto !right-auto !w-2.5 !h-2.5 !bg-[#25D366] !border-2 !border-white"
                />
              </div>
            ))}
          </div>
        )}

        {/* List items */}
        {d.listItems && d.listItems.length > 0 && (
          <div className="space-y-1 pt-2 border-t border-gray-100">
            {d.listItems.map((item) => (
              <div key={item.id} className="bg-gray-50 rounded-lg px-3 py-1.5">
                <div className="text-sm font-medium text-gray-700">{item.title}</div>
                {item.description && <div className="text-xs text-gray-400">{item.description}</div>}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Default source handle (only if no button handles) */}
      {(!d.buttons || d.buttons.length === 0) && (
        <Handle type="source" position={Position.Right} className="!w-3 !h-3 !bg-[#25D366] !border-2 !border-white" />
      )}
    </div>
  );
}

export const MessageNode = memo(MessageNodeComponent);
