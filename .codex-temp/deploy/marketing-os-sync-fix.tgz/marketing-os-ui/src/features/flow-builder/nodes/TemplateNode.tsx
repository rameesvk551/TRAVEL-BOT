import { memo } from 'react';
import { Handle, Position, type NodeProps } from '@xyflow/react';
import type { FlowNodeData, TemplateData } from '../types';
import { useFlowStore } from '../store/useFlowStore';

function TemplateNodeComponent({ id, data, selected }: NodeProps) {
  const d = data as FlowNodeData & TemplateData & { nodeType: 'template' };
  const selectNode = useFlowStore((s) => s.selectNode);
  const deleteNode = useFlowStore((s) => s.deleteNode);

  return (
    <div
      onClick={() => selectNode(id)}
      className={`group relative min-w-[200px] max-w-[260px] rounded-2xl bg-white border-2 transition-all duration-200 cursor-pointer
        ${selected ? 'border-teal-400 shadow-lg shadow-teal-50' : 'border-gray-200 shadow-md hover:shadow-lg hover:border-teal-300'}`}
    >
      <button
        onClick={(e) => { e.stopPropagation(); deleteNode(id); }}
        className="absolute -top-2 -right-2 w-6 h-6 bg-gray-400 hover:bg-red-500 text-white rounded-full text-xs flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity z-10"
      >
        ×
      </button>

      <Handle type="target" position={Position.Left} className="!w-3 !h-3 !bg-teal-400 !border-2 !border-white" />

      <div className="bg-teal-50 rounded-t-xl px-4 py-2.5 flex items-center gap-2 border-b border-teal-100">
        <div className="w-7 h-7 rounded-lg bg-teal-400/20 flex items-center justify-center">
          <span className="text-sm">📋</span>
        </div>
        <span className="font-semibold text-sm text-gray-800">{d.label || 'Template'}</span>
      </div>

      <div className="p-4 space-y-2">
        <div className="text-sm font-medium text-gray-700">
          {d.templateName || 'Select template...'}
        </div>
        <div className="text-xs text-gray-400">Language: {d.language || 'en'}</div>
        {Object.keys(d.variables || {}).length > 0 && (
          <div className="text-xs text-gray-400">
            {Object.keys(d.variables).length} variable(s)
          </div>
        )}
      </div>

      <Handle type="source" position={Position.Right} className="!w-3 !h-3 !bg-teal-400 !border-2 !border-white" />
    </div>
  );
}

export const TemplateNode = memo(TemplateNodeComponent);
