import { memo } from 'react';
import { Handle, Position, type NodeProps } from '@xyflow/react';
import type { FlowNodeData, DelayData } from '../types';
import { useFlowStore } from '../store/useFlowStore';

function DelayNodeComponent({ id, data, selected }: NodeProps) {
  const d = data as FlowNodeData & DelayData & { nodeType: 'delay' };
  const selectNode = useFlowStore((s) => s.selectNode);
  const deleteNode = useFlowStore((s) => s.deleteNode);

  return (
    <div
      onClick={() => selectNode(id)}
      className={`group relative min-w-[180px] max-w-[240px] rounded-2xl bg-white border-2 transition-all duration-200 cursor-pointer
        ${selected ? 'border-blue-400 shadow-lg shadow-blue-50' : 'border-gray-200 shadow-md hover:shadow-lg hover:border-blue-300'}`}
    >
      <button
        onClick={(e) => { e.stopPropagation(); deleteNode(id); }}
        className="absolute -top-2 -right-2 w-6 h-6 bg-gray-400 hover:bg-red-500 text-white rounded-full text-xs flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity z-10"
      >
        ×
      </button>

      <Handle type="target" position={Position.Left} className="!w-3 !h-3 !bg-blue-400 !border-2 !border-white" />

      <div className="bg-blue-50 rounded-t-xl px-4 py-2.5 flex items-center gap-2 border-b border-blue-100">
        <div className="w-7 h-7 rounded-lg bg-blue-400/20 flex items-center justify-center">
          <span className="text-sm">⏱️</span>
        </div>
        <span className="font-semibold text-sm text-gray-800">{d.label || 'Wait'}</span>
      </div>

      <div className="p-4">
        {d.delayType === 'fixed' ? (
          <div className="text-center">
            <span className="text-2xl font-bold text-blue-500">{d.duration || 0}</span>
            <span className="text-sm text-gray-500 ml-1">{d.unit || 'seconds'}</span>
          </div>
        ) : (
          <div className="text-sm text-gray-500 text-center">
            Until: {d.untilTime || 'Not set'}
          </div>
        )}
      </div>

      <Handle type="source" position={Position.Right} className="!w-3 !h-3 !bg-blue-400 !border-2 !border-white" />
    </div>
  );
}

export const DelayNode = memo(DelayNodeComponent);
