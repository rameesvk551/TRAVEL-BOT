import { memo } from 'react';
import { Handle, Position, type NodeProps } from '@xyflow/react';
import type { FlowNodeData, ConditionData } from '../types';
import { useFlowStore } from '../store/useFlowStore';

function ConditionNodeComponent({ id, data, selected }: NodeProps) {
  const d = data as FlowNodeData & ConditionData & { nodeType: 'condition' };
  const selectNode = useFlowStore((s) => s.selectNode);
  const deleteNode = useFlowStore((s) => s.deleteNode);

  return (
    <div
      onClick={() => selectNode(id)}
      className={`group relative min-w-[200px] max-w-[260px] rounded-2xl bg-white border-2 transition-all duration-200 cursor-pointer
        ${selected ? 'border-amber-400 shadow-lg shadow-amber-50' : 'border-gray-200 shadow-md hover:shadow-lg hover:border-amber-300'}`}
    >
      <button
        onClick={(e) => { e.stopPropagation(); deleteNode(id); }}
        className="absolute -top-2 -right-2 w-6 h-6 bg-gray-400 hover:bg-red-500 text-white rounded-full text-xs flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity z-10"
      >
        ×
      </button>

      <Handle type="target" position={Position.Left} className="!w-3 !h-3 !bg-amber-400 !border-2 !border-white" />

      <div className="bg-amber-50 rounded-t-xl px-4 py-2.5 flex items-center gap-2 border-b border-amber-100">
        <div className="w-7 h-7 rounded-lg bg-amber-400/20 flex items-center justify-center">
          <span className="text-sm">🔀</span>
        </div>
        <span className="font-semibold text-sm text-gray-800">{d.label || 'Condition'}</span>
      </div>

      <div className="p-4 space-y-2">
        <div className="text-xs text-gray-500">
          If <span className="font-mono bg-gray-100 px-1 rounded">{d.variable || '{{var}}'}</span> {d.operator} <span className="font-mono bg-gray-100 px-1 rounded">{d.value || '...'}</span>
        </div>

        <div className="space-y-1.5 pt-2 border-t border-gray-100">
          {(d.branches || []).map((branch) => (
            <div key={branch.id} className="flex items-center gap-2">
              <div className={`flex-1 text-center py-1.5 rounded-lg text-sm font-medium ${
                branch.id === 'yes' ? 'bg-green-50 text-green-600 border border-green-200' : 'bg-red-50 text-red-500 border border-red-200'
              }`}>
                {branch.label}
              </div>
              <Handle
                type="source"
                position={Position.Right}
                id={`branch-${branch.id}`}
                className={`!relative !transform-none !top-auto !right-auto !w-2.5 !h-2.5 !border-2 !border-white ${
                  branch.id === 'yes' ? '!bg-green-500' : '!bg-red-400'
                }`}
              />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export const ConditionNode = memo(ConditionNodeComponent);
