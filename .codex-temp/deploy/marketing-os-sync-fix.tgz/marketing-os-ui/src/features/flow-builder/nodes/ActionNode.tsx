import { memo } from 'react';
import { Handle, Position, type NodeProps } from '@xyflow/react';
import type { FlowNodeData, ActionData } from '../types';
import { useFlowStore } from '../store/useFlowStore';

function ActionNodeComponent({ id, data, selected }: NodeProps) {
  const d = data as FlowNodeData & ActionData & { nodeType: 'action' };
  const selectNode = useFlowStore((s) => s.selectNode);
  const deleteNode = useFlowStore((s) => s.deleteNode);

  const actionLabels: Record<string, string> = {
    api_call: '🌐 API Call',
    google_sheets: '📊 Google Sheets',
    crm_sync: '👥 CRM Sync',
    webhook: '🔗 Webhook',
  };

  return (
    <div
      onClick={() => selectNode(id)}
      className={`group relative min-w-[200px] max-w-[260px] rounded-2xl bg-white border-2 transition-all duration-200 cursor-pointer
        ${selected ? 'border-purple-400 shadow-lg shadow-purple-50' : 'border-gray-200 shadow-md hover:shadow-lg hover:border-purple-300'}`}
    >
      <button
        onClick={(e) => { e.stopPropagation(); deleteNode(id); }}
        className="absolute -top-2 -right-2 w-6 h-6 bg-gray-400 hover:bg-red-500 text-white rounded-full text-xs flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity z-10"
      >
        ×
      </button>

      <Handle type="target" position={Position.Left} className="!w-3 !h-3 !bg-purple-400 !border-2 !border-white" />

      <div className="bg-purple-50 rounded-t-xl px-4 py-2.5 flex items-center gap-2 border-b border-purple-100">
        <div className="w-7 h-7 rounded-lg bg-purple-400/20 flex items-center justify-center">
          <span className="text-sm">🔗</span>
        </div>
        <span className="font-semibold text-sm text-gray-800">{d.label || 'Action'}</span>
      </div>

      <div className="p-4 space-y-2">
        <div className="inline-flex items-center gap-1 bg-purple-50 px-2 py-1 rounded-md">
          <span className="text-xs font-medium text-purple-600">{actionLabels[d.actionType] || d.actionType}</span>
        </div>
        {d.url && (
          <div className="text-xs text-gray-400 truncate font-mono">{d.method} {d.url}</div>
        )}
        {!d.url && (
          <div className="text-xs text-gray-400">Not configured</div>
        )}
      </div>

      <Handle type="source" position={Position.Right} className="!w-3 !h-3 !bg-purple-400 !border-2 !border-white" />
    </div>
  );
}

export const ActionNode = memo(ActionNodeComponent);
