import { memo } from 'react';
import { Handle, Position, type NodeProps } from '@xyflow/react';
import { useFlowStore } from '../store/useFlowStore';

function AddToCartNodeComponent({ id, data, selected }: NodeProps) {
  const d = data as any;
  const selectNode = useFlowStore((s) => s.selectNode);
  const deleteNode = useFlowStore((s) => s.deleteNode);

  return (
    <div
      onClick={() => selectNode(id)}
      className={`group relative min-w-[200px] max-w-[260px] rounded-2xl bg-white border-2 transition-all duration-200 cursor-pointer
        ${selected ? 'border-orange-400 shadow-lg shadow-orange-50' : 'border-gray-200 shadow-md hover:shadow-lg hover:border-orange-300'}`}
    >
      <button
        onClick={(e) => { e.stopPropagation(); deleteNode(id); }}
        className="absolute -top-2 -right-2 w-6 h-6 bg-gray-400 hover:bg-red-500 text-white rounded-full text-xs flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity z-10"
      >
        ×
      </button>

      <Handle type="target" position={Position.Left} className="!w-3 !h-3 !bg-orange-400 !border-2 !border-white" />

      <div className="bg-orange-50 rounded-t-xl px-4 py-2.5 flex items-center gap-2 border-b border-orange-100">
        <div className="w-7 h-7 rounded-lg bg-orange-400/20 flex items-center justify-center">
          <span className="text-sm">🛒</span>
        </div>
        <span className="font-semibold text-sm text-gray-800">{d.label || 'Add to Cart'}</span>
      </div>

      <div className="p-4 space-y-1">
        <div className="text-xs text-gray-500">Adds the selected product to the customer&apos;s cart</div>
        <div className="text-xs text-orange-500 font-medium">Auto: uses selected_product variable</div>
      </div>

      <Handle type="source" position={Position.Right} className="!w-3 !h-3 !bg-orange-400 !border-2 !border-white" />
    </div>
  );
}

export const AddToCartNode = memo(AddToCartNodeComponent);
