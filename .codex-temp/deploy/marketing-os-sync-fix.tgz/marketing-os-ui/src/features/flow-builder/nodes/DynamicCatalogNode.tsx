import { memo } from 'react';
import { Handle, Position, type NodeProps } from '@xyflow/react';
import { useFlowStore } from '../store/useFlowStore';

function DynamicCatalogNodeComponent({ id, data, selected }: NodeProps) {
  const d = data as any;
  const selectNode = useFlowStore((s) => s.selectNode);
  const deleteNode = useFlowStore((s) => s.deleteNode);

  const sourceLabels: Record<string, { icon: string; label: string; color: string }> = {
    categories: { icon: '📂', label: 'Categories', color: 'cyan' },
    products: { icon: '📦', label: 'Products', color: 'blue' },
    featured: { icon: '⭐', label: 'Featured', color: 'amber' },
  };

  const info = sourceLabels[d.dataSource] || sourceLabels.categories;

  return (
    <div
      onClick={() => selectNode(id)}
      className={`group relative min-w-[200px] max-w-[260px] rounded-2xl bg-white border-2 transition-all duration-200 cursor-pointer
        ${selected ? 'border-cyan-400 shadow-lg shadow-cyan-50' : 'border-gray-200 shadow-md hover:shadow-lg hover:border-cyan-300'}`}
    >
      <button
        onClick={(e) => { e.stopPropagation(); deleteNode(id); }}
        className="absolute -top-2 -right-2 w-6 h-6 bg-gray-400 hover:bg-red-500 text-white rounded-full text-xs flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity z-10"
      >
        ×
      </button>

      <Handle type="target" position={Position.Left} className="!w-3 !h-3 !bg-cyan-400 !border-2 !border-white" />

      <div className="bg-cyan-50 rounded-t-xl px-4 py-2.5 flex items-center gap-2 border-b border-cyan-100">
        <div className="w-7 h-7 rounded-lg bg-cyan-400/20 flex items-center justify-center">
          <span className="text-sm">{info.icon}</span>
        </div>
        <span className="font-semibold text-sm text-gray-800">{d.label || 'Dynamic Catalog'}</span>
      </div>

      <div className="p-4 space-y-2">
        <div className="inline-flex items-center gap-1 bg-cyan-50 px-2 py-1 rounded-md">
          <span className="text-xs font-medium text-cyan-600">📡 DB → {info.label}</span>
        </div>
        <div className="text-xs text-gray-400">Fetches from tenant database at runtime</div>
      </div>

      <Handle type="source" position={Position.Right} className="!w-3 !h-3 !bg-cyan-400 !border-2 !border-white" />
    </div>
  );
}

export const DynamicCatalogNode = memo(DynamicCatalogNodeComponent);
