import { memo } from 'react';
import { Handle, Position, type NodeProps } from '@xyflow/react';
import type { FlowNodeData, TriggerData } from '../types';
import { useFlowStore } from '../store/useFlowStore';

function TriggerNodeComponent({ id, data, selected }: NodeProps) {
  const d = data as FlowNodeData & TriggerData & { nodeType: 'trigger' };
  const selectNode = useFlowStore((s) => s.selectNode);
  const deleteNode = useFlowStore((s) => s.deleteNode);

  return (
    <div
      onClick={() => selectNode(id)}
      className={`group relative min-w-[220px] max-w-[280px] rounded-2xl bg-white border-2 transition-all duration-200 cursor-pointer
        ${selected ? 'border-[#25D366] shadow-lg shadow-green-100' : 'border-gray-200 shadow-md hover:shadow-lg hover:border-[#25D366]/50'}`}
    >
      {/* Delete button */}
      <button
        onClick={(e) => { e.stopPropagation(); deleteNode(id); }}
        className="absolute -top-2 -right-2 w-6 h-6 bg-gray-400 hover:bg-red-500 text-white rounded-full text-xs flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity z-10"
      >
        ×
      </button>

      {/* Green accent bar */}
      <div className="bg-[#25D366] rounded-t-xl px-4 py-2 flex items-center gap-2">
        <span className="text-white text-lg">⚡</span>
        <span className="text-white font-semibold text-sm">{d.label || 'Flow Start'}</span>
      </div>

      {/* Content */}
      <div className="p-4">
        <div className="text-xs text-gray-500 mb-2">Trigger: {d.triggerType}</div>
        {d.triggerType === 'keyword' && d.keywords && d.keywords.length > 0 && (
          <div className="space-y-1">
            <div className="text-xs text-gray-400">Keywords:</div>
            {d.keywords.map((kw, i) => (
              <div key={i} className="bg-gray-50 border border-gray-200 rounded-lg px-3 py-1.5 text-sm text-gray-700">
                {kw}
              </div>
            ))}
          </div>
        )}
        {d.triggerType === 'webhook' && (
          <div className="text-xs text-gray-400">Webhook URL configured</div>
        )}
      </div>

      <Handle type="source" position={Position.Right} className="!w-3 !h-3 !bg-[#25D366] !border-2 !border-white" />
    </div>
  );
}

export const TriggerNode = memo(TriggerNodeComponent);
