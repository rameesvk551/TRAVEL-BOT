export { TriggerNode } from './TriggerNode';
export { MessageNode } from './MessageNode';
export { ConditionNode } from './ConditionNode';
export { DelayNode } from './DelayNode';
export { ActionNode } from './ActionNode';
export { TemplateNode } from './TemplateNode';
export { DynamicCatalogNode } from './DynamicCatalogNode';
export { AddToCartNode } from './AddToCartNode';
export { CreateOrderNode } from './CreateOrderNode';

import { TriggerNode } from './TriggerNode';
import { MessageNode } from './MessageNode';
import { ConditionNode } from './ConditionNode';
import { DelayNode } from './DelayNode';
import { ActionNode } from './ActionNode';
import { TemplateNode } from './TemplateNode';
import { DynamicCatalogNode } from './DynamicCatalogNode';
import { AddToCartNode } from './AddToCartNode';
import { CreateOrderNode } from './CreateOrderNode';

export const nodeTypes = {
  trigger: TriggerNode,
  message: MessageNode,
  condition: ConditionNode,
  delay: DelayNode,
  action: ActionNode,
  template: TemplateNode,
  dynamic_catalog: DynamicCatalogNode,
  add_to_cart: AddToCartNode,
  create_order: CreateOrderNode,
};
