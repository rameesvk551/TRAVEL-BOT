import apiClient from '../../../api/client';

export interface FlowDTO {
  _id: string;
  name: string;
  tenantId: string;
  status: 'draft' | 'active' | 'inactive';
  triggerType?: 'keyword' | 'webhook' | 'new_lead' | 'attribute_change';
  nodes?: any[];
  edges?: any[];
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export const flowApi = {
  getFlows: async () => {
    const res = await apiClient.get('/flows');
    // Assuming the response is formatted { success: true, data: [...] }
    return res.data.data as FlowDTO[];
  },
  createFlow: async (data: Partial<FlowDTO>) => {
    const res = await apiClient.post('/flows', data);
    return res.data.data as FlowDTO;
  },
  getFlowById: async (id: string) => {
    const res = await apiClient.get(`/flows/${id}`);
    return res.data.data as FlowDTO;
  },
  updateFlow: async (id: string, data: Partial<FlowDTO>) => {
    const res = await apiClient.put(`/flows/${id}`, data);
    return res.data.data as FlowDTO;
  },
  updateFlowStatus: async (id: string, status: FlowDTO['status']) => {
    const res = await apiClient.put(`/flows/${id}/status`, { status });
    return res.data.data as FlowDTO;
  },
  deleteFlow: async (id: string) => {
    const res = await apiClient.delete(`/flows/${id}`);
    return res.data;
  }
};
