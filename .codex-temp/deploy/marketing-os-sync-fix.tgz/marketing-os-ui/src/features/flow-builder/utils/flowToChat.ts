import type { FlowNode, FlowEdge, PreviewMessage, FlowNodeData } from '../types';

/**
 * Walk the node graph from the trigger node(s) downstream,
 * producing a linear chat sequence for the WhatsApp phone preview.
 */
export function flowToChat(nodes: FlowNode[], edges: FlowEdge[]): PreviewMessage[] {
  if (nodes.length === 0) return [];

  // Find the trigger node (start)
  const triggerNode = nodes.find((n) => (n.data as FlowNodeData).nodeType === 'trigger');
  if (!triggerNode) {
    // If no trigger, just convert all message nodes linearly
    return nodes
      .filter((n) => (n.data as FlowNodeData).nodeType === 'message')
      .map((n) => nodeToMessage(n));
  }

  // BFS from trigger
  const visited = new Set<string>();
  const queue: string[] = [triggerNode.id];
  const messages: PreviewMessage[] = [];

  // Build adjacency from edges
  const adj = new Map<string, string[]>();
  for (const edge of edges) {
    if (!adj.has(edge.source)) adj.set(edge.source, []);
    adj.get(edge.source)!.push(edge.target);
  }

  while (queue.length > 0) {
    const id = queue.shift()!;
    if (visited.has(id)) continue;
    visited.add(id);

    const node = nodes.find((n) => n.id === id);
    if (!node) continue;

    const data = node.data as FlowNodeData;

    if (data.nodeType === 'trigger') {
      // Add a "user" message for the keyword trigger
      if (data.triggerType === 'keyword' && data.keywords?.length) {
        messages.push({
          id: `${node.id}-trigger`,
          type: 'sent',
          content: data.keywords[0],
        });
      }
    } else if (data.nodeType === 'message') {
      messages.push(nodeToMessage(node));
    } else if (data.nodeType === 'delay') {
      messages.push({
        id: `${node.id}-delay`,
        type: 'typing',
        delay: data.duration || 3,
      });
    } else if (data.nodeType === 'condition') {
      messages.push({
        id: `${node.id}-cond`,
        type: 'received',
        content: `🔀 ${data.label}: checking ${data.variable || '...'}`,
      });
    } else if (data.nodeType === 'action') {
      messages.push({
        id: `${node.id}-action`,
        type: 'received',
        content: `🔗 ${data.label}`,
      });
    } else if (data.nodeType === 'template') {
      messages.push({
        id: `${node.id}-tpl`,
        type: 'received',
        content: `📋 Template: ${data.templateName || 'Untitled'}`,
      });
    }

    // Traverse children
    const children = adj.get(id) || [];
    for (const child of children) {
      queue.push(child);
    }
  }

  return messages;
}

function nodeToMessage(node: FlowNode): PreviewMessage {
  const data = node.data as FlowNodeData;
  if (data.nodeType !== 'message') {
    return { id: node.id, type: 'received', content: data.label };
  }

  return {
    id: node.id,
    type: 'received',
    content: data.bodyText || '',
    headerText: data.headerText,
    footerText: data.footerText,
    mediaUrl: data.mediaUrl,
    mediaType: data.messageType === 'image' ? 'image' : data.messageType === 'video' ? 'video' : undefined,
    buttons: data.buttons,
    listItems: data.listItems,
  };
}
