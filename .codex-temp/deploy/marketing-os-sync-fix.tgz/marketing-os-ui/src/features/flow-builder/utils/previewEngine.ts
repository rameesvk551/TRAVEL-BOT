import type { FlowNode, FlowEdge, PreviewMessage, FlowNodeData } from '../types';

export function getNextNodes(currentNodeId: string, edges: FlowEdge[], nodes: FlowNode[]): FlowNode[] {
  const outgoingEdges = edges.filter((e) => e.source === currentNodeId);
  return outgoingEdges
    .map((e) => nodes.find((n) => n.id === e.target))
    .filter((n): n is FlowNode => n !== undefined);
}

export function generateMessageForNode(node: FlowNode): PreviewMessage {
  const data = node.data as FlowNodeData;

  if (data.nodeType === 'trigger') {
    return {
      id: `${node.id}-${Date.now()}`,
      type: 'received',
      content: `⚡ System Trigger: ${data.triggerType === 'keyword' ? `Keyword (${data.keywords?.join(', ')})` : data.triggerType}`,
      footerText: 'Flow started automatically'
    };
  }
  
  if (data.nodeType === 'delay') {
    return {
      id: `${node.id}-${Date.now()}`,
      type: 'typing',
      delay: data.duration || 3,
    };
  }
  
  if (data.nodeType === 'condition') {
    return {
      id: `${node.id}-${Date.now()}`,
      type: 'received',
      content: `🔀 System Condition: Check ${data.variable || 'variable'} ${data.operator} ${data.value || '...'}`,
      footerText: 'Routing automatically based on logic'
    };
  }
  
  if (data.nodeType === 'action') {
    return {
      id: `${node.id}-${Date.now()}`,
      type: 'received',
      content: `🔗 System Action: ${data.label}`,
      footerText: `API / Action executed in background`
    };
  }
  
  if (data.nodeType === 'template') {
    return {
      id: `${node.id}-${Date.now()}`,
      type: 'received',
      content: `📋 Template Message: ${data.templateName || 'Untitled'}`,
    };
  }

  if (data.nodeType === 'dynamic_catalog') {
    return {
      id: `${node.id}-${Date.now()}`,
      type: 'received',
      content: `📂 Dynamic ${data.dataSource || 'Catalog'}: ${data.bodyText || 'Fetching from DB...'}`,
      footerText: data.footerText || 'User will see real items here',
      listItems: [
        { id: '1', title: 'Sample Item 1', description: 'Real items fetch from DB' },
        { id: '2', title: 'Sample Item 2', description: 'Based on tenantId' }
      ]
    };
  }

  if (data.nodeType === 'add_to_cart') {
    return {
      id: `${node.id}-${Date.now()}`,
      type: 'received',
      content: `🛒 Cart Action: Adding selected_product to cart`,
      footerText: 'Internal database update'
    };
  }

  if (data.nodeType === 'create_order') {
    return {
      id: `${node.id}-${Date.now()}`,
      type: 'received',
      content: `📝 Order Action: Finalizing order (Method: ${data.paymentMethod || 'cod'})`,
      footerText: 'Internal database update'
    };
  }

  // Standard message node
  return {
    id: `${node.id}-${Date.now()}`,
    type: 'received',
    content: data.bodyText || '',
    headerText: data.headerText,
    footerText: data.footerText,
    mediaUrl: data.mediaUrl,
    mediaType: data.messageType === 'image' ? 'image' : data.messageType === 'video' ? 'video' : undefined,
    buttons: data.buttons,
    listItems: data.listItems,
    nodeId: node.id // keep track to know which node this came from
  };
}
