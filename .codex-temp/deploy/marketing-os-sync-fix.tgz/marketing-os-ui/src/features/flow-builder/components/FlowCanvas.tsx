import { useCallback, useRef, type DragEvent } from 'react';
import {
  ReactFlow,
  MiniMap,
  Controls,
  Background,
  BackgroundVariant,
  type ReactFlowInstance,
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import { useFlowStore } from '../store/useFlowStore';
import { nodeTypes } from '../nodes';
import type { FlowNode, FlowEdge, FlowNodeType } from '../types';

export function FlowCanvas() {
  const nodes = useFlowStore((s) => s.nodes);
  const edges = useFlowStore((s) => s.edges);
  const onNodesChange = useFlowStore((s) => s.onNodesChange);
  const onEdgesChange = useFlowStore((s) => s.onEdgesChange);
  const onConnect = useFlowStore((s) => s.onConnect);
  const addNode = useFlowStore((s) => s.addNode);
  const selectNode = useFlowStore((s) => s.selectNode);

  const reactFlowInstance = useRef<ReactFlowInstance<FlowNode, FlowEdge> | null>(null);

  const onDragOver = useCallback((e: DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  }, []);

  const onDrop = useCallback(
    (e: DragEvent) => {
      e.preventDefault();
      const type = e.dataTransfer.getData('application/flowNodeType') as FlowNodeType;
      if (!type || !reactFlowInstance.current) return;

      const position = reactFlowInstance.current.screenToFlowPosition({
        x: e.clientX,
        y: e.clientY,
      });

      addNode(type, position);
    },
    [addNode]
  );

  const onInit = useCallback((instance: ReactFlowInstance<FlowNode, FlowEdge>) => {
    reactFlowInstance.current = instance;
  }, []);

  const onPaneClick = useCallback(() => {
    selectNode(null);
  }, [selectNode]);

  return (
    <div className="flex-1 h-full">
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onConnect={onConnect}
        onInit={onInit}
        onDrop={onDrop}
        onDragOver={onDragOver}
        onPaneClick={onPaneClick}
        nodeTypes={nodeTypes}
        snapToGrid
        snapGrid={[16, 16]}
        fitView
        defaultEdgeOptions={{
          animated: true,
          style: { stroke: '#25D366', strokeWidth: 2 },
        }}
        connectionLineStyle={{ stroke: '#25D366', strokeWidth: 2 }}
        className="bg-gray-50"
      >
        <Background variant={BackgroundVariant.Dots} gap={20} size={1} color="#d1d5db" />
        <Controls
          className="!bg-white !border-gray-200 !rounded-xl !shadow-lg"
          showInteractive={false}
        />
        <MiniMap
          className="!bg-white !border-gray-200 !rounded-xl !shadow-lg"
          nodeColor={(node) => {
            const colors: Record<string, string> = {
              trigger: '#25D366',
              message: '#25D366',
              condition: '#F59E0B',
              delay: '#3B82F6',
              action: '#A855F7',
              template: '#14B8A6',
            };
            return colors[node.type || ''] || '#94A3B8';
          }}
          maskColor="rgba(0,0,0,0.08)"
        />
      </ReactFlow>
    </div>
  );
}
