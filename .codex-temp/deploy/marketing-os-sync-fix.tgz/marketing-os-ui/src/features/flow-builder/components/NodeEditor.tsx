import { useState } from 'react';
import { useFlowStore } from '../store/useFlowStore';
import type { FlowNodeData, ButtonItem } from '../types';

export function NodeEditor() {
  const selectedNodeId = useFlowStore((s) => s.selectedNodeId);
  const nodes = useFlowStore((s) => s.nodes);
  const updateNodeData = useFlowStore((s) => s.updateNodeData);
  const deleteNode = useFlowStore((s) => s.deleteNode);
  const duplicateNode = useFlowStore((s) => s.duplicateNode);
  const selectNode = useFlowStore((s) => s.selectNode);

  const node = nodes.find((n) => n.id === selectedNodeId);

  if (!node || !selectedNodeId) {
    return (
      <div className="w-80 bg-white border-l border-gray-200 flex items-center justify-center p-8">
        <div className="text-center">
          <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-gray-50 flex items-center justify-center text-3xl">
            👆
          </div>
          <p className="text-sm text-gray-400 font-medium">Select a node to edit</p>
          <p className="text-xs text-gray-300 mt-1">Click on any node in the canvas</p>
        </div>
      </div>
    );
  }

  const data = node.data as FlowNodeData;

  return (
    <div className="w-80 bg-white border-l border-gray-200 flex flex-col overflow-hidden">
      {/* Header */}
      <div className="px-4 py-3 border-b border-gray-100 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-lg">{getIcon(data.nodeType)}</span>
          <h3 className="text-sm font-bold text-gray-800">{data.label}</h3>
        </div>
        <button
          onClick={() => selectNode(null)}
          className="w-7 h-7 rounded-lg hover:bg-gray-100 flex items-center justify-center text-gray-400"
        >
          ✕
        </button>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* Common: label */}
        <Field label="Label">
          <input
            type="text"
            value={data.label}
            onChange={(e) => updateNodeData(selectedNodeId, { label: e.target.value } as Partial<FlowNodeData>)}
            className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#25D366]/30 focus:border-[#25D366]"
          />
        </Field>

        {/* Trigger fields */}
        {data.nodeType === 'trigger' && <TriggerFields nodeId={selectedNodeId} data={data} />}

        {/* Message fields */}
        {data.nodeType === 'message' && <MessageFields nodeId={selectedNodeId} data={data} />}

        {/* Condition fields */}
        {data.nodeType === 'condition' && <ConditionFields nodeId={selectedNodeId} data={data} />}

        {/* Delay fields */}
        {data.nodeType === 'delay' && <DelayFields nodeId={selectedNodeId} data={data} />}

        {/* Action fields */}
        {data.nodeType === 'action' && <ActionFields nodeId={selectedNodeId} data={data} />}

        {/* Template fields */}
        {data.nodeType === 'template' && <TemplateFields nodeId={selectedNodeId} data={data as any} />}

        {/* Dynamic Catalog fields */}
        {data.nodeType === 'dynamic_catalog' && <DynamicCatalogFields nodeId={selectedNodeId} data={data as any} />}

        {/* Add to Cart fields */}
        {data.nodeType === 'add_to_cart' && <AddToCartFields />}

        {/* Create Order fields */}
        {data.nodeType === 'create_order' && <CreateOrderFields nodeId={selectedNodeId} data={data as any} />}
      </div>

      {/* Footer actions */}
      <div className="px-4 py-3 border-t border-gray-100 flex gap-2">
        <button
          onClick={() => duplicateNode(selectedNodeId)}
          className="flex-1 px-3 py-2 text-xs font-medium bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg transition-colors"
        >
          📋 Duplicate
        </button>
        <button
          onClick={() => { deleteNode(selectedNodeId); selectNode(null); }}
          className="flex-1 px-3 py-2 text-xs font-medium bg-red-50 hover:bg-red-100 text-red-600 rounded-lg transition-colors"
        >
          🗑️ Delete
        </button>
      </div>
    </div>
  );
}

// ─── Sub-forms ───

function TriggerFields({ nodeId, data }: { nodeId: string; data: FlowNodeData & { nodeType: 'trigger' } }) {
  const update = useFlowStore((s) => s.updateNodeData);
  const [newKeyword, setNewKeyword] = useState('');

  return (
    <>
      <Field label="Trigger Type">
        <select
          value={data.triggerType}
          onChange={(e) => update(nodeId, { triggerType: e.target.value } as any)}
          className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#25D366]/30"
        >
          <option value="keyword">Keyword</option>
          <option value="webhook">Webhook</option>
          <option value="new_lead">New Lead</option>
          <option value="attribute_change">Attribute Change</option>
        </select>
      </Field>

      {data.triggerType === 'keyword' && (
        <Field label="Keywords">
          <div className="space-y-1.5">
            {(data.keywords || []).map((kw, i) => (
              <div key={i} className="flex items-center gap-2">
                <span className="flex-1 px-3 py-1.5 text-sm bg-gray-50 border border-gray-200 rounded-lg">{kw}</span>
                <button
                  onClick={() => update(nodeId, { keywords: data.keywords!.filter((_, j) => j !== i) } as any)}
                  className="text-red-400 hover:text-red-600 text-xs"
                >
                  ×
                </button>
              </div>
            ))}
            <div className="flex gap-2">
              <input
                value={newKeyword}
                onChange={(e) => setNewKeyword(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && newKeyword.trim()) {
                    update(nodeId, { keywords: [...(data.keywords || []), newKeyword.trim()] } as any);
                    setNewKeyword('');
                  }
                }}
                placeholder="Add keyword..."
                className="flex-1 px-3 py-1.5 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#25D366]/30"
              />
            </div>
          </div>
        </Field>
      )}
    </>
  );
}

function MessageFields({ nodeId, data }: { nodeId: string; data: FlowNodeData & { nodeType: 'message' } }) {
  const update = useFlowStore((s) => s.updateNodeData);

  const addButton = () => {
    const btn: ButtonItem = { id: `btn_${Date.now()}`, text: 'Button', type: 'quick_reply' };
    update(nodeId, { buttons: [...(data.buttons || []), btn] } as any);
  };

  const updateButton = (btnId: string, text: string) => {
    update(nodeId, {
      buttons: (data.buttons || []).map((b) => (b.id === btnId ? { ...b, text } : b)),
    } as any);
  };

  const removeButton = (btnId: string) => {
    update(nodeId, { buttons: (data.buttons || []).filter((b) => b.id !== btnId) } as any);
  };

  return (
    <>
      <Field label="Message Type">
        <select
          value={data.messageType}
          onChange={(e) => update(nodeId, { messageType: e.target.value } as any)}
          className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#25D366]/30"
        >
          <option value="text">Text</option>
          <option value="image">Image</option>
          <option value="video">Video</option>
          <option value="buttons">Buttons</option>
          <option value="list">List</option>
        </select>
      </Field>

      <Field label="Header">
        <input
          value={data.headerText || ''}
          onChange={(e) => update(nodeId, { headerText: e.target.value } as any)}
          placeholder="Optional header text"
          className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#25D366]/30"
        />
      </Field>

      <Field label="Body">
        <textarea
          value={data.bodyText}
          onChange={(e) => update(nodeId, { bodyText: e.target.value } as any)}
          rows={4}
          placeholder="Type your message... Use {{variable_name}} for dynamic data"
          className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#25D366]/30 resize-none"
        />
        <p className="text-[11px] text-gray-400 mt-1">Use {'{{name}}'} for variables</p>
      </Field>

      <Field label="Footer">
        <input
          value={data.footerText || ''}
          onChange={(e) => update(nodeId, { footerText: e.target.value } as any)}
          placeholder="Optional footer"
          className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#25D366]/30"
        />
      </Field>

      {(data.messageType === 'image' || data.messageType === 'video') && (
        <Field label="Media URL">
          <input
            value={data.mediaUrl || ''}
            onChange={(e) => update(nodeId, { mediaUrl: e.target.value } as any)}
            placeholder="https://..."
            className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#25D366]/30"
          />
        </Field>
      )}

      {/* Buttons */}
      <Field label="Buttons">
        <div className="space-y-2">
          {(data.buttons || []).map((btn) => (
            <div key={btn.id} className="flex gap-2 items-center">
              <input
                value={btn.text}
                onChange={(e) => updateButton(btn.id, e.target.value)}
                className="flex-1 px-3 py-1.5 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#25D366]/30"
              />
              <button onClick={() => removeButton(btn.id)} className="text-red-400 hover:text-red-600 text-sm">×</button>
            </div>
          ))}
          {(data.buttons || []).length < 3 && (
            <button
              onClick={addButton}
              className="w-full py-1.5 text-xs font-medium text-[#25D366] border border-dashed border-[#25D366]/30 rounded-lg hover:bg-[#25D366]/5 transition-colors"
            >
              + Add Button
            </button>
          )}
        </div>
      </Field>
    </>
  );
}

function ConditionFields({ nodeId, data }: { nodeId: string; data: FlowNodeData & { nodeType: 'condition' } }) {
  const update = useFlowStore((s) => s.updateNodeData);
  return (
    <>
      <Field label="Variable">
        <input
          value={data.variable}
          onChange={(e) => update(nodeId, { variable: e.target.value } as any)}
          placeholder="e.g. customer_type"
          className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#25D366]/30"
        />
      </Field>
      <Field label="Operator">
        <select
          value={data.operator}
          onChange={(e) => update(nodeId, { operator: e.target.value } as any)}
          className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#25D366]/30"
        >
          <option value="equals">Equals</option>
          <option value="contains">Contains</option>
          <option value="greater_than">Greater than</option>
          <option value="less_than">Less than</option>
          <option value="exists">Exists</option>
        </select>
      </Field>
      <Field label="Value">
        <input
          value={data.value}
          onChange={(e) => update(nodeId, { value: e.target.value } as any)}
          placeholder="Comparison value"
          className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#25D366]/30"
        />
      </Field>
    </>
  );
}

function DelayFields({ nodeId, data }: { nodeId: string; data: FlowNodeData & { nodeType: 'delay' } }) {
  const update = useFlowStore((s) => s.updateNodeData);
  return (
    <>
      <Field label="Delay Type">
        <select
          value={data.delayType}
          onChange={(e) => update(nodeId, { delayType: e.target.value } as any)}
          className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#25D366]/30"
        >
          <option value="fixed">Fixed Duration</option>
          <option value="until">Until Specific Time</option>
        </select>
      </Field>
      {data.delayType === 'fixed' ? (
        <div className="flex gap-2">
          <Field label="Duration" className="flex-1">
            <input
              type="number"
              value={data.duration || 0}
              onChange={(e) => update(nodeId, { duration: Number(e.target.value) } as any)}
              className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#25D366]/30"
            />
          </Field>
          <Field label="Unit" className="flex-1">
            <select
              value={data.unit || 'seconds'}
              onChange={(e) => update(nodeId, { unit: e.target.value } as any)}
              className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#25D366]/30"
            >
              <option value="seconds">Seconds</option>
              <option value="minutes">Minutes</option>
              <option value="hours">Hours</option>
              <option value="days">Days</option>
            </select>
          </Field>
        </div>
      ) : (
        <Field label="Until Time">
          <input
            type="datetime-local"
            value={data.untilTime || ''}
            onChange={(e) => update(nodeId, { untilTime: e.target.value } as any)}
            className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#25D366]/30"
          />
        </Field>
      )}
    </>
  );
}

function ActionFields({ nodeId, data }: { nodeId: string; data: FlowNodeData & { nodeType: 'action' } }) {
  const update = useFlowStore((s) => s.updateNodeData);
  return (
    <>
      <Field label="Action Type">
        <select
          value={data.actionType}
          onChange={(e) => update(nodeId, { actionType: e.target.value } as any)}
          className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#25D366]/30"
        >
          <option value="api_call">API Call</option>
          <option value="google_sheets">Google Sheets</option>
          <option value="crm_sync">CRM Sync</option>
          <option value="webhook">Webhook</option>
        </select>
      </Field>
      {(data.actionType === 'api_call' || data.actionType === 'webhook') && (
        <>
          <Field label="Method">
            <select
              value={data.method || 'POST'}
              onChange={(e) => update(nodeId, { method: e.target.value } as any)}
              className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#25D366]/30"
            >
              <option value="GET">GET</option>
              <option value="POST">POST</option>
              <option value="PUT">PUT</option>
              <option value="DELETE">DELETE</option>
            </select>
          </Field>
          <Field label="URL">
            <input
              value={data.url || ''}
              onChange={(e) => update(nodeId, { url: e.target.value } as any)}
              placeholder="https://api.example.com/..."
              className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#25D366]/30"
            />
          </Field>
        </>
      )}
    </>
  );
}

function TemplateFields({ nodeId, data }: { nodeId: string; data: FlowNodeData & { nodeType: 'template' } }) {
  const update = useFlowStore((s) => s.updateNodeData);
  return (
    <>
      <Field label="Template Name">
        <input
          value={data.templateName}
          onChange={(e) => update(nodeId, { templateName: e.target.value } as any)}
          placeholder="e.g. order_confirmation"
          className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#25D366]/30"
        />
      </Field>
      <Field label="Language">
        <select
          value={data.language}
          onChange={(e) => update(nodeId, { language: e.target.value } as any)}
          className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#25D366]/30"
        >
          <option value="en">English</option>
          <option value="hi">Hindi</option>
          <option value="es">Spanish</option>
          <option value="ar">Arabic</option>
        </select>
      </Field>
    </>
  );
}

function DynamicCatalogFields({ nodeId, data }: { nodeId: string; data: any }) {
  const update = useFlowStore((s) => s.updateNodeData);
  return (
    <>
      <Field label="Data Source">
        <select
          value={data.dataSource || 'categories'}
          onChange={(e) => update(nodeId, { dataSource: e.target.value } as any)}
          className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#25D366]/30"
        >
          <option value="categories">Categories (Dynamic)</option>
          <option value="products">Products (Filter by selected_category)</option>
          <option value="featured">Featured / Specials (⭐)</option>
        </select>
      </Field>
      <Field label="Header">
        <input
          value={data.headerText || ''}
          onChange={(e) => update(nodeId, { headerText: e.target.value } as any)}
          placeholder="Optional list header"
          className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#25D366]/30"
        />
      </Field>
      <Field label="Body">
        <textarea
          value={data.bodyText || ''}
          onChange={(e) => update(nodeId, { bodyText: e.target.value } as any)}
          rows={3}
          placeholder="Browse our catalog..."
          className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#25D366]/30 resize-none"
        />
      </Field>
      <Field label="Footer (List Button Label)">
        <input
          value={data.footerText || ''}
          onChange={(e) => update(nodeId, { footerText: e.target.value } as any)}
          placeholder="Select an option"
          className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#25D366]/30"
        />
      </Field>
    </>
  );
}

function AddToCartFields() {
  return (
    <div className="p-3 bg-orange-50 rounded-xl border border-orange-100">
      <p className="text-xs text-orange-600 leading-relaxed font-medium">
        🛒 This node automatically adds the product stored in <code className="bg-orange-100 px-1 rounded">selected_product</code> to the cart and updates variables: <code className="bg-orange-100 px-1 rounded">cart_total</code>, <code className="bg-orange-100 px-1 rounded">cart_item_count</code>.
      </p>
    </div>
  );
}

function CreateOrderFields({ nodeId, data }: { nodeId: string; data: any }) {
  const update = useFlowStore((s) => s.updateNodeData);
  return (
    <>
      <Field label="Default Payment Method">
        <select
          value={data.paymentMethod || 'cod'}
          onChange={(e) => update(nodeId, { paymentMethod: e.target.value } as any)}
          className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#25D366]/30"
        >
          <option value="cod">Cash on Delivery (COD)</option>
          <option value="online">Online Payment (Link)</option>
        </select>
      </Field>
      <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-100 mt-2">
        <p className="text-xs text-emerald-600 leading-relaxed font-medium">
          📋 Finalizes the order and clears the cart. Sets <code className="bg-emerald-100 px-1 rounded">order_id</code> and <code className="bg-emerald-100 px-1 rounded">order_total</code>.
        </p>
      </div>
    </>
  );
}

// ─── Helpers ───

function Field({ label, children, className }: { label: string; children: React.ReactNode; className?: string }) {
  return (
    <div className={className}>
      <label className="block text-xs font-semibold text-gray-500 mb-1.5 uppercase tracking-wider">{label}</label>
      {children}
    </div>
  );
}

function getIcon(type: string) {
  const icons: Record<string, string> = {
    trigger: '⚡',
    message: '💬',
    condition: '🔀',
    delay: '⏱️',
    action: '🔗',
    template: '📋',
    dynamic_catalog: '📂',
    add_to_cart: '🛒',
    create_order: '📋',
  };
  return icons[type] || '📦';
}
