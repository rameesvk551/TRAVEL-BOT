import { useEffect, useRef } from 'react';
import { useFlowStore } from '../store/useFlowStore';
import type { PreviewMessage, ButtonItem } from '../types';
import clsx from 'clsx';
import { format } from 'date-fns';

export function PhonePreview({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
  const messages = useFlowStore((s) => s.previewMessages);
  const handlePreviewInteraction = useFlowStore((s) => s.handlePreviewInteraction);
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const currentTime = format(new Date(), 'HH:mm');

  return (
    <>
      {/* Optional Backdrop */}
      {isOpen && (
        <div 
          className="absolute inset-0 bg-gray-900/10 z-40 transition-opacity backdrop-blur-[1px]"
          onClick={onClose}
        />
      )}

      <div 
        className={`absolute top-0 right-0 bottom-0 w-[420px] xl:w-[480px] flex flex-col items-center py-6 px-4 bg-gray-50/80 backdrop-blur-md border-l border-gray-200/60 z-50 transform transition-transform duration-300 shadow-2xl overflow-y-auto
          ${isOpen ? 'translate-x-0' : 'translate-x-full'}
        `}
      >
        <div className="w-full flex items-center justify-between mb-6 px-2">
          <div>
            <h2 className="text-lg font-bold text-slate-900">Interactive Preview</h2>
            <p className="text-xs text-slate-500">Test your flow conversation</p>
          </div>
          <button 
            onClick={onClose} 
            className="w-8 h-8 flex items-center justify-center text-slate-400 hover:text-slate-700 hover:bg-slate-200/50 rounded-full transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Preview Container */}
        <div className="w-full max-w-[400px] flex-1 flex flex-col overflow-hidden rounded-[24px] border border-emerald-100 bg-[#E8F5E9] shadow-[0_16px_30px_rgba(22,101,52,0.08)] relative">
          
          {/* Header */}
          <div className="flex items-center justify-between bg-[#0f766e] px-4 py-3 text-[11px] font-semibold uppercase tracking-[0.18em] text-emerald-50 shrink-0">
            <span>WhatsApp Preview</span>
            <span className="rounded-full bg-white/16 px-2.5 py-1 text-[10px] tracking-[0.12em] text-white/90">
              Live
            </span>
          </div>

          {/* Chat area */}
          <div className="flex-1 overflow-y-auto px-4 py-5 space-y-4">
            {messages.length === 0 && (
              <div className="flex flex-col items-center justify-center h-full text-slate-400 opacity-80">
                <div className="text-3xl mb-3">💬</div>
                <p className="text-sm font-medium text-center">
                  Add nodes and connect them<br />to start testing
                </p>
              </div>
            )}

            {messages.map((msg) => (
              <MessageBubble 
                key={msg.id} 
                message={msg} 
                onAction={handlePreviewInteraction} 
                currentTime={currentTime} 
              />
            ))}

            <div ref={bottomRef} />
          </div>

          {/* Input bar */}
          <div className="p-3 bg-white/60 backdrop-blur border-t border-emerald-100 shrink-0">
            <form 
              className="flex items-center gap-2"
              onSubmit={(e) => {
                 e.preventDefault();
                 if (inputRef.current?.value.trim()) {
                   handlePreviewInteraction(undefined, inputRef.current.value.trim());
                   inputRef.current.value = '';
                 }
              }}
            >
              <input 
                ref={inputRef}
                type="text"
                className="flex-1 bg-white border border-emerald-100 rounded-[18px] px-4 py-2.5 text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-[#0f766e]/20 focus:border-[#0f766e]/30 shadow-sm transition-all placeholder:text-slate-400"
                placeholder="Type a message..."
              />
              <button 
                type="submit" 
                className="w-10 h-10 rounded-[18px] bg-[#0f766e] flex items-center justify-center text-white shadow-md hover:bg-[#0d645d] transition-colors shrink-0"
              >
                <div className="ml-0.5 transform rotate-[-45deg] scale-110">➤</div>
              </button>
            </form>
          </div>
        </div>
        
        {/* Restart Button & Stats */}
        <div className="mt-6 flex flex-col items-center gap-3">
          <button 
            onClick={() => useFlowStore.getState().startPreview()}
            className="text-[12px] font-semibold text-slate-600 hover:text-slate-900 bg-white border border-slate-200 hover:bg-slate-50 px-4 py-2 rounded-[16px] transition-all shadow-sm flex items-center gap-2"
          >
            <span className="text-lg leading-none">↻</span> Restart Simulator
          </button>
          
          <div className="text-center">
            <p className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">
              {messages.length} message{messages.length !== 1 ? 's' : ''} exchanged
            </p>
          </div>
        </div>
      </div>
    </>
  );
}

// ─── Message bubble ───

function MessageBubble({ message, onAction, currentTime }: { message: PreviewMessage, onAction: (edgeId: string, text: string) => void, currentTime: string }) {
  if (message.type === 'typing') {
    return (
      <div className="flex justify-start">
        <div className="bg-white rounded-[20px] rounded-tl-md px-4 py-3 shadow-[0_12px_24px_rgba(15,23,42,0.06)] min-w-[60px] flex items-center h-[42px]">
          <div className="flex items-center gap-1.5 opacity-60">
            <span className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
            <span className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
            <span className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
          </div>
        </div>
      </div>
    );
  }

  const isSent = message.type === 'sent';

  return (
    <div className={clsx('flex', isSent ? 'justify-end' : 'justify-start')}>
      <div className={clsx('relative max-w-[92%]')}>
        <div
          className={clsx(
            'px-3 sm:px-4 py-2 sm:py-3 text-sm shadow-[0_12px_24px_rgba(15,23,42,0.06)]',
            isSent
              ? 'bg-[#DCF8C6] rounded-[20px] rounded-tr-md text-slate-900'
              : 'bg-white rounded-[20px] rounded-tl-md text-slate-900'
          )}
        >
          {/* Media */}
          {message.mediaUrl && (
            <div className="w-full h-32 mb-2 bg-slate-100 rounded-[14px] flex items-center justify-center text-slate-400 text-xs shadow-inner">
              {message.mediaType === 'video' ? '🎥 Video' : '🖼️ Image'}
            </div>
          )}

          {/* Header */}
          {message.headerText && (
            <div className="mb-1.5 font-semibold text-slate-950 text-[15px]">
              {message.headerText}
            </div>
          )}

          {/* Content */}
          {message.content && (
            <p className="whitespace-pre-wrap leading-relaxed">
              {/* Highlight variables roughly using regex if needed, or simply let it flow */}
              {message.content}
            </p>
          )}

          {/* Footer */}
          {message.footerText && (
            <div className="mt-2 text-[11px] text-slate-400 leading-snug">
              {message.footerText}
            </div>
          )}

          {/* Timestamp */}
          <div className="mt-2 flex items-center justify-end gap-1 text-[11px] text-slate-400">
            <span>{currentTime}</span>
            {isSent && <span className="text-cyan-600">✓✓</span>}
          </div>
        </div>

        {/* Buttons (inside outer container but below bubble, similar to interactive templates) */}
        {message.buttons && message.buttons.length > 0 && (
          <div className="mt-2 overflow-hidden rounded-[18px] border border-slate-200/60 bg-white/90 backdrop-blur shadow-[0_8px_16px_rgba(15,23,42,0.04)]">
            {message.buttons.map((btn: ButtonItem) => (
              <button
                key={btn.id}
                onClick={() => onAction(btn.id, btn.text)}
                className="w-full flex items-center justify-center py-2.5 px-3 text-[13px] font-semibold text-[#0f766e] border-t border-slate-100 first:border-t-0 hover:bg-[#0f766e]/5 active:bg-[#0f766e]/10 transition-colors"
              >
                {btn.text}
              </button>
            ))}
          </div>
        )}

        {/* List items */}
        {message.listItems && message.listItems.length > 0 && (
          <div className="mt-2 overflow-hidden rounded-[18px] border border-slate-200/60 bg-white/90 backdrop-blur shadow-[0_8px_16px_rgba(15,23,42,0.04)]">
            <div className="px-3 py-2 bg-slate-50/80 border-b border-slate-100/80 text-[11px] font-semibold text-slate-500 uppercase tracking-widest text-center">
              Options
            </div>
            {message.listItems.map((item) => (
              <button 
                key={item.id} 
                className="w-full text-left py-2.5 px-4 border-t border-slate-100 first:border-t-0 hover:bg-[#0f766e]/5 active:bg-[#0f766e]/10 transition-colors"
                onClick={() => onAction(item.id, item.title)}
              >
                <div className="text-[14px] font-semibold text-[#0f766e]">{item.title}</div>
                {item.description && <div className="text-[12px] text-slate-500 mt-0.5 leading-snug">{item.description}</div>}
              </button>
            ))}
          </div>
        )}

        {/* Bubble Tail */}
        <span 
          className={clsx(
            "absolute top-0 h-0 w-0 border-b-[10px] border-t-0 border-b-transparent",
            isSent 
              ? "-right-2 border-l-[10px] border-r-0 border-l-[#DCF8C6]" 
              : "-left-2 border-r-[10px] border-l-0 border-r-white"
          )} 
        />
      </div>
    </div>
  );
}
