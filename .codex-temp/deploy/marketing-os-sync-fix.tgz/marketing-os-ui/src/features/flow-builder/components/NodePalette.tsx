import { type DragEvent } from 'react';
import { PALETTE_ITEMS } from '../types';
import type { FlowNodeType } from '../types';

interface NodePaletteProps {
  collapsed?: boolean;
  onToggle?: () => void;
}

export function NodePalette({ collapsed, onToggle }: NodePaletteProps) {
  const messageItems = PALETTE_ITEMS.filter((p) => p.category === 'messages');
  const actionItems = PALETTE_ITEMS.filter((p) => p.category === 'actions');

  const onDragStart = (event: DragEvent, nodeType: FlowNodeType) => {
    event.dataTransfer.setData('application/flowNodeType', nodeType);
    event.dataTransfer.effectAllowed = 'move';
  };

  if (collapsed) {
    return (
      <div className="w-12 bg-white border-r border-gray-200 flex flex-col items-center py-4 gap-3">
        <button
          onClick={onToggle}
          className="w-8 h-8 rounded-lg bg-gray-100 hover:bg-gray-200 flex items-center justify-center text-gray-600 transition-colors"
          title="Expand sidebar"
        >
          ☰
        </button>
        {PALETTE_ITEMS.map((item) => (
          <div
            key={item.type}
            draggable
            onDragStart={(e) => onDragStart(e, item.type)}
            className="w-9 h-9 rounded-lg bg-gray-50 hover:bg-[#25D366]/10 border border-gray-200 hover:border-[#25D366]/30 flex items-center justify-center cursor-grab active:cursor-grabbing transition-all text-base"
            title={item.label}
          >
            {item.icon}
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="w-64 bg-white border-r border-gray-200 flex flex-col overflow-hidden">
      {/* Header */}
      <div className="px-4 py-3 border-b border-gray-100 flex items-center justify-between">
        <h3 className="text-sm font-bold text-gray-800 tracking-wide uppercase">Nodes</h3>
        {onToggle && (
          <button
            onClick={onToggle}
            className="w-7 h-7 rounded-lg hover:bg-gray-100 flex items-center justify-center text-gray-400 transition-colors"
          >
            ✕
          </button>
        )}
      </div>

      <div className="flex-1 overflow-y-auto p-3 space-y-5">
        {/* Message types */}
        <div>
          <h4 className="text-xs font-semibold text-[#25D366] uppercase tracking-wider mb-2 px-1">
            Message types
          </h4>
          <div className="grid grid-cols-2 gap-2">
            {messageItems.map((item) => (
              <div
                key={item.type}
                draggable
                onDragStart={(e) => onDragStart(e, item.type)}
                className="flex flex-col items-center gap-1.5 p-3 rounded-xl border-2 border-gray-100 bg-white hover:border-[#25D366]/40 hover:bg-[#25D366]/5 cursor-grab active:cursor-grabbing transition-all group"
              >
                <div className="w-10 h-10 rounded-xl bg-gray-50 group-hover:bg-[#25D366]/10 flex items-center justify-center text-xl transition-colors">
                  {item.icon}
                </div>
                <span className="text-xs font-medium text-gray-600 group-hover:text-gray-900 text-center leading-tight">
                  {item.label}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Actions */}
        <div>
          <h4 className="text-xs font-semibold text-[#25D366] uppercase tracking-wider mb-2 px-1">
            Actions
          </h4>
          <div className="grid grid-cols-2 gap-2">
            {actionItems.map((item) => (
              <div
                key={item.type}
                draggable
                onDragStart={(e) => onDragStart(e, item.type)}
                className="flex flex-col items-center gap-1.5 p-3 rounded-xl border-2 border-gray-100 bg-white hover:border-[#25D366]/40 hover:bg-[#25D366]/5 cursor-grab active:cursor-grabbing transition-all group"
              >
                <div className="w-10 h-10 rounded-xl bg-gray-50 group-hover:bg-[#25D366]/10 flex items-center justify-center text-xl transition-colors">
                  {item.icon}
                </div>
                <span className="text-xs font-medium text-gray-600 group-hover:text-gray-900 text-center leading-tight">
                  {item.label}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Footer hint */}
      <div className="px-4 py-2.5 border-t border-gray-100 bg-gray-50">
        <p className="text-[11px] text-gray-400 text-center">
          Drag and drop nodes onto the canvas
        </p>
      </div>
    </div>
  );
}
