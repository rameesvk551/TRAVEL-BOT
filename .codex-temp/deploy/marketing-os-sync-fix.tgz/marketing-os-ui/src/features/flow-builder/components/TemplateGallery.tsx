import { useState } from 'react';
import { FLOW_TEMPLATES, type FlowTemplate } from '../templates';
import { useFlowStore } from '../store/useFlowStore';

interface TemplateGalleryProps {
  onClose: () => void;
}

const CATEGORY_LABELS: Record<string, string> = {
  restaurant: '🍽 Restaurant',
  ecommerce: '🛍 E-Commerce',
  support: '🎧 Support',
  marketing: '📢 Marketing',
  custom: '🧩 Custom',
};

export function TemplateGallery({ onClose }: TemplateGalleryProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [previewTemplate, setPreviewTemplate] = useState<FlowTemplate | null>(null);
  const loadFlow = useFlowStore((s) => s.loadFlow);

  const categories = ['all', ...new Set(FLOW_TEMPLATES.map((t) => t.category))];

  const filtered =
    selectedCategory === 'all'
      ? FLOW_TEMPLATES
      : FLOW_TEMPLATES.filter((t) => t.category === selectedCategory);

  const handleUseTemplate = (template: FlowTemplate) => {
    loadFlow(template.nodes, template.edges, template.meta);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="bg-white rounded-2xl shadow-2xl w-[720px] max-h-[85vh] flex flex-col overflow-hidden animate-in">
        {/* Header */}
        <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between shrink-0">
          <div>
            <h2 className="text-lg font-bold text-gray-900">Flow Templates</h2>
            <p className="text-xs text-gray-500 mt-0.5">
              Start with a prebuilt flow and customize it to your needs
            </p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg flex items-center justify-center text-gray-400 hover:bg-gray-100 hover:text-gray-600 transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Category Tabs */}
        <div className="px-6 py-3 border-b border-gray-50 flex gap-2 shrink-0 overflow-x-auto">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-colors ${
                selectedCategory === cat
                  ? 'bg-[#25D366] text-white shadow-sm'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              {cat === 'all' ? '🌐 All' : CATEGORY_LABELS[cat] || cat}
            </button>
          ))}
        </div>

        {/* Template Grid */}
        <div className="flex-1 overflow-y-auto p-6">
          {filtered.length === 0 ? (
            <div className="text-center py-16 text-gray-400">
              <div className="text-4xl mb-3">📭</div>
              <p className="text-sm">No templates in this category yet</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-4">
              {filtered.map((template) => (
                <div
                  key={template.id}
                  className={`group relative border rounded-xl p-4 cursor-pointer transition-all hover:shadow-lg hover:border-[#25D366]/40 ${
                    previewTemplate?.id === template.id
                      ? 'border-[#25D366] shadow-md bg-[#25D366]/5'
                      : 'border-gray-200 bg-white'
                  }`}
                  onClick={() => setPreviewTemplate(template)}
                >
                  {/* Icon & Name */}
                  <div className="flex items-start gap-3 mb-3">
                    <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#25D366]/10 to-[#25D366]/5 flex items-center justify-center text-xl shrink-0">
                      {template.icon}
                    </div>
                    <div className="min-w-0">
                      <h3 className="text-sm font-semibold text-gray-900 truncate">
                        {template.name}
                      </h3>
                      <p className="text-[11px] text-gray-500 mt-0.5 line-clamp-2">
                        {template.description}
                      </p>
                    </div>
                  </div>

                  {/* Stats */}
                  <div className="flex items-center gap-3 text-[10px] text-gray-400">
                    <span className="flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#25D366]" />
                      {template.nodeCount} nodes
                    </span>
                    <span className="flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-blue-400" />
                      {template.edges.length} connections
                    </span>
                  </div>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-1 mt-2.5">
                    {template.tags.slice(0, 4).map((tag) => (
                      <span
                        key={tag}
                        className="px-1.5 py-0.5 text-[9px] font-medium rounded bg-gray-100 text-gray-500"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>

                  {/* Hover overlay */}
                  <div className="absolute inset-0 rounded-xl bg-[#25D366]/0 group-hover:bg-[#25D366]/[0.02] transition-colors pointer-events-none" />
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer with action */}
        {previewTemplate && (
          <div className="px-6 py-4 border-t border-gray-100 flex items-center justify-between shrink-0 bg-gray-50/50">
            <div className="min-w-0">
              <p className="text-xs font-semibold text-gray-800 truncate">
                {previewTemplate.icon} {previewTemplate.name}
              </p>
              <p className="text-[10px] text-gray-500">
                {previewTemplate.nodeCount} nodes · {previewTemplate.edges.length} edges
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setPreviewTemplate(null)}
                className="px-3 py-1.5 text-xs font-medium text-gray-500 hover:bg-gray-200 rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => handleUseTemplate(previewTemplate)}
                className="px-4 py-2 text-xs font-semibold text-white bg-[#25D366] hover:bg-[#1ea855] rounded-lg transition-colors shadow-sm"
              >
                ✨ Use This Template
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
