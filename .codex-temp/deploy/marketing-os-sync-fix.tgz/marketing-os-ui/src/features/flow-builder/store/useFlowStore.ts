import { create } from 'zustand';
import {
  applyNodeChanges,
  applyEdgeChanges,
  addEdge,
  type OnNodesChange,
  type OnEdgesChange,
  type OnConnect,
  type NodeChange,
  type EdgeChange,
  type Connection,
} from '@xyflow/react';
import type { FlowNode, FlowEdge, FlowNodeData, FlowNodeType, PreviewMessage } from '../types';
import { generateMessageForNode } from '../utils/previewEngine';

let nodeIdCounter = 0;
const genId = () => `node_${++nodeIdCounter}_${Date.now()}`;

interface HistoryEntry {
  nodes: FlowNode[];
  edges: FlowEdge[];
}

interface FlowMeta {
  id?: string;
  name: string;
  status: 'draft' | 'active' | 'inactive';
}

interface FlowState {
  // Meta
  flowMeta: FlowMeta;
  setFlowMeta: (meta: Partial<FlowMeta>) => void;

  // Canvas
  nodes: FlowNode[];
  edges: FlowEdge[];
  onNodesChange: OnNodesChange;
  onEdgesChange: OnEdgesChange;
  onConnect: OnConnect;

  // Node CRUD
  addNode: (type: FlowNodeType, position: { x: number; y: number }) => FlowNode;
  updateNodeData: (nodeId: string, data: Partial<FlowNodeData>) => void;
  deleteNode: (nodeId: string) => void;
  duplicateNode: (nodeId: string) => void;

  // Selection
  selectedNodeId: string | null;
  selectNode: (id: string | null) => void;

  // History
  undoStack: HistoryEntry[];
  redoStack: HistoryEntry[];
  pushHistory: () => void;
  undo: () => void;
  redo: () => void;

  // Preview
  previewMessages: PreviewMessage[];
  currentPreviewNodeId: string | null;
  startPreview: () => void;
  handlePreviewInteraction: (edgeId?: string, userReply?: string) => void;

  // Serialization
  loadFlow: (nodes: FlowNode[], edges: FlowEdge[], meta?: FlowMeta) => void;
  toJSON: () => object;
}

function getDefaultData(type: FlowNodeType): FlowNodeData {
  switch (type) {
    case 'trigger':
      return { nodeType: 'trigger', label: 'Flow Start', triggerType: 'keyword', keywords: ['Hi', 'Hello'] };
    case 'message':
      return { nodeType: 'message', label: 'Send Message', messageType: 'text', bodyText: 'Hello {{name}}! 👋', buttons: [], listItems: [] };
    case 'condition':
      return { nodeType: 'condition', label: 'Condition', variable: '', operator: 'equals', value: '', branches: [{ id: 'yes', label: 'Yes', condition: 'true' }, { id: 'no', label: 'No', condition: 'false' }] };
    case 'delay':
      return { nodeType: 'delay', label: 'Wait', delayType: 'fixed', duration: 5, unit: 'seconds' };
    case 'action':
      return { nodeType: 'action', label: 'API Call', actionType: 'api_call', url: '', method: 'POST' };
    case 'template':
      return { nodeType: 'template', label: 'Template', templateName: '', language: 'en', variables: {} };
    case 'dynamic_catalog':
      return { nodeType: 'dynamic_catalog', label: 'Dynamic Catalog', dataSource: 'categories', bodyText: 'Check out our options below:', footerText: 'View Options' };
    case 'add_to_cart':
      return { nodeType: 'add_to_cart', label: 'Add to Cart' };
    case 'create_order':
      return { nodeType: 'create_order', label: 'Create Order', paymentMethod: 'cod' };
  }
}

export const useFlowStore = create<FlowState>((set, get) => ({
  // Meta
  flowMeta: { name: 'Untitled Flow', status: 'draft' },
  setFlowMeta: (meta) => set((s) => ({ flowMeta: { ...s.flowMeta, ...meta } })),

  // Canvas
  nodes: [],
  edges: [],
  onNodesChange: (changes: NodeChange[]) => {
    set((s) => ({ nodes: applyNodeChanges(changes, s.nodes as any) as unknown as FlowNode[] }));
    // If we delete the current preview node, restart preview
    setTimeout(() => {
      const { currentPreviewNodeId, nodes, startPreview } = get();
      if (currentPreviewNodeId && !nodes.find(n => n.id === currentPreviewNodeId)) {
        startPreview();
      }
    }, 100);
  },
  onEdgesChange: (changes: EdgeChange[]) => {
    set((s) => ({ edges: applyEdgeChanges(changes, s.edges) as FlowEdge[] }));
  },
  onConnect: (connection: Connection) => {
    get().pushHistory();
    set((s) => ({
      edges: addEdge(
        { ...connection, animated: true, style: { stroke: '#25D366', strokeWidth: 2 } },
        s.edges
      ) as FlowEdge[],
    }));
  },

  // Node CRUD
  addNode: (type, position) => {
    get().pushHistory();
    const id = genId();
    const newNode: FlowNode = {
      id,
      type,
      position,
      data: getDefaultData(type),
    };
    set((s) => ({ nodes: [...s.nodes, newNode] }));
    if (get().previewMessages.length === 0) get().startPreview();
    return newNode;
  },
  updateNodeData: (nodeId, data) => {
    get().pushHistory();
    set((s) => ({
      nodes: s.nodes.map((n) =>
        n.id === nodeId ? { ...n, data: { ...n.data, ...data } as FlowNodeData } : n
      ),
    }));
    
    // Auto-update preview if modifying current node
    if (get().currentPreviewNodeId === nodeId) {
       const updatedNode = get().nodes.find(n => n.id === nodeId);
       if (updatedNode) {
          set(s => {
             const newMsgs = [...s.previewMessages];
             const lastMsgIdx = newMsgs.map(m => m.id).lastIndexOf(nodeId);
             if (lastMsgIdx !== -1) {
                newMsgs[lastMsgIdx] = generateMessageForNode(updatedNode);
             }
             return { previewMessages: newMsgs };
          });
       }
    }
  },
  deleteNode: (nodeId) => {
    get().pushHistory();
    set((s) => ({
      nodes: s.nodes.filter((n) => n.id !== nodeId),
      edges: s.edges.filter((e) => e.source !== nodeId && e.target !== nodeId),
      selectedNodeId: s.selectedNodeId === nodeId ? null : s.selectedNodeId,
    }));
  },
  duplicateNode: (nodeId) => {
    const state = get();
    const node = state.nodes.find((n) => n.id === nodeId);
    if (!node) return;
    state.pushHistory();
    const id = genId();
    const dup: FlowNode = {
      ...node,
      id,
      position: { x: node.position.x + 40, y: node.position.y + 40 },
      data: { ...node.data } as FlowNodeData,
    };
    set((s) => ({ nodes: [...s.nodes, dup] }));
  },

  // Selection
  selectedNodeId: null,
  selectNode: (id) => set({ selectedNodeId: id }),

  // History
  undoStack: [],
  redoStack: [],
  pushHistory: () => {
    const { nodes, edges, undoStack } = get();
    set({
      undoStack: [...undoStack.slice(-30), { nodes: JSON.parse(JSON.stringify(nodes)), edges: JSON.parse(JSON.stringify(edges)) }],
      redoStack: [],
    });
  },
  undo: () => {
    const { undoStack, nodes, edges } = get();
    if (undoStack.length === 0) return;
    const prev = undoStack[undoStack.length - 1];
    set((s) => ({
      nodes: prev.nodes,
      edges: prev.edges,
      undoStack: s.undoStack.slice(0, -1),
      redoStack: [...s.redoStack, { nodes: JSON.parse(JSON.stringify(nodes)), edges: JSON.parse(JSON.stringify(edges)) }],
    }));
  },
  redo: () => {
    const { redoStack, nodes, edges } = get();
    if (redoStack.length === 0) return;
    const next = redoStack[redoStack.length - 1];
    set((s) => ({
      nodes: next.nodes,
      edges: next.edges,
      redoStack: s.redoStack.slice(0, -1),
      undoStack: [...s.undoStack, { nodes: JSON.parse(JSON.stringify(nodes)), edges: JSON.parse(JSON.stringify(edges)) }],
    }));
  },

  // Preview
  previewMessages: [],
  currentPreviewNodeId: null,
  startPreview: () => {
    const { nodes } = get();
    if (nodes.length === 0) {
      set({ previewMessages: [], currentPreviewNodeId: null });
      return;
    }

    const triggerNode = nodes.find((n) => (n.data as FlowNodeData).nodeType === 'trigger');
    const startNode = triggerNode || nodes[0];
    
    // Reset preview state
    set({ previewMessages: [], currentPreviewNodeId: null });
    
    // Begin interactive run
    get().handlePreviewInteraction(undefined, (startNode.data as any).keywords?.[0] || 'Start');
  },
  
  handlePreviewInteraction: (edgeId?: string, userReply?: string) => {
    const { nodes, edges, currentPreviewNodeId, previewMessages } = get();
    const newMessages = [...previewMessages];

    // 1. Add user reply if provided
    if (userReply) {
      newMessages.push({
        id: `user_${Date.now()}`,
        type: 'sent',
        content: userReply,
      });
    }

    // 2. Determine next node
    let nextNode: FlowNode | undefined;
    
    if (!currentPreviewNodeId) {
      // First start
      nextNode = nodes.find((n) => (n.data as FlowNodeData).nodeType === 'trigger') || nodes[0];
    } else {
      // Follow specific edge or first available edge
      const outgoingEdges = edges.filter(e => e.source === currentPreviewNodeId);
      if (outgoingEdges.length === 0) return; // End of flow
      
      let followedEdge: FlowEdge | undefined;
      
      if (edgeId && userReply) {
         // 1. Try exact sourceHandle match
         followedEdge = outgoingEdges.find(e => e.sourceHandle === edgeId);
         // 2. Try exact label match
         if (!followedEdge) {
            followedEdge = outgoingEdges.find(e => e.label === userReply);
         }
         // 3. Try fuzzy label match (ignoring emojis)
         if (!followedEdge) {
            const cleanReply = userReply.replace(/[\u{1F300}-\u{1F64F}\u{1F680}-\u{1F6FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]/gu, '').trim().toLowerCase();
            followedEdge = outgoingEdges.find(e => {
               if (!e.label) return false;
               const cleanLabel = (e.label as string).replace(/[\u{1F300}-\u{1F64F}\u{1F680}-\u{1F6FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]/gu, '').trim().toLowerCase();
               return cleanLabel.includes(cleanReply) || cleanReply.includes(cleanLabel);
            });
         }
      }
      
      // 4. Fallback to first edge
      if (!followedEdge) {
         followedEdge = outgoingEdges[0];
      }
      
      if (followedEdge) {
        nextNode = nodes.find(n => n.id === followedEdge!.target);
      }
    }

    if (!nextNode) return;

    // 3. Process the next node(s) automatically through action/logic nodes until hitting a message/interactive node
    let currentNode: FlowNode | undefined = nextNode;
    
    const processChain = async () => {
      while (currentNode) {
         const data = currentNode.data as FlowNodeData;
         
         // Visual delay for non-message nodes
         if (data.nodeType === 'action' || data.nodeType === 'condition' || data.nodeType === 'delay') {
            newMessages.push(generateMessageForNode(currentNode));
            set({ previewMessages: [...newMessages], currentPreviewNodeId: currentNode.id });
            
            // tiny sleep for effect
            await new Promise(r => setTimeout(r, 600));
            
            const nextEdges = get().edges.filter(e => e.source === currentNode!.id);
            if (nextEdges.length > 0) {
               currentNode = get().nodes.find(n => n.id === nextEdges[0].target);
               continue;
            } else {
               currentNode = undefined;
               break;
            }
         }
         
         // Message node (interactive)
         if (data.nodeType === 'message' || data.nodeType === 'trigger') {
            newMessages.push(generateMessageForNode(currentNode));
            set({ previewMessages: [...newMessages], currentPreviewNodeId: currentNode.id });
            break; // Stop automatic chain, wait for user interaction
         }
         
         break;
      }
    };
    
    processChain();
  },

  // Serialization
  loadFlow: (nodes, edges, meta) => {
    set({
      nodes,
      edges,
      flowMeta: meta || { name: 'Untitled Flow', status: 'draft' },
      undoStack: [],
      redoStack: [],
      selectedNodeId: null,
    });
    setTimeout(() => get().startPreview(), 100);
  },
  toJSON: () => {
    const { nodes, edges, flowMeta } = get();
    return { id: flowMeta.id, name: flowMeta.name, status: flowMeta.status, nodes, edges };
  },
}));
