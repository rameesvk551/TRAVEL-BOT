import type { FlowNode, FlowEdge } from '../types';
import restaurantFlow from './restaurant-ordering-flow.json';
import ecommerceFlow from './ecommerce-store-flow.json';
import pureInteractiveMenuFlow from './pure-interactive-menu-flow.json';
import dynamicCommerceFlow from './dynamic-commerce-flow.json';

export interface FlowTemplate {
  id: string;
  name: string;
  description: string;
  icon: string;
  category: 'restaurant' | 'ecommerce' | 'support' | 'marketing' | 'custom';
  tags: string[];
  nodeCount: number;
  nodes: FlowNode[];
  edges: FlowEdge[];
  meta: {
    name: string;
    status: 'draft' | 'active' | 'inactive';
  };
}

function parseTemplate(raw: typeof restaurantFlow): { nodes: FlowNode[]; edges: FlowEdge[] } {
  return {
    nodes: raw.nodes as unknown as FlowNode[],
    edges: raw.edges.map((e) => ({
      ...e,
      id: e.id,
      source: e.source,
      target: e.target,
      animated: e.animated ?? true,
      label: e.label || undefined,
      style: e.style as Record<string, unknown>,
    })) as unknown as FlowEdge[],
  };
}

const parsed = parseTemplate(restaurantFlow);

export const FLOW_TEMPLATES: FlowTemplate[] = [
  {
    id: 'pure_interactive_menu',
    name: '📱 Pure Interactive Menu (Fast)',
    description: 'A lightning-fast WhatsApp menu where all categories and items are stored directly within the JSON template. No database needed!',
    icon: '⚡',
    category: 'restaurant',
    tags: ['fast', 'menu', 'interactive', 'json', 'restaurant'],
    nodeCount: pureInteractiveMenuFlow.nodes.length,
    nodes: parseTemplate(pureInteractiveMenuFlow as unknown as typeof restaurantFlow).nodes,
    edges: parseTemplate(pureInteractiveMenuFlow as unknown as typeof restaurantFlow).edges,
    meta: {
      name: pureInteractiveMenuFlow.meta.name,
      status: pureInteractiveMenuFlow.meta.status as 'draft',
    },
  },
  {
    id: 'restaurant_ordering',
    name: '🍽 Restaurant Ordering',
    description: 'Complete WhatsApp ordering flow with menu browsing, cart, checkout, upsells & order tracking.',
    icon: '🍔',
    category: 'restaurant',
    tags: ['food', 'ordering', 'delivery', 'menu', 'cart', 'checkout'],
    nodeCount: restaurantFlow.nodes.length,
    nodes: parsed.nodes,
    edges: parsed.edges,
    meta: {
      name: restaurantFlow.meta.name,
      status: restaurantFlow.meta.status as 'draft',
    },
  },
  {
    id: 'ecommerce_store',
    name: '🛍 E-Commerce Store',
    description: 'WhatsApp-based e-commerce store with product catalog, cart, checkout, payments, and shipping updates.',
    icon: '🛍️',
    category: 'ecommerce',
    tags: ['shopping', 'catalog', 'checkout', 'payments', 'tracking'],
    nodeCount: ecommerceFlow.nodes.length,
    nodes: parseTemplate(ecommerceFlow as unknown as typeof restaurantFlow).nodes,
    edges: parseTemplate(ecommerceFlow as unknown as typeof restaurantFlow).edges,
    meta: {
      name: ecommerceFlow.meta.name,
      status: ecommerceFlow.meta.status as 'draft',
    },
  },
  {
    id: 'dynamic_commerce_flow',
    name: '🛒 Dynamic Commerce (DB-Driven)',
    description: 'The ultimate multi-tenant commerce flow. Fetches categories and products from your database in real-time. Perfectly adapts to any business!',
    icon: '🚀',
    category: 'ecommerce',
    tags: ['dynamic', 'db', 'multi-tenant', 'commerce', 'restaurant', 'store'],
    nodeCount: dynamicCommerceFlow.nodes.length,
    nodes: parseTemplate(dynamicCommerceFlow as unknown as typeof restaurantFlow).nodes,
    edges: parseTemplate(dynamicCommerceFlow as unknown as typeof restaurantFlow).edges,
    meta: {
      name: dynamicCommerceFlow.meta.name,
      status: dynamicCommerceFlow.meta.status as 'draft',
    },
  },
];

export function getTemplateById(id: string): FlowTemplate | undefined {
  return FLOW_TEMPLATES.find((t) => t.id === id);
}
