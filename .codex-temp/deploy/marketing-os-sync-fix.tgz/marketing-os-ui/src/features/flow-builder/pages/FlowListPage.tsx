import { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { Card, Input, Button, Table, Typography, Space } from 'antd';
import { 
  PlusOutlined, 
  SearchOutlined, 
  CopyOutlined, 
  EditOutlined, 
  DeleteOutlined,
  ReadOutlined
} from '@ant-design/icons';

import { flowApi } from '../api/flowApi';
import { FLOW_TEMPLATES } from '../templates';

const { Title, Text } = Typography;


export function FlowListPage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState('flows');

  const { data: flows = [], isLoading } = useQuery({
    queryKey: ['flows'],
    queryFn: flowApi.getFlows,
  });
  
  const columns = [
    {
      title: 'Flow Name',
      dataIndex: 'name',
      key: 'name',
      render: (text: string) => <span className="font-medium text-gray-800">{text}</span>,
    },
    {
      title: 'Created By',
      dataIndex: 'createdBy',
      key: 'createdBy',
      render: (text: string) => <span className="text-gray-600 font-medium">{text || 'Admin'}</span>,
    },
    {
      title: 'Status',
      dataIndex: 'status',
      key: 'status',
      render: (status: string, record: any) => {
        const isActive = status === 'active';
        return (
          <div 
            className={`w-10 h-5 rounded-full flex items-center px-1 transition-colors cursor-pointer ${isActive ? 'bg-[#1E3A8A]' : 'bg-gray-300'}`}
            onClick={async () => {
              try {
                const newStatus = isActive ? 'inactive' : 'active';
                await flowApi.updateFlowStatus(record._id, newStatus);
                // Invalidate query to refetch data
                queryClient.invalidateQueries({ queryKey: ['flows'] });
              } catch (error) {
                console.error('Failed to update flow status', error);
              }
            }}
          >
            <div className={`w-3.5 h-3.5 rounded-full bg-white transition-transform ${isActive ? 'translate-x-4' : 'translate-x-0'}`} />
          </div>
        );
      },
    },
    {
      title: 'Actions',
      key: 'actions',
      render: (_: any, record: any) => (
        <Space size="middle" className="text-gray-500 text-lg">
          <CopyOutlined className="cursor-pointer hover:text-indigo-600 transition-colors" />
          <EditOutlined className="cursor-pointer hover:text-indigo-600 transition-colors" onClick={() => navigate(`/flows/${record._id}`)} />
          <DeleteOutlined className="cursor-pointer hover:text-red-600 transition-colors" />
        </Space>
      ),
    },
  ];

  return (
    <div className="p-6 w-full space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between pb-4 border-b border-gray-100">
        <Typography.Title level={4} style={{ margin: 0, fontWeight: 600, color: '#1E293B' }}>
          Flow Builder
        </Typography.Title>
      </div>

      {/* Search and Action */}
      <div className="flex items-center justify-between pt-4">
        <Input 
          placeholder="Search by flow name" 
          prefix={<SearchOutlined className="text-gray-400" />}
          className="max-w-md h-10 bg-gray-50/50 border-gray-200 hover:bg-white focus:bg-white transition-colors"
        />
        <Button 
          type="primary" 
          icon={<PlusOutlined />} 
          className="h-10 px-5 bg-[#0F172A] hover:bg-[#1E293B]"
          onClick={() => navigate('/flows/new')}
        >
          Create Flow
        </Button>
      </div>

      {/* Tabs and Content */}
      <div className="pt-2">
        <div className="border-b border-gray-200 mb-6 flex gap-6">
          <button 
            className={`pb-3 font-medium text-sm border-b-2 transition-colors flex items-center gap-2 ${activeTab === 'flows' ? 'border-[#0F172A] text-[#0F172A]' : 'border-transparent text-gray-500 hover:text-gray-700'}`}
            onClick={() => setActiveTab('flows')}
          >
            <span className={`w-4 h-4 rounded-full border-2 ${activeTab === 'flows' ? 'border-[#0F172A]' : 'border-gray-400'}`} />
            Your Flows
          </button>
          <button 
            className={`pb-3 font-medium text-sm border-b-2 transition-colors flex items-center gap-2 ${activeTab === 'templates' ? 'border-[#0F172A] text-[#0F172A]' : 'border-transparent text-gray-500 hover:text-gray-700'}`}
            onClick={() => setActiveTab('templates')}
          >
            <ReadOutlined />
            Templates
            <span className="px-1.5 py-0.5 bg-[#DCFCE7] text-[#166534] text-[10px] uppercase font-bold rounded">NEW</span>
          </button>
        </div>

        {activeTab === 'flows' && (
          <Table 
            dataSource={flows} 
            loading={isLoading}
            columns={columns} 
            pagination={false}
            rowKey="_id"
            className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden [&_.ant-table-thead_th]:!bg-white [&_.ant-table-thead_th]:!text-gray-500 [&_.ant-table-thead_th]:!font-medium"
          />
        )}

        {activeTab === 'templates' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-fade-in">
             {FLOW_TEMPLATES.map(template => (
               <Card key={template.id} hoverable className="h-full border-gray-200 shadow-sm hover:shadow-md transition-shadow overflow-hidden group">
                  <div className="flex items-start gap-4">
                     <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center text-2xl group-hover:scale-110 group-hover:bg-indigo-600 group-hover:text-white transition-all">
                       {template.icon}
                     </div>
                     <div>
                       <Title level={5} className="!mb-1 group-hover:text-indigo-600 transition-colors">{template.name}</Title>
                       <Text className="text-gray-500 text-sm line-clamp-2">{template.description}</Text>
                     </div>
                  </div>
                  <div className="mt-4 pt-4 border-t border-gray-100 flex items-center justify-between">
                    <Button type="text" className="text-indigo-600 font-medium p-0 hover:bg-transparent" onClick={() => navigate('/flows/new?template=' + template.id)}>
                      Use Template →
                    </Button>
                  </div>
               </Card>
             ))}
          </div>
        )}
      </div>
    </div>
  );
}
