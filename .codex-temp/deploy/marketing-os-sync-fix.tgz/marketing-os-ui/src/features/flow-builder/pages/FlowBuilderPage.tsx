import { useState, useCallback, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { message } from 'antd';
import { ReactFlowProvider } from '@xyflow/react';
import { NodePalette } from '../components/NodePalette';
import { FlowCanvas } from '../components/FlowCanvas';
import { NodeEditor } from '../components/NodeEditor';
import { PhonePreview } from '../components/PhonePreview';
import { TemplateGallery } from '../components/TemplateGallery';
import { useFlowStore } from '../store/useFlowStore';
import { flowApi } from '../api/flowApi';

export function FlowBuilderPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [showPreview, setShowPreview] = useState(true);
  const [showTemplates, setShowTemplates] = useState(false);
  const [loading, setLoading] = useState(!!id);

  const flowMeta = useFlowStore((s) => s.flowMeta);
  const setFlowMeta = useFlowStore((s) => s.setFlowMeta);
  const undo = useFlowStore((s) => s.undo);
  const redo = useFlowStore((s) => s.redo);
  const undoStack = useFlowStore((s) => s.undoStack);
  const redoStack = useFlowStore((s) => s.redoStack);
  const toJSON = useFlowStore((s) => s.toJSON);
  const selectedNodeId = useFlowStore((s) => s.selectedNodeId);
  const loadFlow = useFlowStore((s) => s.loadFlow);

  useEffect(() => {
    async function fetchFlow() {
      if (!id || id === 'new') {
        setLoading(false);
        return;
      }
      try {
        const data = await flowApi.getFlowById(id);
        loadFlow(data.nodes || [], data.edges || [], {
          id: data._id,
          name: data.name,
          status: data.status
        });
      } catch (error) {
        console.error('Failed to load flow', error);
        message.error('Failed to load flow');
      } finally {
        setLoading(false);
      }
    }
    fetchFlow();
  }, [id, loadFlow]);

  const handleSave = useCallback(async () => {
    try {
      const data = toJSON() as any;
      console.log('[FlowBuilder] Save payload:', data);
      
      let savedFlow;
      if (data.id) {
        savedFlow = await flowApi.updateFlow(data.id, data);
        message.success('Flow updated successfully!');
      } else {
        savedFlow = await flowApi.createFlow(data);
        setFlowMeta({ id: savedFlow._id });
        navigate(`/flows/${savedFlow._id}`, { replace: true });
        message.success('Flow created successfully!');
      }
    } catch (error) {
      console.error('Failed to save flow', error);
      message.error('Failed to save flow. Check console.');
    }
  }, [toJSON, setFlowMeta]);

  const handleExport = useCallback(() => {
    const data = toJSON();
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${flowMeta.name.replace(/\s+/g, '_')}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }, [toJSON, flowMeta.name]);

  if (loading) {
    return <div className="p-8 text-center text-gray-500 font-medium">Loading flow...</div>;
  }

  return (
    <ReactFlowProvider>
      <div className="h-[calc(100vh-64px)] flex flex-col bg-gray-50">
        {/* Toolbar */}
        <div className="h-14 bg-white border-b border-gray-200 px-4 flex items-center justify-between shrink-0 z-10">
          {/* Left */}
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-[#25D366]/10 flex items-center justify-center">
                <span className="text-lg">🔀</span>
              </div>
              <input
                type="text"
                value={flowMeta.name}
                onChange={(e) => setFlowMeta({ name: e.target.value })}
                className="text-sm font-semibold text-gray-800 bg-transparent border-none outline-none focus:ring-0 w-48 hover:bg-gray-50 px-2 py-1 rounded-lg transition-colors"
                placeholder="Flow name..."
              />
            </div>

            {/* Status badge - Clickable to toggle */}
            <span 
              onClick={() => {
                const nextStatus = flowMeta.status === 'active' ? 'inactive' : 'active';
                setFlowMeta({ status: nextStatus });
                message.info(`Status changed to ${nextStatus}. Remember to save!`);
              }}
              className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider cursor-pointer hover:opacity-80 transition-opacity ${
              flowMeta.status === 'active'
                ? 'bg-green-100 text-green-700'
                : flowMeta.status === 'inactive'
                ? 'bg-red-100 text-red-700'
                : 'bg-amber-100 text-amber-700'
            }`}>
              {flowMeta.status}
            </span>
          </div>

          {/* Center actions */}
          <div className="flex items-center gap-1.5">
            <button
              onClick={undo}
              disabled={undoStack.length === 0}
              className="w-8 h-8 rounded-lg flex items-center justify-center text-gray-500 hover:bg-gray-100 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
              title="Undo (Ctrl+Z)"
            >
              ↩
            </button>
            <button
              onClick={redo}
              disabled={redoStack.length === 0}
              className="w-8 h-8 rounded-lg flex items-center justify-center text-gray-500 hover:bg-gray-100 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
              title="Redo (Ctrl+Y)"
            >
              ↪
            </button>
            <div className="w-px h-5 bg-gray-200 mx-1" />
            <button
              onClick={() => setShowTemplates(true)}
              className="px-3 py-1.5 rounded-lg text-xs font-medium text-gray-500 hover:bg-gray-100 transition-colors"
            >
              📦 Templates
            </button>
            <button
              onClick={() => setShowPreview(!showPreview)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                showPreview ? 'bg-[#25D366]/10 text-[#25D366]' : 'text-gray-500 hover:bg-gray-100'
              }`}
            >
              📱 Preview
            </button>
          </div>

          {/* Right actions */}
          <div className="flex items-center gap-2">
            <button
              onClick={handleExport}
              className="px-3 py-1.5 text-xs font-medium text-gray-600 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
            >
              ⬇ Export
            </button>
            <button
              onClick={handleSave}
              className="px-4 py-1.5 text-xs font-semibold text-white bg-[#25D366] hover:bg-[#1ea855] rounded-lg transition-colors shadow-sm"
            >
              💾 Save Flow
            </button>
          </div>
        </div>

        {/* Main area */}
        <div className="flex-1 flex overflow-hidden relative">
          {/* Left sidebar — Node Palette */}
          <NodePalette
            collapsed={sidebarCollapsed}
            onToggle={() => setSidebarCollapsed(!sidebarCollapsed)}
          />

          {/* Canvas */}
          <FlowCanvas />

          {/* Right panel — Node Editor (when a node is selected) */}
          {selectedNodeId && <NodeEditor />}

          {/* Phone Preview Drawer */}
          <PhonePreview isOpen={showPreview} onClose={() => setShowPreview(false)} />
        </div>

        {/* Template Gallery Modal */}
        {showTemplates && <TemplateGallery onClose={() => setShowTemplates(false)} />}
      </div>
    </ReactFlowProvider>
  );
}
