export interface PartnerSummary {
  id: string;
  name: string;
  email: string;
  commissionRate: number;
  referralCode: string;
  referralLink: string;
  createdAt: string;
}

export interface PartnerCustomer {
  id: string;
  businessName: string;
  email: string;
  plan: string;
  createdAt: string;
}

export interface PartnerCommissionCustomer {
  id: string;
  businessName: string;
  email: string;
  plan: string;
}

export interface PartnerCommission {
  id: string;
  amount: number;
  createdAt: string;
  customer: PartnerCommissionCustomer | null;
}

export interface PartnerWithdrawRequest {
  id: string;
  amount: number;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
}

export interface PartnerDashboard {
  partner: PartnerSummary;
  totalCustomers: number;
  totalRevenue: number;
  walletBalance: number;
  withdrawableAmount: number;
  pendingWithdrawals: number;
  recentCustomers: PartnerCustomer[];
  recentWithdrawRequests: PartnerWithdrawRequest[];
}

export interface ApiEnvelope<T> {
  status: string;
  message: string;
  data: T;
}

// ── Tenant Management Types ──

export interface Tenant {
  _id: string;
  partnerId: string;
  name: string;
  slug: string;
  email: string;
  phone?: string;
  status: 'active' | 'suspended' | 'pending';
  settings: {
    timezone: string;
    language: string;
    businessType?: string;
  };
  rateLimits: {
    messagesPerMinute: number;
    messagesPerDay: number;
  };
  metadata: Record<string, unknown>;
  createdAt: string;
  updatedAt: string;
}

export interface TenantWhatsAppAccount {
  _id: string;
  tenantId: string;
  wabaId: string;
  businessName: string;
  accessToken: string;
  credentialSource: 'own' | 'managed';
  status: 'connected' | 'disconnected' | 'pending';
  phoneNumbers: Array<{
    phoneNumberId: string;
    displayNumber: string;
    qualityRating: string;
    status: string;
    isDefault: boolean;
  }>;
  createdAt: string;
  updatedAt: string;
}

export interface TenantListResponse {
  tenants: Tenant[];
  total: number;
  page: number;
  limit: number;
  pages: number;
}

export interface CreateTenantPayload {
  name: string;
  email: string;
  phone?: string;
  settings?: Partial<Tenant['settings']>;
  rateLimits?: Partial<Tenant['rateLimits']>;
}

export interface LinkWhatsAppPayload {
  wabaId: string;
  businessName: string;
  accessToken: string;
  credentialSource: 'own' | 'managed';
  webhookVerifyToken?: string;
  phoneNumbers?: Array<{ phoneNumberId: string; displayNumber: string }>;
}

