import { useState } from 'react';
import { Key, Copy, Check, Eye, EyeOff, AlertTriangle } from 'lucide-react';
import { useGenerateApiKey } from '../hooks/useTenant';

export default function PartnerApiKeyPage() {
  const generateMutation = useGenerateApiKey();
  const [apiKey, setApiKey] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [showKey, setShowKey] = useState(false);

  const handleGenerate = async () => {
    try {
      const result = await generateMutation.mutateAsync();
      setApiKey(result.apiKey);
      setShowKey(true);
      setCopied(false);
    } catch (err) {
      console.error('Generate API key error:', err);
    }
  };

  const handleCopy = async () => {
    if (apiKey) {
      await navigator.clipboard.writeText(apiKey);
      setCopied(true);
      setTimeout(() => setCopied(false), 3000);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <section className="rounded-xl border border-slate-200 bg-white px-6 py-6 shadow-sm">
        <p className="text-xs font-bold uppercase tracking-wider text-slate-400">Developer</p>
        <h2 className="mt-2 text-2xl font-bold tracking-tight text-slate-900">API Key Management</h2>
        <p className="mt-2 max-w-2xl text-sm font-medium text-slate-600">
          Generate an API key to authenticate requests to our Headless V1 API. Pass this key in the
          <code className="mx-1 rounded bg-slate-100 px-2 py-0.5 text-xs font-bold font-mono text-indigo-600">x-api-key</code>
          header.
        </p>
      </section>

      {/* Key generation card */}
      <section className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
            <Key className="h-5 w-5" />
          </div>
          <div>
            <h3 className="font-bold text-slate-900">Partner API Key</h3>
            <p className="text-sm font-medium text-slate-500">Used for server-to-server integration</p>
          </div>
        </div>

        {!apiKey ? (
          <div className="mt-6">
            <div className="rounded-lg border border-amber-200 bg-amber-50 p-4">
              <div className="flex items-start gap-2">
                <AlertTriangle className="mt-0.5 h-4 w-4 flex-shrink-0 text-amber-600" />
                <div className="text-sm text-amber-800">
                  <p className="font-bold">Important</p>
                  <p className="mt-1 font-medium">
                    Generating a new API key will invalidate any existing key. Store it securely immediately.
                  </p>
                </div>
              </div>
            </div>
            <button
              id="generate-api-key-btn"
              onClick={handleGenerate}
              disabled={generateMutation.isPending}
              className="mt-4 rounded-lg bg-slate-900 px-6 py-2.5 text-sm font-bold text-white transition hover:bg-slate-800 disabled:opacity-60"
            >
              {generateMutation.isPending ? 'Generating...' : 'Generate New API Key'}
            </button>
          </div>
        ) : (
          <div className="mt-6 space-y-4">
            <div className="rounded-lg border border-emerald-200 bg-emerald-50 p-4">
              <p className="text-sm font-bold text-emerald-800">
                ✓ API key generated. Copy now — it won't be shown again.
              </p>
            </div>

            <div className="flex items-center gap-2 rounded-lg border border-slate-200 bg-slate-50 p-3">
              <code className="flex-1 break-all font-bold font-mono text-sm text-slate-800">
                {showKey ? apiKey : '•'.repeat(48)}
              </code>
              <button
                onClick={() => setShowKey(!showKey)}
                className="rounded-lg p-2 text-slate-400 transition hover:bg-slate-200 hover:text-slate-600"
                title={showKey ? 'Hide key' : 'Show key'}
              >
                {showKey ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
              <button
                onClick={handleCopy}
                className="rounded-lg p-2 text-slate-400 transition hover:bg-slate-200 hover:text-slate-600"
                title="Copy to clipboard"
              >
                {copied ? <Check className="h-4 w-4 text-emerald-500" /> : <Copy className="h-4 w-4" />}
              </button>
            </div>
          </div>
        )}

        {generateMutation.isError && (
          <div className="mt-4 rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-700">
            {(generateMutation.error as any)?.response?.data?.message || 'Failed to generate API key'}
          </div>
        )}
      </section>

      {/* Usage guide */}
      <section className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
        <h3 className="font-bold text-slate-900">Quick Start</h3>
        <p className="mt-1 text-sm font-medium text-slate-500">Integrate in 3 simple steps:</p>

        <div className="mt-4 space-y-4">
          {[
            {
              step: '1',
              title: 'Create a tenant',
              language: 'bash',
              code: `curl -X POST /api/v1/tenants \\
  -H "x-api-key: YOUR_API_KEY" \\
  -d '{"name": "Acme Rentals", "slug": "acme"}'`,
            },
            {
              step: '2',
              title: 'Set Webhook URL',
              language: 'bash',
              code: `curl -X PUT /api/v1/partner/settings \\
  -H "Authorization: Bearer <JWT>" \\
  -d '{"webhookUrl": "https://yoursite.com/hook"}'`,
            },
            {
              step: '3',
              title: 'Send a message',
              language: 'bash',
              code: `curl -X POST /api/v1/messages \\
  -H "x-api-key: YOUR_API_KEY" \\
  -H "x-tenant-id: acme" \\
  -d '{"to": "123...", "type": "text", "text": {"body": "Hi!"}}'`,
            },
          ].map(({ step, title, code }) => (
            <div key={step} className="rounded-lg border border-slate-100 bg-slate-50 p-4">
              <div className="flex items-center gap-2">
                <span className="flex h-5 w-5 items-center justify-center rounded-full bg-slate-900 text-[10px] font-bold text-white">
                  {step}
                </span>
                <span className="text-sm font-bold text-slate-900">{title}</span>
              </div>
              <pre className="mt-3 overflow-x-auto rounded-lg bg-slate-900 p-4 text-[11px] leading-relaxed text-slate-300">
                {code}
              </pre>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
