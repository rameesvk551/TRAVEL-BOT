import { useState } from 'react';
import {
  Building2,
  Plus,
  Search,
  Phone,
  Mail,
  MoreVertical,
  Pause,
  Play,
  MessagesSquare,
  Wifi,
} from 'lucide-react';
import { useTenants, useCreateTenant, useDeactivateTenant, useUpdateTenant } from '../hooks/useTenant';
import { PartnerLoadingState } from '../components/PartnerLoadingState';
import { PartnerErrorState } from '../components/PartnerErrorState';
import type { CreateTenantPayload } from '../types';

const statusConfig: Record<string, { bg: string; text: string; dot: string; label: string }> = {
  active: { bg: 'bg-emerald-50', text: 'text-emerald-700', dot: 'bg-emerald-500', label: 'Active' },
  suspended: { bg: 'bg-red-50', text: 'text-red-700', dot: 'bg-red-500', label: 'Suspended' },
  pending: { bg: 'bg-amber-50', text: 'text-amber-700', dot: 'bg-amber-500', label: 'Pending' },
};

export default function PartnerTenantsPage() {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('');
  const [page, setPage] = useState(1);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [actionMenuId, setActionMenuId] = useState<string | null>(null);

  const tenantsQuery = useTenants({ search: search || undefined, status: statusFilter || undefined, page });
  const deactivateMutation = useDeactivateTenant();
  const reactivateMutation = useUpdateTenant();

  const tenants = tenantsQuery.data?.tenants || [];
  const total = tenantsQuery.data?.total || 0;
  const pages = tenantsQuery.data?.pages || 1;

  const handleDeactivate = async (slug: string) => {
    setActionMenuId(null);
    await deactivateMutation.mutateAsync(slug);
  };

  const handleReactivate = async (slug: string) => {
    setActionMenuId(null);
    await reactivateMutation.mutateAsync({ tenantId: slug, updates: { status: 'active' } });
  };

  if (tenantsQuery.isLoading && !tenantsQuery.data) {
    return <PartnerLoadingState title="Loading tenants" />;
  }

  if (tenantsQuery.isError) {
    return <PartnerErrorState title="Unable to load tenants" description="Check your partner context." />;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <section className="rounded-xl border border-slate-200 bg-white px-6 py-6 shadow-sm">
        <p className="text-xs font-bold uppercase tracking-wider text-slate-400">Tenant Management</p>
        <div className="mt-2 flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <h2 className="text-2xl font-bold tracking-tight text-slate-900">
              Customer Workspaces
            </h2>
            <p className="mt-1 text-sm font-medium text-slate-600">
              Manage isolated WhatsApp Business environments for your clients.
            </p>
          </div>
          <button
            id="create-tenant-btn"
            onClick={() => setShowCreateModal(true)}
            className="flex items-center gap-2 rounded-lg bg-slate-900 px-5 py-2.5 text-sm font-bold text-white transition hover:bg-slate-800"
          >
            <Plus className="h-4 w-4" />
            Add Tenant
          </button>
        </div>
      </section>

      {/* Filters */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <input
            id="tenant-search"
            type="text"
            placeholder="Search by name, email, or ID..."
            value={search}
            onChange={(e) => { setSearch(e.target.value); setPage(1); }}
            className="w-full rounded-lg border border-slate-200 bg-white py-2.5 pl-11 pr-4 text-sm font-medium text-slate-900 placeholder-slate-400 outline-none transition focus:border-indigo-400"
          />
        </div>
        <div className="flex gap-2">
          {['', 'active', 'suspended', 'pending'].map((s) => (
            <button
              key={s}
              onClick={() => { setStatusFilter(s); setPage(1); }}
              className={`rounded-lg px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider transition ${
                statusFilter === s
                  ? 'bg-slate-900 text-white'
                  : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
              }`}
            >
              {s || 'All Status'}
            </button>
          ))}
        </div>
      </div>

      {/* Stats row */}
      <div className="grid gap-4 sm:grid-cols-3">
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
          <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Total Tenants</p>
          <p className="mt-1 text-2xl font-bold tracking-tight text-slate-900">{total}</p>
        </div>
        <div className="rounded-xl border border-emerald-100 bg-emerald-50/30 p-5 shadow-sm">
          <p className="text-[10px] font-bold uppercase tracking-wider text-emerald-600">Active</p>
          <p className="mt-1 text-2xl font-bold tracking-tight text-emerald-700">
            {tenants.filter(t => t.status === 'active').length}
          </p>
        </div>
        <div className="rounded-xl border border-amber-100 bg-amber-50/30 p-5 shadow-sm">
          <p className="text-[10px] font-bold uppercase tracking-wider text-amber-600">Notice Required</p>
          <p className="mt-1 text-2xl font-bold tracking-tight text-amber-700">
            {tenants.filter(t => t.status !== 'active').length}
          </p>
        </div>
      </div>

      {/* Tenant cards grid */}
      {tenants.length === 0 ? (
        <div className="rounded-xl border border-dashed border-slate-300 bg-white px-8 py-16 text-center">
          <Building2 className="mx-auto h-12 w-12 text-slate-200" />
          <h3 className="mt-4 text-lg font-bold text-slate-900">No tenants yet</h3>
          <p className="mx-auto mt-2 max-w-md text-sm font-medium text-slate-500">
            Create an isolated workspace to start managing client business flows.
          </p>
          <button
            onClick={() => setShowCreateModal(true)}
            className="mt-6 inline-flex items-center gap-2 rounded-lg bg-slate-900 px-6 py-2.5 text-sm font-bold text-white transition hover:bg-slate-800"
          >
            <Plus className="h-4 w-4" />
            Create First Tenant
          </button>
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 2xl:grid-cols-3">
          {tenants.map((tenant) => {
            const sc = statusConfig[tenant.status] || statusConfig.pending;
            return (
              <div
                key={tenant._id}
                className="group relative rounded-xl border border-slate-200 bg-white p-5 shadow-sm transition hover:border-indigo-400"
              >
                {/* Header */}
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-slate-50 text-slate-400">
                      <Building2 className="h-4 w-4" />
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-slate-900">{tenant.name}</h3>
                      <p className="text-[10px] font-bold text-indigo-600 family-mono">{tenant.slug}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`rounded-md px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider ${sc.bg} ${sc.text}`}>
                      {sc.label}
                    </span>
                    <div className="relative">
                      <button
                        onClick={() => setActionMenuId(actionMenuId === tenant.slug ? null : tenant.slug)}
                        className="rounded-lg p-1 text-slate-400 transition hover:bg-slate-100 hover:text-slate-600"
                      >
                        <MoreVertical className="h-4 w-4" />
                      </button>
                      {actionMenuId === tenant.slug && (
                        <div className="absolute right-0 top-8 z-10 w-40 rounded-xl border border-slate-200 bg-white p-1 shadow-lg">
                          {tenant.status === 'active' ? (
                            <button
                              onClick={() => handleDeactivate(tenant.slug)}
                              className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm text-red-600 hover:bg-red-50"
                            >
                              <Pause className="h-3.5 w-3.5" /> Suspend
                            </button>
                          ) : (
                            <button
                              onClick={() => handleReactivate(tenant.slug)}
                              className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm text-emerald-600 hover:bg-emerald-50"
                            >
                              <Play className="h-3.5 w-3.5" /> Reactivate
                            </button>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Details */}
                <div className="mt-4 space-y-2">
                  <div className="flex items-center gap-2 text-sm text-slate-500">
                    <Mail className="h-3.5 w-3.5 flex-shrink-0 text-slate-400" />
                    <span className="truncate">{tenant.email}</span>
                  </div>
                  {tenant.phone && (
                    <div className="flex items-center gap-2 text-sm text-slate-500">
                      <Phone className="h-3.5 w-3.5 flex-shrink-0 text-slate-400" />
                      <span>{tenant.phone}</span>
                    </div>
                  )}
                </div>

                {/* Footer */}
                <div className="mt-4 flex items-center justify-between border-t border-slate-100 pt-4 text-[11px] font-bold text-slate-400">
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-1">
                      <MessagesSquare className="h-3.5 w-3.5" />
                      <span>{tenant.rateLimits.messagesPerDay.toLocaleString()} cap</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Wifi className="h-3.5 w-3.5" />
                      <span>{tenant.settings.timezone}</span>
                    </div>
                  </div>
                  <span>
                    {new Date(tenant.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Pagination */}
      {pages > 1 && (
        <div className="flex items-center justify-center gap-2">
          <button
            disabled={page <= 1}
            onClick={() => setPage(page - 1)}
            className="rounded-lg border border-slate-200 bg-white px-4 py-2 text-xs font-bold text-slate-600 transition hover:bg-slate-50 disabled:opacity-40"
          >
            Previous
          </button>
          <span className="rounded-lg border border-slate-200 bg-white px-4 py-2 text-xs font-bold text-slate-900">
            {page} / {pages}
          </span>
          <button
            disabled={page >= pages}
            onClick={() => setPage(page + 1)}
            className="rounded-lg border border-slate-200 bg-white px-4 py-2 text-xs font-bold text-slate-600 transition hover:bg-slate-50 disabled:opacity-40"
          >
            Next
          </button>
        </div>
      )}

      {/* Create Tenant Modal */}
      {showCreateModal && (
        <CreateTenantModal onClose={() => setShowCreateModal(false)} />
      )}
    </div>
  );
}

// ── Create Tenant Modal ──

function CreateTenantModal({ onClose }: { onClose: () => void }) {
  const createMutation = useCreateTenant();
  const [form, setForm] = useState<CreateTenantPayload>({
    name: '',
    email: '',
    phone: '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await createMutation.mutateAsync(form);
      onClose();
    } catch (err: any) {
      console.error('Create tenant error:', err);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-sm" onClick={onClose}>
      <div
        className="w-full max-w-lg rounded-xl border border-slate-200 bg-white p-8 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <h2 className="text-xl font-bold tracking-tight text-slate-900">Create New Tenant</h2>
        <p className="mt-1 text-sm font-medium text-slate-600">
          Add an isolated workspace for a new client business.
        </p>

        <form onSubmit={handleSubmit} className="mt-6 space-y-4">
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-slate-400">Business Name</label>
            <input
              id="tenant-name"
              type="text"
              required
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              placeholder="Acme Rentals"
              className="mt-2 w-full rounded-lg border border-slate-200 bg-slate-50 px-4 py-2.5 text-sm font-bold text-slate-900 outline-none transition focus:border-indigo-400 focus:bg-white"
            />
          </div>

          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-slate-400">Admin Email</label>
            <input
              id="tenant-email"
              type="email"
              required
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              placeholder="admin@acme.com"
              className="mt-2 w-full rounded-lg border border-slate-200 bg-slate-50 px-4 py-2.5 text-sm font-bold text-slate-900 outline-none transition focus:border-indigo-400 focus:bg-white"
            />
          </div>

          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-slate-400">Contact Phone</label>
            <input
              id="tenant-phone"
              type="tel"
              value={form.phone}
              onChange={(e) => setForm({ ...form, phone: e.target.value })}
              placeholder="+91..."
              className="mt-2 w-full rounded-lg border border-slate-200 bg-slate-50 px-4 py-2.5 text-sm font-bold text-slate-900 outline-none transition focus:border-indigo-400 focus:bg-white"
            />
          </div>

          {createMutation.isError && (
            <div className="rounded-lg border border-red-200 bg-red-50 p-3 text-xs font-bold text-red-700">
              ✕ {(createMutation.error as any)?.response?.data?.message || 'Failed to create tenant'}
            </div>
          )}

          <div className="flex items-center justify-end gap-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg px-5 py-2 text-sm font-bold text-slate-500 transition hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              id="create-tenant-submit"
              type="submit"
              disabled={createMutation.isPending}
              className="rounded-lg bg-slate-900 px-6 py-2.5 text-sm font-bold text-white transition hover:bg-slate-800 disabled:opacity-60"
            >
              {createMutation.isPending ? 'Working...' : 'Create Tenant'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
