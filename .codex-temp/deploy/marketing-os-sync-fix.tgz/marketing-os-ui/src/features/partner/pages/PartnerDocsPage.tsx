import { Typography, Card, Divider, Tag, Space, Breadcrumb, Button, message } from 'antd';
import { 
  BookOutlined, 
  KeyOutlined, 
  ApiOutlined, 
  SendOutlined, 
  SyncOutlined,
  CopyOutlined,
  QuestionCircleOutlined
} from '@ant-design/icons';

const { Title, Paragraph, Text } = Typography;

const CodeBlock = ({ code }: { code: string }) => {
  const copyToClipboard = () => {
    navigator.clipboard.writeText(code);
    message.success('Copied to clipboard');
  };

  return (
    <div style={{ position: 'relative', marginBottom: 24 }}>
      <Button 
        size="small"
        icon={<CopyOutlined />} 
        style={{ 
          position: 'absolute', 
          right: 8, 
          top: 8, 
          zIndex: 10,
          opacity: 0.6
        }}
        onClick={copyToClipboard}
      />
      <pre style={{ 
        background: '#f8fafc', 
        padding: '16px', 
        borderRadius: '8px', 
        color: '#1e293b',
        overflow: 'auto',
        fontSize: '13px',
        border: '1px solid #e2e8f0',
        fontFamily: "'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace"
      }}>
        <code>{code}</code>
      </pre>
    </div>
  );
};

export function PartnerDocsPage() {
  return (
    <div style={{ padding: '24px', background: '#fff', borderRadius: '16px', minHeight: '100%' }}>
      <div style={{ marginBottom: 32 }}>
        <Breadcrumb 
          items={[
            { title: 'Partner Dashboard', href: '/partner' },
            { title: 'API Documentation' },
          ]} 
          style={{ marginBottom: 8 }}
        />
        <Title level={2} style={{ margin: 0, fontWeight: 700 }}>
          Partner API Documentation
        </Title>
        <Paragraph type="secondary" style={{ fontSize: 16 }}>
          Official technical guide for integrating with the Marketing OS WhatsApp infrastructure.
        </Paragraph>
      </div>

      <div style={{ maxWidth: 800 }}>
        <section id="introduction">
          <Title level={4}>Introduction</Title>
          <Paragraph style={{ fontSize: 15, color: '#334155' }}>
            The Partner API allows you to build custom WhatsApp solutions on top of our scalable infrastructure. 
            This guide covers tenant provisioning, master authentication, and real-time webhook delivery.
          </Paragraph>
        </section>

        <Divider />

        <section id="concepts">
          <Title level={4}>
            <Space><BookOutlined /> Core Concepts</Space>
          </Title>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginTop: 16 }}>
            <Card size="small" title="x-api-key" headStyle={{ borderBottom: 'none', padding: '0 12px' }} style={{ background: '#fefce8', border: '1px solid #fef08a' }}>
              <Text type="secondary">Your master key. Required for all requests. Never expose on frontend.</Text>
            </Card>
            <Card size="small" title="x-tenant-id" headStyle={{ borderBottom: 'none', padding: '0 12px' }} style={{ background: '#f0f9ff', border: '1px solid #bae6fd' }}>
              <Text type="secondary">Identify which customer (tenant) you are acting on behalf of.</Text>
            </Card>
          </div>
        </section>

        <Divider />

        <section id="auth">
          <Title level={4}>
            <Space><KeyOutlined /> 1. Authentication</Space>
          </Title>
          <Paragraph>Pass your API Key in the custom header for every request.</Paragraph>
          <CodeBlock code="x-api-key: YOUR_MASTER_SECRET_KEY" />
        </section>

        <Divider />

        <section id="tenants">
          <Title level={4}>
            <Space><ApiOutlined /> 2. Creating Tenants</Space>
          </Title>
          <Paragraph>Create a new workspace for your customer.</Paragraph>
          <div style={{ marginBottom: 12 }}>
            <Tag color="blue">POST</Tag> <Text code>/api/v1/tenants</Text>
          </div>
          <CodeBlock code={JSON.stringify({
  "name": "Jane's Coffee Shop",
  "slug": "janes-coffee",
  "plan": "starter"
}, null, 2)} />
        </section>

        <Divider />

        <section id="messaging">
          <Title level={4}>
            <Space><SendOutlined /> 3. Sending Messages</Space>
          </Title>
          <Paragraph>Send WhatsApp messages using the tenant context.</Paragraph>
          <div style={{ marginBottom: 12 }}>
            <Tag color="green">POST</Tag> <Text code>/api/v1/messages</Text>
          </div>
          <CodeBlock code={JSON.stringify({
  "to": "1234567890",
  "type": "text",
  "text": { "body": "Hello from your custom API!" }
}, null, 2)} />
        </section>

        <Divider />

        <section id="webhooks">
          <Title level={4}>
            <Space><SyncOutlined /> 4. Webhook Events</Space>
          </Title>
          <Paragraph>Register a URL in your settings to receive incoming data updates.</Paragraph>
          <Text strong>Event Payload Example:</Text>
          <div style={{ marginTop: 12 }}>
            <CodeBlock code={JSON.stringify({
  "tenantId": "janes-coffee",
  "eventType": "message",
  "data": {
    "senderPhone": "1234567890",
    "messageType": "TEXT",
    "textContent": { "body": "I have a question." }
  }
}, null, 2)} />
          </div>
        </section>

        <Divider />

        <section id="support" style={{ textAlign: 'center', padding: '40px 0' }}>
          <QuestionCircleOutlined style={{ fontSize: 32, color: '#6366f1', marginBottom: 16 }} />
          <Title level={4}>Still have questions?</Title>
          <Paragraph type="secondary">
            Our technical support team is available 24/7 via the dashboard chat for all partners.
          </Paragraph>
        </section>
      </div>
    </div>
  );
}

export default PartnerDocsPage;
