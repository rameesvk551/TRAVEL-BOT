import { useState } from 'react';
import { ArrowRight, Landmark, Wallet } from 'lucide-react';
import { PartnerErrorState } from '../components/PartnerErrorState';
import { PartnerLoadingState } from '../components/PartnerLoadingState';
import { PartnerTableCard } from '../components/PartnerTableCard';
import { useCreatePartnerWithdrawRequest, usePartnerDashboard } from '../hooks/usePartner';
import { formatCurrency, formatDate } from '../utils/format';

const getMutationErrorMessage = (error: unknown) => {
  const responseError = error as {
    response?: {
      data?: {
        message?: string;
      };
    };
  };

  return responseError.response?.data?.message || 'Unable to create the withdraw request right now.';
};

export default function PartnerWithdrawPage() {
  const [amount, setAmount] = useState('');
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const dashboardQuery = usePartnerDashboard();
  const withdrawMutation = useCreatePartnerWithdrawRequest();

  if (dashboardQuery.isLoading) {
    return <PartnerLoadingState title="Loading withdrawal workspace" />;
  }

  if (dashboardQuery.isError || !dashboardQuery.data) {
    return (
      <PartnerErrorState
        title="Unable to load withdrawal data"
        description="The payout workspace could not be loaded for the current partner context."
      />
    );
  }

  const dashboard = dashboardQuery.data;

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setSuccessMessage(null);

    await withdrawMutation.mutateAsync(Number(amount));
    setSuccessMessage('Withdrawal request created. An admin can approve it manually from the back office.');
    setAmount('');
  };

  return (
    <div className="space-y-6">
      <section className="grid gap-4 lg:grid-cols-2">
        <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
          <div className="flex items-center gap-4">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-slate-50 text-indigo-600">
              <Wallet className="h-5 w-5" />
            </div>
            <div>
              <p className="text-xs font-bold uppercase tracking-wider text-slate-400">Available to Withdraw</p>
              <p className="text-2xl font-bold tracking-tight text-slate-900">{formatCurrency(dashboard.withdrawableAmount)}</p>
            </div>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
          <div className="flex items-center gap-4">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-slate-50 text-slate-400">
              <Landmark className="h-5 w-5" />
            </div>
            <div>
              <p className="text-xs font-bold uppercase tracking-wider text-slate-400">Pending Review</p>
              <p className="text-2xl font-bold tracking-tight text-slate-900">{formatCurrency(dashboard.pendingWithdrawals)}</p>
            </div>
          </div>
        </div>
      </section>

      <div className="grid gap-6 xl:grid-cols-[minmax(0,0.95fr)_minmax(0,1.25fr)]">
        <section className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
          <p className="text-xs font-bold uppercase tracking-wider text-slate-400">New Request</p>
          <h2 className="mt-2 text-xl font-bold tracking-tight text-slate-900">Request Payout</h2>
          <p className="mt-2 text-sm font-medium text-slate-600">
            Submit an amount to be reviewed by the administration team.
          </p>

          <form className="mt-6 space-y-4" onSubmit={handleSubmit}>
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-slate-400">Withdraw Amount</label>
              <input
                type="number"
                min="0"
                step="0.01"
                value={amount}
                onChange={(event) => setAmount(event.target.value)}
                placeholder="0.00"
                className="mt-2 w-full rounded-lg border border-slate-200 bg-slate-50 px-4 py-2.5 text-sm font-bold text-slate-900 outline-none transition focus:border-indigo-400 focus:bg-white"
                required
              />
            </div>

            <div className="rounded-lg border border-slate-100 bg-slate-50 px-4 py-3 text-xs font-bold text-slate-500">
              Maximum available: <span className="text-slate-900">{formatCurrency(dashboard.withdrawableAmount)}</span>
            </div>

            {successMessage ? (
              <div className="rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3 text-xs font-bold text-emerald-800">
                ✓ {successMessage}
              </div>
            ) : null}

            {withdrawMutation.isError ? (
              <div className="rounded-lg border border-rose-200 bg-rose-50 px-4 py-3 text-xs font-bold text-rose-800">
                ✕ {getMutationErrorMessage(withdrawMutation.error)}
              </div>
            ) : null}

            <button
              type="submit"
              disabled={withdrawMutation.isPending}
              className="inline-flex w-full items-center justify-center gap-2 rounded-lg bg-slate-900 px-4 py-3 text-sm font-bold text-white transition hover:bg-slate-800 disabled:opacity-60"
            >
              {withdrawMutation.isPending ? 'Submitting...' : 'Submit Request'}
              {!withdrawMutation.isPending && <ArrowRight className="h-4 w-4" />}
            </button>
          </form>
        </section>

        <PartnerTableCard
          title="Recent Requests"
          description="Keep an eye on your latest payout submissions and their approval status."
          rows={dashboard.recentWithdrawRequests}
          emptyTitle="No withdrawal requests yet"
          emptyDescription="Your payout requests will appear here after you create one."
          columns={[
            {
              header: 'Amount',
              render: (request) => <span className="font-semibold text-slate-900">{formatCurrency(request.amount)}</span>,
            },
            {
              header: 'Status',
              render: (request) => (
                <span className="rounded bg-slate-100 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-slate-600">
                  {request.status}
                </span>
              ),
            },
            {
              header: 'Created At',
              render: (request) => <span className="font-medium text-slate-700">{formatDate(request.createdAt)}</span>,
            },
          ]}
        />
      </div>
    </div>
  );
}
