import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, Button, Input, Form, Typography, Result, Divider, message } from 'antd';
import { RocketOutlined, DollarOutlined, UserAddOutlined, TeamOutlined } from '@ant-design/icons';
import { useAuth } from '../../../context/AuthContext';
import { useJoinPartner } from '../hooks/usePartner';

const { Title, Text, Paragraph } = Typography;

export function BecomePartnerPage() {
    const { user, updateUser } = useAuth();
    const navigate = useNavigate();
    const [form] = Form.useForm();
    const joinPartner = useJoinPartner();
    const [success, setSuccess] = useState(false);

    if (user?.partnerId && !success) {
        navigate('/partner');
        return null;
    }

    const onFinish = async (values: { businessName: string }) => {
        try {
            const data = await joinPartner.mutateAsync(values.businessName);
            if (user) {
                updateUser({ ...user, partnerId: data.id });
            }
            setSuccess(true);
        } catch (error: any) {
            message.error(error?.response?.data?.message || 'Failed to join the partner program');
        }
    };

    if (success) {
        return (
            <div style={{ maxWidth: 640, margin: '80px auto', padding: '0 24px', textAlign: 'center' }}>
                <Result
                    status="success"
                    title={<span style={{ fontWeight: 800, color: '#0f172a' }}>Registration Complete</span>}
                    subTitle={<span style={{ fontWeight: 500, color: '#475569' }}>Your partner account is now active. You can start managing tenants and earning commissions immediately.</span>}
                />
                <Button 
                    type="primary" 
                    size="large"
                    onClick={() => { window.location.href = '/partner'; }}
                    style={{ background: '#0f172a', borderRadius: 8, height: 48, padding: '0 32px', fontWeight: 700 }}
                >
                    Open Partner Dashboard
                </Button>
            </div>
        );
    }

    return (
        <div style={{ maxWidth: 800, margin: '60px auto', padding: '0 24px' }}>
            <div style={{ textAlign: 'center', marginBottom: 48 }}>
                <div 
                    style={{ 
                        width: 56, 
                        height: 56, 
                        background: '#f1f5f9',
                        borderRadius: 12,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        margin: '0 auto 24px',
                        border: '1px solid #e2e8f0'
                    }}
                >
                    <RocketOutlined style={{ fontSize: 24, color: '#4f46e5' }} />
                </div>
                <Title level={2} style={{ color: '#0f172a', marginBottom: 16, fontSize: 32, fontWeight: 800 }}>
                    Partner Program
                </Title>
                <Paragraph style={{ color: '#475569', fontSize: 16, maxWidth: 500, margin: '0 auto', fontWeight: 500 }}>
                    Earn 50% recurring commissions for every business you refer to our headless WhatsApp marketing platform.
                </Paragraph>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24, marginBottom: 40 }}>
                <Card 
                    variant="borderless" 
                    style={{ 
                        background: '#fff', 
                        border: '1px solid #e2e8f0',
                        borderRadius: 12,
                        boxShadow: '0 1px 2px rgba(0,0,0,0.05)'
                    }}
                >
                    <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 12 }}>
                        <DollarOutlined style={{ fontSize: 20, color: '#10b981' }} />
                        <Title level={5} style={{ color: '#0f172a', margin: 0, fontWeight: 700 }}>50% Commission</Title>
                    </div>
                    <Text style={{ color: '#475569', fontWeight: 500 }}>Recurring revenue share on all subscription payments.</Text>
                </Card>
                <Card 
                    variant="borderless" 
                    style={{ 
                        background: '#fff', 
                        border: '1px solid #e2e8f0',
                        borderRadius: 12,
                        boxShadow: '0 1px 2px rgba(0,0,0,0.05)'
                    }}
                >
                    <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 12 }}>
                        <TeamOutlined style={{ fontSize: 20, color: '#f59e0b' }} />
                        <Title level={5} style={{ color: '#0f172a', margin: 0, fontWeight: 700 }}>Unlimited Scale</Title>
                    </div>
                    <Text style={{ color: '#475569', fontWeight: 500 }}>No limits on referred businesses or total earnings.</Text>
                </Card>
            </div>

            <Card
                variant="borderless"
                style={{
                    background: '#fff',
                    border: '1px solid #e2e8f0',
                    borderRadius: 12,
                    padding: 8
                }}
            >
                <Title level={4} style={{ color: '#0f172a', marginBottom: 4, fontWeight: 800 }}>Enrollment Form</Title>
                <Text style={{ color: '#475569', display: 'block', marginBottom: 24, fontWeight: 500 }}>
                    Enter your business details to activate your partner profile.
                </Text>

                <Form
                    form={form}
                    layout="vertical"
                    onFinish={onFinish}
                    initialValues={{ businessName: user?.name || '' }}
                    size="large"
                >
                    <Form.Item
                        name="businessName"
                        label={<span style={{ color: '#334155', fontWeight: 700 }}>Agency / Business Name</span>}
                        rules={[{ required: true, message: 'Required' }]}
                    >
                        <Input 
                            prefix={<UserAddOutlined style={{ color: '#94a3b8' }} />} 
                            placeholder="e.g. Acme Agency" 
                            style={{ 
                                borderRadius: 8,
                                fontWeight: 600
                            }} 
                        />
                    </Form.Item>

                    <Divider style={{ borderColor: '#f1f5f9' }} />

                    <Button
                        type="primary"
                        htmlType="submit"
                        loading={joinPartner.isPending}
                        block
                        style={{
                            height: 48,
                            fontSize: 16,
                            fontWeight: 700,
                            background: '#0f172a',
                            border: 'none',
                            borderRadius: 8
                        }}
                    >
                        Activate Partnership
                    </Button>
                </Form>
            </Card>
        </div>
    );
}

export default BecomePartnerPage;
