import { Outlet } from 'react-router-dom';

import { usePartnerDashboard } from '../hooks/usePartner';

export default function PartnerLayout() {
  const dashboardQuery = usePartnerDashboard();
  // const partner = dashboardQuery.data?.partner;
  const errorMessage = dashboardQuery.isError
    ? 'Partner data could not be resolved. Log in with a partner email or set localStorage.partnerId to a valid partner id.'
    : undefined;

  return (
    <div className="space-y-6">


      {errorMessage && (
        <div className="rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm font-medium text-amber-900">
          {errorMessage}
        </div>
      )}

      <div className="min-w-0">
        <Outlet />
      </div>
    </div>
  );
}
