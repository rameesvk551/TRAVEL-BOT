import { useState } from 'react';
import { Copy, Link2, Mail, Percent, Sparkles } from 'lucide-react';
import { PartnerErrorState } from '../components/PartnerErrorState';
import { PartnerLoadingState } from '../components/PartnerLoadingState';
import { usePartnerDashboard } from '../hooks/usePartner';
import { formatDate, formatPercent } from '../utils/format';

export default function PartnerSettingsPage() {
  const [copied, setCopied] = useState(false);
  const dashboardQuery = usePartnerDashboard();

  if (dashboardQuery.isLoading) {
    return <PartnerLoadingState title="Loading partner settings" />;
  }

  if (dashboardQuery.isError || !dashboardQuery.data) {
    return (
      <PartnerErrorState
        title="Unable to load partner settings"
        description="Partner identity details could not be loaded for the current workspace."
      />
    );
  }

  const partner = dashboardQuery.data.partner;

  const handleCopy = async () => {
    await navigator.clipboard.writeText(partner.referralLink);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1800);
  };

  return (
    <div className="space-y-6">
      <section className="rounded-xl border border-slate-200 bg-white px-6 py-6 shadow-sm">
        <p className="text-xs font-bold uppercase tracking-wider text-slate-400">Settings</p>
        <h2 className="mt-2 text-2xl font-bold tracking-tight text-slate-900">Partner Details</h2>
        <p className="mt-2 text-sm font-medium text-slate-600">
          Manage your partner profile and referral performance.
        </p>
      </section>

      <div className="grid gap-6 xl:grid-cols-2">
        <section className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
          <div className="space-y-4">
            <div className="flex items-start gap-4">
              <Mail className="mt-0.5 h-4 w-4 text-slate-400" />
              <div>
                <p className="text-xs font-bold uppercase tracking-wider text-slate-400">Email Address</p>
                <p className="mt-1 text-base font-bold text-slate-900">{partner.email}</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <Percent className="mt-0.5 h-4 w-4 text-slate-400" />
              <div>
                <p className="text-xs font-bold uppercase tracking-wider text-slate-400">Commission Rate</p>
                <p className="mt-1 text-base font-bold text-indigo-600">{formatPercent(partner.commissionRate)}</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <Sparkles className="mt-0.5 h-4 w-4 text-slate-400" />
              <div>
                <p className="text-xs font-bold uppercase tracking-wider text-slate-400">Join Date</p>
                <p className="mt-1 text-base font-bold text-slate-900">{formatDate(partner.createdAt)}</p>
              </div>
            </div>
          </div>
        </section>

        <section className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
          <div className="flex items-center gap-3">
            <Link2 className="h-4 w-4 text-slate-400" />
            <div>
              <p className="text-xs font-bold uppercase tracking-wider text-slate-400">Referral ID</p>
              <p className="mt-1 text-lg font-bold text-slate-900">{partner.referralCode}</p>
            </div>
          </div>

          <div className="mt-5 rounded-lg border border-slate-100 bg-slate-50 p-4 text-xs font-bold text-indigo-600 break-all family-mono">
            {partner.referralLink}
          </div>

          <button
            type="button"
            onClick={handleCopy}
            className="mt-4 inline-flex items-center gap-2 rounded-lg bg-slate-900 px-6 py-2.5 text-sm font-bold text-white transition hover:bg-slate-800"
          >
            <Copy className="h-4 w-4" />
            {copied ? 'Copied' : 'Copy referral link'}
          </button>
        </section>
      </div>
    </div>
  );
}
