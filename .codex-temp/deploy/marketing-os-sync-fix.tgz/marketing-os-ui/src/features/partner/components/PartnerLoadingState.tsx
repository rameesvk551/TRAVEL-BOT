interface PartnerLoadingStateProps {
  title: string;
}

export function PartnerLoadingState({ title }: PartnerLoadingStateProps) {
  return (
    <div className="space-y-6">
      <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
        <p className="text-sm font-bold text-slate-400">{title}</p>
        <div className="mt-5 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {Array.from({ length: 4 }).map((_, index) => (
            <div key={index} className="animate-pulse rounded-xl border border-slate-100 bg-slate-50 p-5">
              <div className="h-4 w-24 rounded bg-slate-200" />
              <div className="mt-4 h-8 w-28 rounded bg-slate-200" />
              <div className="mt-3 h-4 w-32 rounded bg-slate-200" />
            </div>
          ))}
        </div>
      </div>

      <div className="animate-pulse rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
        <div className="h-5 w-40 rounded bg-slate-200" />
        <div className="mt-3 h-4 w-64 rounded bg-slate-200" />
        <div className="mt-8 space-y-3">
          {Array.from({ length: 5 }).map((_, index) => (
            <div key={index} className="h-12 rounded-lg bg-slate-50" />
          ))}
        </div>
      </div>
    </div>
  );
}
