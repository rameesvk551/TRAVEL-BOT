interface PartnerErrorStateProps {
  title: string;
  description: string;
}

export function PartnerErrorState({ title, description }: PartnerErrorStateProps) {
  return (
    <div className="rounded-xl border border-rose-200 bg-rose-50 px-6 py-6 text-rose-900">
      <h3 className="text-lg font-bold">{title}</h3>
      <p className="mt-2 max-w-2xl text-sm font-medium text-rose-800">{description}</p>
    </div>
  );
}
