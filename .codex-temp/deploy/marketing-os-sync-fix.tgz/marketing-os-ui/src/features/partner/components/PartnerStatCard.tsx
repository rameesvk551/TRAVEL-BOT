import type { ReactNode } from 'react';

interface PartnerStatCardProps {
  label: string;
  value: string;
  hint: string;
  icon: ReactNode;
}

export function PartnerStatCard({ label, value, hint, icon }: PartnerStatCardProps) {
  return (
    <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-xs font-bold uppercase tracking-wider text-slate-500">{label}</p>
          <p className="mt-2 text-2xl font-bold tracking-tight text-slate-900">{value}</p>
          <p className="mt-1 text-sm font-medium text-slate-500">{hint}</p>
        </div>
        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-slate-50 text-indigo-600">
          {icon}
        </div>
      </div>
    </div>
  );
}
