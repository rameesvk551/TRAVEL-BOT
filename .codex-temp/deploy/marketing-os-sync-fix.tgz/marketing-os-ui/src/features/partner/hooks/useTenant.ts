import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { tenantService } from '../services/tenantService';
import type { CreateTenantPayload, LinkWhatsAppPayload } from '../types';

export function useTenants(filters?: { status?: string; search?: string; page?: number }) {
  return useQuery({
    queryKey: ['tenants', filters],
    queryFn: () => tenantService.listTenants(filters),
  });
}

export function useTenant(tenantId: string) {
  return useQuery({
    queryKey: ['tenant', tenantId],
    queryFn: () => tenantService.getTenant(tenantId),
    enabled: !!tenantId,
  });
}

export function useTenantWhatsApp(tenantId: string) {
  return useQuery({
    queryKey: ['tenant-whatsapp', tenantId],
    queryFn: () => tenantService.getWhatsApp(tenantId),
    enabled: !!tenantId,
  });
}

export function useCreateTenant() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (payload: CreateTenantPayload) => tenantService.createTenant(payload),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tenants'] });
    },
  });
}

export function useUpdateTenant() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ tenantId, updates }: { tenantId: string; updates: Partial<CreateTenantPayload> & { status?: string } }) =>
      tenantService.updateTenant(tenantId, updates),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tenants'] });
    },
  });
}

export function useDeactivateTenant() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (tenantId: string) => tenantService.deactivateTenant(tenantId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tenants'] });
    },
  });
}

export function useLinkWhatsApp() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ tenantId, payload }: { tenantId: string; payload: LinkWhatsAppPayload }) =>
      tenantService.linkWhatsApp(tenantId, payload),
    onSuccess: (_data, variables) => {
      queryClient.invalidateQueries({ queryKey: ['tenant-whatsapp', variables.tenantId] });
    },
  });
}

export function useGenerateApiKey() {
  return useMutation({
    mutationFn: () => tenantService.generateApiKey(),
  });
}
