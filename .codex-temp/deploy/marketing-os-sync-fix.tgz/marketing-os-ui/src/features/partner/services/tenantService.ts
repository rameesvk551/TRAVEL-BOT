import client from '../../../api/client';
import type {
  ApiEnvelope,
  Tenant,
  TenantListResponse,
  TenantWhatsAppAccount,
  CreateTenantPayload,
  LinkWhatsAppPayload,
} from '../types';

const getPartnerContext = () => {
  const storedUser = localStorage.getItem('user');
  if (storedUser) {
    try {
      const user = JSON.parse(storedUser);
      return user.partnerId ? { partnerId: user.partnerId } : undefined;
    } catch (e) {
      console.error('Failed to parse user for partner context', e);
    }
  }
  return undefined;
};

/**
 * Tenant management API service.
 * Uses the partner's JWT auth (existing axios interceptor sends Bearer token).
 */
export const tenantService = {
  async listTenants(params?: {
    status?: string;
    search?: string;
    page?: number;
    limit?: number;
  }): Promise<TenantListResponse> {
    const { data } = await client.get<ApiEnvelope<TenantListResponse>>('/partner/tenants', {
      params: { ...getPartnerContext(), ...params },
    });
    return data.data;
  },

  async getTenant(tenantId: string): Promise<Tenant> {
    const { data } = await client.get<ApiEnvelope<Tenant>>(`/partner/tenants/${tenantId}`, {
      params: getPartnerContext(),
    });
    return data.data;
  },

  async createTenant(payload: CreateTenantPayload): Promise<Tenant> {
    const { data } = await client.post<ApiEnvelope<Tenant>>('/partner/tenants', {
      ...payload,
      ...getPartnerContext(),
    });
    return data.data;
  },

  async updateTenant(tenantId: string, updates: Partial<CreateTenantPayload> & { status?: string }): Promise<Tenant> {
    const { data } = await client.put<ApiEnvelope<Tenant>>(`/partner/tenants/${tenantId}`, {
      ...updates,
      ...getPartnerContext(),
    });
    return data.data;
  },

  async deactivateTenant(tenantId: string): Promise<void> {
    await client.delete(`/partner/tenants/${tenantId}`, {
      params: getPartnerContext(),
    });
  },

  async linkWhatsApp(tenantId: string, payload: LinkWhatsAppPayload): Promise<TenantWhatsAppAccount> {
    const { data } = await client.post<ApiEnvelope<TenantWhatsAppAccount>>(
      `/partner/tenants/${tenantId}/whatsapp`,
      { ...payload, ...getPartnerContext() },
    );
    return data.data;
  },

  async getWhatsApp(tenantId: string): Promise<TenantWhatsAppAccount> {
    const { data } = await client.get<ApiEnvelope<TenantWhatsAppAccount>>(
      `/partner/tenants/${tenantId}/whatsapp`,
      { params: getPartnerContext() },
    );
    return data.data;
  },

  async generateApiKey(): Promise<{ apiKey: string; message: string }> {
    const { data } = await client.post<ApiEnvelope<{ apiKey: string; message: string }>>(
      '/partner/api-key',
      getPartnerContext(),
    );
    return data.data;
  },
};
