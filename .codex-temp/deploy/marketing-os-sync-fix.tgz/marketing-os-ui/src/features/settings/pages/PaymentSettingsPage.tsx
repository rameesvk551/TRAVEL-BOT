import React, { useEffect, useState } from 'react';
import { Card, Form, Input, Switch, Button, Typography, Divider, Space, Spin, Alert } from 'antd';
import { SaveOutlined, CreditCardOutlined, DollarOutlined, SafetyOutlined } from '@ant-design/icons';
import { usePaymentSettings, useUpdatePaymentSettings } from '../../configure-business/hooks/useOrderQueries';

const { Title, Text, Paragraph } = Typography;

interface PaymentConfig {
    enabled: boolean;
    cod_enabled: boolean;
    online_enabled: boolean;
    payment_configuration: string;
    business_name: string;
    country_of_origin: string;
    importer_name: string;
    importer_address: {
        address_line1: string;
        city: string;
        zone_code: string;
        postal_code: string;
        country_code: string;
    };
}

const defaultConfig: PaymentConfig = {
    enabled: false,
    cod_enabled: true,
    online_enabled: false,
    payment_configuration: '',
    business_name: '',
    country_of_origin: 'IN',
    importer_name: '',
    importer_address: {
        address_line1: '',
        city: '',
        zone_code: '',
        postal_code: '',
        country_code: 'IN',
    },
};

export const PaymentSettingsPage: React.FC = () => {
    const [form] = Form.useForm();
    const { data: settings, isLoading } = usePaymentSettings();
    const updateMutation = useUpdatePaymentSettings();
    const [onlineEnabled, setOnlineEnabled] = useState(false);

    useEffect(() => {
        if (settings) {
            form.setFieldsValue({ ...defaultConfig, ...settings });
            setOnlineEnabled(settings.online_enabled || false);
        }
    }, [settings, form]);

    const handleSubmit = (values: any) => {
        updateMutation.mutate(values);
    };

    if (isLoading) {
        return (
            <Card style={{ borderRadius: 12, textAlign: 'center', padding: 48 }}>
                <Spin size="large" />
            </Card>
        );
    }

    return (
        <Card style={{ borderRadius: 12 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 24 }}>
                <CreditCardOutlined style={{ fontSize: 24, color: '#4F46E5' }} />
                <div>
                    <Title level={4} style={{ margin: 0 }}>Payment Settings</Title>
                    <Text type="secondary">Configure payment options for your WhatsApp store</Text>
                </div>
            </div>

            <Form
                form={form}
                layout="vertical"
                onFinish={handleSubmit}
                initialValues={defaultConfig}
                style={{ maxWidth: 600 }}
            >
                {/* ── Payment Toggles ── */}
                <Card
                    size="small"
                    style={{ marginBottom: 24, background: '#F8FAFC', borderRadius: 8 }}
                    bordered={false}
                >
                    <Space direction="vertical" style={{ width: '100%' }} size="middle">
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                            <div>
                                <Text strong>Enable Payments</Text>
                                <br />
                                <Text type="secondary" style={{ fontSize: 12 }}>Turn on payments for your WhatsApp store</Text>
                            </div>
                            <Form.Item name="enabled" valuePropName="checked" noStyle>
                                <Switch />
                            </Form.Item>
                        </div>

                        <Divider style={{ margin: '4px 0' }} />

                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                            <div>
                                <DollarOutlined style={{ marginRight: 8, color: '#10B981' }} />
                                <Text strong>Cash on Delivery (COD)</Text>
                                <br />
                                <Text type="secondary" style={{ fontSize: 12, marginLeft: 24 }}>Allow customers to pay when order is delivered</Text>
                            </div>
                            <Form.Item name="cod_enabled" valuePropName="checked" noStyle>
                                <Switch />
                            </Form.Item>
                        </div>

                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                            <div>
                                <CreditCardOutlined style={{ marginRight: 8, color: '#4F46E5' }} />
                                <Text strong>Online Payment (Razorpay)</Text>
                                <br />
                                <Text type="secondary" style={{ fontSize: 12, marginLeft: 24 }}>
                                    UPI, Cards, Netbanking, Wallets via Razorpay
                                </Text>
                            </div>
                            <Form.Item name="online_enabled" valuePropName="checked" noStyle>
                                <Switch onChange={setOnlineEnabled} />
                            </Form.Item>
                        </div>
                    </Space>
                </Card>

                {/* ── Razorpay Configuration ── */}
                {onlineEnabled && (
                    <>
                        <Alert
                            message="Razorpay Payment Configuration"
                            description="You need a Razorpay account connected to WhatsApp Business API. Enter your payment configuration name from the Meta Business Manager."
                            type="info"
                            showIcon
                            icon={<SafetyOutlined />}
                            style={{ marginBottom: 16, borderRadius: 8 }}
                        />

                        <Form.Item
                            label="Payment Configuration Name"
                            name="payment_configuration"
                            rules={[{ required: onlineEnabled, message: 'Required for online payments' }]}
                            tooltip="The payment configuration name from Meta Business Manager → WhatsApp → Payment Settings"
                        >
                            <Input placeholder="e.g., razorpay_config_1" />
                        </Form.Item>

                        <Divider orientation={"left" as any}>Business Details</Divider>

                        <Form.Item
                            label="Business Name"
                            name="business_name"
                            rules={[{ required: onlineEnabled, message: 'Required' }]}
                        >
                            <Input placeholder="Your business name" />
                        </Form.Item>

                        <Form.Item
                            label="Country of Origin"
                            name="country_of_origin"
                        >
                            <Input placeholder="IN" />
                        </Form.Item>

                        <Divider orientation={"left" as any}>Importer Information</Divider>

                        <Paragraph type="secondary" style={{ fontSize: 12, marginBottom: 16 }}>
                            Required by Indian regulations for e-commerce orders.
                        </Paragraph>

                        <Form.Item
                            label="Importer Name"
                            name="importer_name"
                        >
                            <Input placeholder="Legal importer name" />
                        </Form.Item>

                        <Form.Item
                            label="Address Line 1"
                            name={['importer_address', 'address_line1']}
                        >
                            <Input placeholder="Street address" />
                        </Form.Item>

                        <Space size="middle" style={{ width: '100%' }}>
                            <Form.Item
                                label="City"
                                name={['importer_address', 'city']}
                                style={{ flex: 1 }}
                            >
                                <Input placeholder="City" />
                            </Form.Item>

                            <Form.Item
                                label="State Code"
                                name={['importer_address', 'zone_code']}
                                style={{ flex: 1 }}
                            >
                                <Input placeholder="e.g., MH" />
                            </Form.Item>
                        </Space>

                        <Space size="middle" style={{ width: '100%' }}>
                            <Form.Item
                                label="Postal Code"
                                name={['importer_address', 'postal_code']}
                                style={{ flex: 1 }}
                            >
                                <Input placeholder="e.g., 400001" />
                            </Form.Item>

                            <Form.Item
                                label="Country Code"
                                name={['importer_address', 'country_code']}
                                style={{ flex: 1 }}
                            >
                                <Input placeholder="IN" />
                            </Form.Item>
                        </Space>
                    </>
                )}

                <Form.Item style={{ marginTop: 24 }}>
                    <Button
                        type="primary"
                        htmlType="submit"
                        icon={<SaveOutlined />}
                        loading={updateMutation.isPending}
                        size="large"
                    >
                        Save Payment Settings
                    </Button>
                </Form.Item>
            </Form>
        </Card>
    );
};
