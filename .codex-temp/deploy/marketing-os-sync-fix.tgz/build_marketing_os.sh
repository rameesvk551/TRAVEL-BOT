#!/bin/bash
cd /home/ec2-user/marketting-os/marketing-os-server
echo "Installing dependencies if needed..."
# Just run tsc
npx tsc
echo "Compiling complete."
pm2 restart marketing-os-api
echo "marketing-os-api restarted."
