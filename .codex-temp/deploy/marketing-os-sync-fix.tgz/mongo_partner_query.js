import mongoose from 'mongoose';

async function run() {
  const uri = 'mongodb://127.0.0.1:27018/marketing-os';
  console.log(`Connecting to ${uri}...`);
  try {
    await mongoose.connect(uri);
    const Tenant = mongoose.connection.collection('tenants');
    const Partner = mongoose.connection.collection('partners');
    
    // Look for wayo tenant
    const tenant = await Tenant.findOne({ slug: 'wayo-82ac6fd3' });
    console.log('\n--- Wayo Tenant ---');
    if (tenant) {
      console.log(`Name: ${tenant.name}`);
      console.log(`Partner ID: ${tenant.partnerId}`);
      console.log(`Partner ID Type: ${typeof tenant.partnerId}`);
      
      const partner = await Partner.findOne({ _id: tenant.partnerId });
      console.log('\n--- Partner Linked ---');
      if (partner) {
        console.log(`Name: ${partner.name}`);
        console.log(`URL: ${partner.webhookUrl}`);
        console.log(`Secret: ${partner.webhookSecret ? 'SET' : 'MISSING'}`);
      } else {
        console.log('❌ PARTNER NOT FOUND BY TENANT PARTNER_ID!');
      }
    } else {
      console.log('❌ TENANT NOT FOUND!');
    }

    process.exit(0);
  } catch (err) {
    console.error('Error:', err.message);
    process.exit(1);
  }
}
run();
