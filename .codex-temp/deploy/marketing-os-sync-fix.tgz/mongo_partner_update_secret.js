import mongoose from 'mongoose';

async function run() {
  const uri = 'mongodb://127.0.0.1:27018/marketing-os';
  console.log(`Connecting to ${uri}...`);
  try {
    await mongoose.connect(uri);
    const Partner = mongoose.connection.collection('partners');
    
    // EdgesPlus Partner ID: 69c29fe5c6231cfeec0f14e0
    const partnerId = '69c29fe5c6231cfeec0f14e0';
    const webhookSecret = 'Aminaraiha@123AIN';

    const crypto = await import('crypto');
    // Using default fallback or hardcode exact key if needed:
    const encryptionKey = process.env.ENCRYPTION_KEY || 'this_is_a_fallback_32_byte_key_!'; 
    
    function encryptSecret(text) {
        const iv = crypto.randomBytes(16);
        const cipher = crypto.createCipheriv(
            'aes-256-cbc',
            Buffer.from(encryptionKey).subarray(0, 32),
            iv
        );
        let encrypted = cipher.update(text);
        encrypted = Buffer.concat([encrypted, cipher.final()]);
        return iv.toString('hex') + ':' + encrypted.toString('hex');
    }

    const encryptedSecret = encryptSecret(webhookSecret);

    const result = await Partner.updateOne(
      { _id: new mongoose.Types.ObjectId(partnerId) },
      { $set: { webhookSecretEncrypted: encryptedSecret, webhookSecret: undefined } }
    );

    console.log(`\nUpdate Results:`);
    console.log(`Matched: ${result.matchedCount}`);
    console.log(`Modified: ${result.modifiedCount}`);
    
    if (result.matchedCount > 0) {
      console.log(`✅ Success! EdgesPlus partner webhookSecretEncrypted is now set.`);
    } else {
      console.log(`⚠️ Warning: No records were modified. Is the ID correct?`);
    }

    process.exit(0);
  } catch (err) {
    console.error('Error:', err.message);
    process.exit(1);
  }
}
run();
