const m = require('mongoose');
(async () => {
  await m.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/marketing_os');
  const t = await m.connection.db.collection('tenants').findOne({ slug: 'wayo-82ac6fd3' });
  console.log('TENANT:', JSON.stringify({ slug: t?.slug, email: t?.email, partnerId: t?.partnerId }, null, 2));
  if (t?.partnerId) {
    const p = await m.connection.db.collection('partners').findOne({ _id: new m.Types.ObjectId(t.partnerId) });
    console.log('PARTNER:', JSON.stringify({ name: p?.name, email: p?.email, webhookUrl: p?.webhookUrl, hasSecret: !!p?.webhookSecretEncrypted, status: p?.status }, null, 2));
  }
  process.exit(0);
})();
