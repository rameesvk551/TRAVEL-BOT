import mongoose from 'mongoose';

async function run() {
  const uri = 'mongodb://127.0.0.1:27018/marketing-os';
  console.log(`Connecting to ${uri}...`);
  try {
    await mongoose.connect(uri);
    const Partner = mongoose.connection.collection('partners');
    
    // EdgesPlus Partner ID: 69c29fe5c6231cfeec0f14e0
    const partnerId = '69c29fe5c6231cfeec0f14e0';
    const webhookUrl = 'http://localhost:6767/api/whatsapp/webhook';

    const result = await Partner.updateOne(
      { _id: new mongoose.Types.ObjectId(partnerId) },
      { $set: { webhookUrl: webhookUrl } }
    );

    console.log(`\nUpdate Results:`);
    console.log(`Matched: ${result.matchedCount}`);
    console.log(`Modified: ${result.modifiedCount}`);
    
    if (result.modifiedCount > 0) {
      console.log(`✅ Success! EdgesPlus partner webhookUrl is now: ${webhookUrl}`);
    } else {
      console.log(`⚠️ Warning: No records were modified. Is the ID correct?`);
    }

    process.exit(0);
  } catch (err) {
    console.error('Error:', err.message);
    process.exit(1);
  }
}
run();
