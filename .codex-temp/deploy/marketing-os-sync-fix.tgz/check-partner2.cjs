require('dotenv').config();
const m = require('mongoose');
(async () => {
  try {
    const uri = process.env.MONGODB_URI;
    console.log('Connecting to', uri);
    await m.connect(uri);
    const t = await m.connection.db.collection('tenants').findOne({ slug: 'wayo-82ac6fd3' });
    console.log('TENANT:', JSON.stringify({ slug: t?.slug, email: t?.email, partnerId: t?.partnerId }, null, 2));
    if (t?.partnerId) {
      const p = await m.connection.db.collection('partners').findOne({ _id: new m.Types.ObjectId(t.partnerId) });
      console.log('PARTNER:', JSON.stringify({ name: p?.name, email: p?.email, webhookUrl: p?.webhookUrl, hasSecret: !!p?.webhookSecretEncrypted, status: p?.status }, null, 2));
    }
  } catch (err) {
    console.error(err);
  } finally {
    process.exit(0);
  }
})();
