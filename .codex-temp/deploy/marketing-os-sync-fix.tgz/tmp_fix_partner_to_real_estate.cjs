const mongoose = require('mongoose');

async function main() {
  await mongoose.connect('mongodb://127.0.0.1:27018/marketing-os');
  const db = mongoose.connection.db;

  const tenant = await db.collection('tenants').findOne(
    { email: 'rameesvk551@gmail.com' },
    { projection: { _id: 1, slug: 1, email: 1, partnerId: 1 } }
  );

  if (!tenant) {
    throw new Error('Tenant by email not found');
  }

  const partner = await db.collection('partners').findOne(
    { _id: tenant.partnerId },
    { projection: { _id: 1, name: 1, email: 1, webhookUrl: 1, status: 1 } }
  );

  if (!partner) {
    throw new Error('Partner not found for tenant');
  }

  const newUrl = 'http://127.0.0.1:4000/api/v1/whatsapp/webhook';

  const update = await db.collection('partners').updateOne(
    { _id: partner._id },
    { $set: { webhookUrl: newUrl, updatedAt: new Date() } }
  );

  const verify = await db.collection('partners').findOne(
    { _id: partner._id },
    { projection: { _id: 1, webhookUrl: 1, status: 1 } }
  );

  console.log(JSON.stringify({
    tenant,
    partnerBefore: partner,
    modifiedCount: update.modifiedCount,
    partnerAfter: verify
  }, null, 2));

  await mongoose.disconnect();
}

main().catch(async (err) => {
  console.error(err.message);
  try { await mongoose.disconnect(); } catch {}
  process.exit(1);
});
