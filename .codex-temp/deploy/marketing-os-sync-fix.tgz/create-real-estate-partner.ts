import mongoose from 'mongoose';
import { config } from 'dotenv';
import crypto from 'crypto';

config();

// Define Partner schema inline
const partnerSchema = new mongoose.Schema({
  name: String,
  email: { type: String, unique: true },
  commissionRate: Number,
  status: String,
  plan: String,
  walletBalance: Number,
  totalCustomers: Number,
  totalRevenue: Number,
  referralCode: String,
  webhookUrl: String,
  webhookSecretEncrypted: String,
  apiKeyEncrypted: String,
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

const PartnerModel = mongoose.model('Partner', partnerSchema);

async function createRealEstateBotPartner() {
  try {
    const mongoUri = process.env.MONGODB_URI || 'mongodb://localhost:27017/marketing-os';
    await mongoose.connect(mongoUri);
    console.log('✅ Connected to MongoDB\n');

    // Generate referral code
    const referralCode = 'REA-BOT-' + crypto.randomBytes(4).toString('hex').toUpperCase();
    
    // Generate API key
    const apiKey = 'reb_' + crypto.randomBytes(32).toString('hex');

    const partnerData = {
      name: 'Real Estate Bot',
      email: 'admin@real-estate-bot.wayon.in',
      commissionRate: 0.50, // 50% commission
      status: 'active',
      plan: 'enterprise',
      walletBalance: 0,
      totalCustomers: 0,
      totalRevenue: 0,
      referralCode: referralCode,
      webhookUrl: 'https://api.real-estate.wayon.in/webhooks/marketing-os'
    };

    const partner = await PartnerModel.findOneAndUpdate(
      { email: partnerData.email },
      partnerData,
      { new: true, upsert: true, runValidators: false }
    );
    
    console.log('✅ Partner successfully created/updated:');
    console.log('════════════════════════════════════════');
    console.log(`Name:              ${partner.name}`);
    console.log(`Email:             ${partner.email}`);
    console.log(`Referral Code:     ${partner.referralCode}`);
    console.log(`Commission Rate:   ${partner.commissionRate * 100}%`);
    console.log(`Status:            ${partner.status}`);
    console.log(`Plan:              ${partner.plan}`);
    console.log('\n📋 Credentials for Real Estate Bot:');
    console.log('════════════════════════════════════════');
    console.log(`API Key:           ${apiKey}`);
    console.log(`Partner Email:     ${partnerData.email}`);
    console.log(`Webhook URL:       ${partnerData.webhookUrl}`);
    console.log('════════════════════════════════════════\n');
    
    console.log('✅ Add to real-estate-bot .env:');
    console.log('════════════════════════════════════════');
    console.log(`MARKETING_OS_PARTNER_KEY=${apiKey}`);
    console.log(`MARKETING_OS_API_BASE_URL=https://api.marketing-os.wayon.in`);
    console.log(`MARKETING_OS_PROVISION_ENABLED=true`);
    console.log('════════════════════════════════════════\n');

  } catch (error) {
    console.error('❌ Failed to create partner:', error);
  } finally {
    await mongoose.disconnect();
    process.exit(0);
  }
}

createRealEstateBotPartner();
